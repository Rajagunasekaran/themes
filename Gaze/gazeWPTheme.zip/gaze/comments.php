<div class="entry-comments mt-20">
	
	<h3 class="heading relative uppercase mb-30">
		<small>
			<?php 
				comments_number( 
					esc_html__( '0 Comments', 'gaze' ), 
					esc_html__( '1 Comment',  'gaze' ), 
					esc_html__( '% Comments', 'gaze' ) 
				); 
			?>
		</small>
	</h3>
	
	<?php if( have_comments() ) : ?>
	
		<ul class="comment-list">
			<?php wp_list_comments( 'type=all&callback=ebor_custom_comment' ); ?>
		</ul>
		
		<?php paginate_comments_links(); ?>
	
	<?php endif; ?>
	
</div>

<div class="comment-form mt-60">
	<?php 
		comment_form(
			array(
				'title_reply_before'  => '<h3 id="reply-title" class="comment-reply-title heading relative uppercase mb-30"><small>',
				'title_reply_after'   => '</small></h3>',
				'class_submit'        => 'btn btn-md btn-color'
			)
		); 
	?>
</div>