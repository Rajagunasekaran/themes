<?php 
	get_header(); 
	
	ebor_page_title( 
		get_option( 'portfolio_title', 'Our Portfolio' ), 
		get_option( 'portfolio_image', '' ) 
	);
?>

<section class="section-wrap-md">
	<div class="container">
		<?php get_template_part( 'loop/loop-portfolio', get_option( 'portfolio_layout', '4-col' ) ); ?>
	</div>
</section>

<?php get_footer();