<?php 
	get_header(); 
	
	ebor_page_title( 
		get_option( 'team_title', 'Our Team' ), 
		get_option( 'team_image', '' ) 
	);
?>

<section class="section-wrap-md">
	<div class="container">
		<?php get_template_part( 'loop/loop-team', get_option( 'team_layout', '4-col' ) ); ?>
	</div>
</section>

<?php get_footer();