<?php 
	get_header();
	the_post();
	
	$thumbnail = has_post_thumbnail();
	$sidebar   = is_active_sidebar( 'page' );
	$class     = ( $sidebar ) ? 'col-md-9' : 'col-md-10 col-md-offset-1';
	
	if( $thumbnail ){
		ebor_page_title( 
			get_the_title(), 
			get_the_post_thumbnail_url( $post->ID, 'full' ) 
		);
	}
?>

<section id="page-<?php the_ID(); ?>" <?php post_class( 'section-wrap-sm post-single bg-light pb-50' ); ?>>
	<div class="container relative">
		<div class="row">
		
			<div class="<?php echo esc_attr( $class ); ?> post-content mb-50">
				<article class="entry-item">
					<div class="entry-wrap">
						<div class="entry">
							<div class="entry-content">
							
								<div class="article">
									<?php
										if(!( $thumbnail )){
											the_title( '<h1 class="entry-title">', '</h1>' );
										}
										
										the_content();
										wp_link_pages();
									?>
								</div><!-- end article -->
								
								<?php
									get_template_part( 'inc/content-post', 'sharing' );
									
									if( comments_open() || get_comments_number() ){
										comments_template();
									}
								?>
							
							</div><!-- end entry content -->
						</div>
					</div>
				</article>
			</div><!-- end col -->
			
			<?php 
				if( $sidebar ){
					get_sidebar( 'page' ); 
				}
			?>
		
		</div><!-- end row -->
	</div><!-- end container -->
</section><!-- end blog standard -->

<?php get_footer();