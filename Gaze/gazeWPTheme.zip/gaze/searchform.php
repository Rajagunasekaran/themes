<form class="relative" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<input type="search" name="s" placeholder="<?php esc_attr_e( 'Search', 'gaze' ); ?>" class="searchbox mb-0">
	<button type="submit" class="search-button"><i class="fa fa-search"></i></button>
</form>