===================================================================
April 27th 2018 - v1.0.3
-------------------------------------------------------------------

* FIXED: Post author being hidden by post sharing theme option
* FIXED: Post sharing buttons now working as intended
  
===================================================================
April 2nd 2018 - v1.0.2
-------------------------------------------------------------------

* FIXED: Logo URLs mixed up
* FIXED: Broken twitter feeds

===================================================================
March 19th 2018 - v1.0.1
-------------------------------------------------------------------

* FIXED: Testimonials on parallax background issue
* FIXED: Font awesome icons missing fa class
* FIXED: Language folder location
* FIXED: Social icons visual composer block
* ADDED: Icon picker to tabs, icon box, flip box, and counter custom Visual Composer blocks for Gaze

===================================================================
March 12th 2018 - v1.0.0 - INITIAL RELEASE
-------------------------------------------------------------------