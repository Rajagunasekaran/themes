<div id="team-<?php the_ID(); ?>" <?php post_class( 'col-sm-4' ); ?>>
	<div class="team-wrap">
		<div class="team-member mt-mdm-40">
			<div class="team-img hover-trigger mb-0">
				
				<?php the_post_thumbnail( 'large' ); ?>
				
				<div class="hover-overlay light">
					<div class="team-details text-center">
						<?php the_title( '<h4 class="team-title uppercase"><a href="'. get_permalink() .'">', '</a></h4>' ); ?>
						<span><?php echo esc_html( get_post_meta( $post->ID, '_ebor_the_job_title', 1 ) ); ?></span> 
					</div>
				</div>
				
			</div>
		</div>
	</div>
</div>