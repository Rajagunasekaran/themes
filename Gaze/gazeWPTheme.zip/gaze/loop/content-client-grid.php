<div id="client-<?php the_ID(); ?>" <?php post_class( 'col-md-3 col-xs-6 partner-cell' ); ?>>
	<a href="<?php echo esc_url( get_post_meta( $post->ID, '_ebor_the_client_url', 1 ) ); ?>" target="_blank">
		<?php the_post_thumbnail(); ?>
	</a>
</div>