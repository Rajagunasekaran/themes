<div class="row blog-standard">
	<div class="col-md-10 col-md-offset-1 post-content mb-50">
		<?php
			if ( have_posts() ) : while ( have_posts() ) : the_post();
			
				/**
				 * Get blog posts by blog layout.
				 */
				get_template_part( 'loop/content-post', 'standard' );
			
			endwhile;	
			else : 
				
				/**
				 * Display no posts message if none are found.
				 */
				get_template_part( 'loop/content','none' );
				
			endif;
			
			get_template_part( 'inc/content-post', 'pagination' ); 
		?>
	</div><!-- end col -->
</div><!-- end row -->