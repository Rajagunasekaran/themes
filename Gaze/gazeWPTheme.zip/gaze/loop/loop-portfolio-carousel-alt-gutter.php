<div id="works-slider" class="flickity-slider-wrap items-3 slider-gutter-14" data-autoplay="false" data-arrows="true" data-slidedots="false">
	<?php
		if ( have_posts() ) : while ( have_posts() ) : the_post();
		
			/**
			 * Get blog posts by blog layout.
			 */
			get_template_part( 'loop/content-portfolio', 'carousel-alt' );
		
		endwhile;	
		else : 
			
			/**
			 * Display no posts message if none are found.
			 */
			get_template_part( 'loop/content','none' );
			
		endif;
	?>
</div>