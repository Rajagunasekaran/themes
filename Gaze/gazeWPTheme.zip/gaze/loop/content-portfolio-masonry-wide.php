<?php
	$colours = array(
		'blue',
		'green',
		'pink',
		'violet',
		'orange',
		'green',
		'blue',
		'green',
		'pink',
		'violet',
		'orange',
		'green',
		'blue',
		'green',
		'pink',
		'violet',
		'orange',
		'green',
		'blue',
		'green',
		'pink',
		'violet',
		'orange',
		'green'
	);
?>

<div id="portfolio-<?php the_ID(); ?>" <?php post_class( 'work-item hover-trigger hover-5 hover-'. $colours[$wp_query->current_post] ); ?>>
	<div class="work-container">
		<div class="work-img">
			<a href="<?php the_permalink(); ?>">
				
				<?php the_post_thumbnail( 'large' ); ?>
				
				<div class="hover-overlay">
					<div class="work-description">
						<?php the_title( '<h3>', '</h3>' ); ?>
						<span><?php echo ebor_the_terms( 'portfolio_category', ', ', 'name' ); ?></span>
					</div>
				</div>
				
			</a>
		</div>
	</div>
</div>