<?php $icons = get_post_meta( $post->ID, '_ebor_team_social_icons', true ); ?>

<div id="team-<?php the_ID(); ?>" <?php post_class( 'col-sm-4 mb-40 animated-from-left' ); ?>>
	<div class="team-wrap">
		<div class="team-member">
			
			<div class="team-img hover-trigger hover-2">
			
				<?php the_post_thumbnail( 'large' ); ?>
				
				<?php if( is_array( $icons ) ) : ?>
					<div class="hover-overlay" data-overlay="5">
						<div class="social-icons nobase">
							<?php 
								foreach( $icons as $key => $icon ){
									if(!( isset( $icon['_ebor_social_icon_url'] ) ))
										continue;
										
									echo '
										<a href="'. esc_url( $icon['_ebor_social_icon_url'] ) .'" target="_blank">
											<i class="fa '. esc_attr( $icon['_ebor_social_icon'] ) .'"></i>
										</a>
									';
								}
							?>
						</div> 
					</div>
				<?php endif; ?>
			
			</div>
			
			<div class="team-details text-center">                
				<?php the_title( '<h4 class="team-title uppercase"><a href="'. get_permalink() .'">', '</a></h4>' ); ?>
				<span><?php echo esc_html( get_post_meta( $post->ID, '_ebor_the_job_title', 1 ) ); ?></span> 
			</div> 
			
		</div>
	</div>
</div>