<?php $format = get_post_format(); ?>

<div id="post-<?php the_ID(); ?>" <?php post_class( 'col-md-4 col-sm-6 col-xs-12 masonry-item' ); ?>>
	<article class="entry-item">
		
		<?php get_template_part( 'inc/content-format', $format ); ?>
		
		<?php if(!( 'quote' == $format )) : ?>
		
			<div class="entry-wrap">
				<div class="entry">
					
					<?php 
						get_template_part( 'inc/content-post', 'meta' );
						the_title( '<h2 class="entry-title"><a href="'. get_permalink() .'">', '</a></h2>' ); 
					?>
					
					<div class="entry-content">
						<?php the_excerpt(); ?>
						<a href="<?php the_permalink(); ?>" class="read-more sliding-link"><?php esc_html_e( 'Read More', 'gaze' ); ?></a>
					</div>
					
				</div>
			</div>
		
		<?php endif; ?>
		
	</article>
</div>