<section class="section-wrap-sm blog-masonry bg-light">
	<div class="container relative">
		<div class="row">
		
			<div class="col-md-9">
				
				<div class="row masonry blog-content">           
					<?php
						if ( have_posts() ) : while ( have_posts() ) : the_post();
						
							/**
							 * Get blog posts by blog layout.
							 */
							get_template_part( 'loop/content-post', 'masonry-sidebar' );
						
						endwhile;	
						else : 
							
							/**
							 * Display no posts message if none are found.
							 */
							get_template_part( 'loop/content','none' );
							
						endif;
					?>
				</div> <!-- end row -->
				
				<?php get_template_part( 'inc/content-post', 'load-more' ); ?>
			
			</div>
			
			<?php get_sidebar(); ?>
		
		</div>
	</div> 
</section> 