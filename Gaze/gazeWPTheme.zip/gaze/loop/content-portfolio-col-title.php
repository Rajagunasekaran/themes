<div id="portfolio-<?php the_ID(); ?>" <?php post_class( 'work-item hover-trigger '. ebor_the_terms('portfolio_category', ' ', 'slug') ); ?>>
	<div class="work-container">
		
		<div class="work-img">
			<a href="<?php the_permalink(); ?>" class="hover-scale">
				<?php the_post_thumbnail( 'ebor-grid' ); ?>
				<div class="hover-overlay" data-overlay="1"></div>
			</a>              
		</div>
		
		<div class="work-description">
			<?php the_title( '<h3><a href="'. get_permalink() .'">', '</a></h3>' ); ?>
			<span><?php echo ebor_the_terms( 'portfolio_category', ', ', 'name' ); ?></span>
		</div>  
		
	</div> 
</div>