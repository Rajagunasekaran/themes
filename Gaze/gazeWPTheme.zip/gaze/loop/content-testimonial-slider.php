<div id="testimonial-<?php the_ID(); ?>" <?php post_class( 'item' ); ?>>
	<div class="testimonial">
		<p class="testimonial-text"><?php echo get_the_content(); ?></p>
		<?php the_title( '<span class="uppercase">', ' / '. esc_html( get_post_meta( $post->ID, '_ebor_the_job_title', 1 ) ) .'</span>' ); ?>
	</div>
</div>