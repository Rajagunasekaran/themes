<?php get_template_part( 'inc/content-portfolio', 'filters' ); ?>

<div class="row">
	<div id="portfolio-grid" class="works-grid grid-3-col with-title gutter">
		<?php
			if ( have_posts() ) : while ( have_posts() ) : the_post();
			
				/**
				 * Get blog posts by blog layout.
				 */
				get_template_part( 'loop/content-portfolio', 'col-title' );
			
			endwhile;	
			else : 
				
				/**
				 * Display no posts message if none are found.
				 */
				get_template_part( 'loop/content','none' );
				
			endif;
		?>
	</div>  <!-- end portfolio container -->
</div> <!-- end row -->

<?php get_template_part( 'inc/content-portfolio', 'load-more' );