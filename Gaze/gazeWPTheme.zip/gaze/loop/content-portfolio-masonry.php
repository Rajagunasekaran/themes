<?php
	$class = 'quarter';
	$ids   = array( 0, 5, 6, 11 );
	if( in_array( $wp_query->current_post, $ids ) ){
		$class = 'half';
	}
?>

<div id="portfolio-<?php the_ID(); ?>" <?php post_class( $class . ' work-item hover-trigger hover-2 '. ebor_the_terms('portfolio_category', ' ', 'slug') ); ?>>
	<div class="work-container">
		<div class="work-img">
			<a href="<?php the_permalink(); ?>">
				
				<?php the_post_thumbnail( 'large' ); ?>
				
				<div class="hover-overlay" data-overlay="5">
					<div class="work-description">
						<?php the_title( '<h3>', '</h3>' ); ?>
						<span><?php echo ebor_the_terms( 'portfolio_category', ', ', 'name' ); ?></span>
					</div>
				</div>
				
			</a>
		</div>
	</div>
</div>