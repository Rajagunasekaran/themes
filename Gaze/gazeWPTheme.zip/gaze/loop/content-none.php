<div class="row text-center page-404">
	<div class="col-md-6 col-md-offset-3">
		
		<h2 class="mb-30"><?php esc_html_e( 'Oops... No Content Found', 'gaze' ); ?></h2>
		
		<p class="mb-20">
			<?php esc_html_e( 'You can go back to', 'gaze' ); ?> 
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Homepage', 'gaze' ); ?></a> 
			<?php esc_html_e( 'or use search', 'gaze' ); ?>
		</p>
		
		<?php get_search_form(); ?>
		
	</div>
</div>