<?php $class = (!( $wp_query->current_post % 2 == 0 )) ? 'align-right' : ''; ?>

<div id="portfolio-<?php the_ID(); ?>" <?php post_class( $class . ' work-item ' . ebor_the_terms('portfolio_category', ' ', 'slug') ); ?>>
	<div class="work-container">
		
		<div class="work-img">
			<a href="<?php the_permalink(); ?>" class="clearfix">
				
				<div class="bg-img-holder">
					<div class="bg-img" style="background-image: url(<?php echo esc_url( get_the_post_thumbnail_url( $post->ID, 'full' ) ); ?>)"></div>
				</div>
				
				<div class="work-description">
					<?php the_title( '<h3 class="uppercase">', '</h3>' ); ?>
					<span class="bottom-line left-align grey"><?php echo ebor_the_terms( 'portfolio_category', ', ', 'name' ); ?></span>
					<?php the_excerpt(); ?>
				</div>
				
			</a>
		</div>
		
	</div>
</div>