<div id="portfolio-<?php the_ID(); ?>" <?php post_class( 'gallery-cell work-item hover-1 hover-trigger' ); ?>>
	<div class="work-container">
		<div class="work-img">
			
			<?php the_post_thumbnail( 'ebor-square' ); ?>
			
			<div class="hover-overlay" data-overlay="5">
				
				<div class="project-icons">
					<a href="<?php echo get_the_post_thumbnail_url( $post->ID, 'full' ); ?>" class="lightbox-img"><i class="ui-search"></i></a>
					<a href="<?php the_permalink(); ?>"><i class="ui-link"></i></a>
				</div>
				
				<div class="work-description">
					<?php the_title( '<h3>', '</h3>' ); ?>
					<span><?php echo ebor_the_terms( 'portfolio_category', ', ', 'name' ); ?></span>
				</div>
				
			</div>
			
		</div>
	</div>
</div>