<article id="post-<?php the_ID(); ?>" <?php post_class( 'mb-30 col-md-4 col-sm-6 col-xs-12 animated-from-left' ); ?>>
	<div class="entry-item card">
		
		<div class="entry-img">
			<a href="<?php the_permalink(); ?>" class="hover-scale">
				<?php the_post_thumbnail( 'ebor-grid' ); ?>
			</a>
			<div class="entry-date">
				<?php the_time( 'd' ); ?>
				<span><?php the_time( 'M' ); ?></span>
			</div>
		</div>
		
		<div class="entry-wrap">
			<div class="entry">
				<?php 
					the_title( '<h4 class="entry-title"><a href="'. get_permalink() .'">', '</a></h4>' );
					the_excerpt();
				?>
			</div>
		</div>
		
	</div>
</article>