<div class="work-item hover-zoom">
	
	<div class="work-container">
		<div class="work-img" id="square-div">
			<a href="<?php the_permalink(); ?>">
				<?php the_post_thumbnail( 'ebor-square' ); ?>
			</a>
		</div>
	</div>
	
	<div class="work-item-description">
		<div class="work-description-inner valign">
			<?php 
				the_title( '<h3 class="bottom-line uppercase">', '</h3>' );
				echo wpautop( wp_trim_words( get_the_excerpt(), 10 ) );
			?>
		</div>
	</div>
	
</div>