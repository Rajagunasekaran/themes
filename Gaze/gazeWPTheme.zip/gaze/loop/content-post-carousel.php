<article class="blog-slide">
	<div class="entry-item">
		<div class="entry-wrap">
			<div class="entry">
				
				<?php the_title ( '<h4 class="entry-title"><a href="'. get_permalink() .'">', '</a></h4>' ); ?>
				
				<ul class="entry-meta">
					<li><?php the_time( get_option('date_format') ); ?></li>
					<li class="entry-author">
						<?php the_author_link(); ?>
					</li>
				</ul>
				
			</div>
		</div>
	</div>
</article>