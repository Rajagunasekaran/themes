<hr>
	
<div class="socials-share mt-30 clearfix">
	
	<span><?php esc_html_e( 'Share:', 'gaze' ); ?></span>
	
	<div class="social-icons nobase dark">
		
		<a href="#" data-social="facebook" class="social-facebook">
			<i class="fa fa-facebook"></i>
		</a>
		
		<a href="#" data-social="twitter" class="social-twitter">
			<i class="fa fa-twitter"></i>
		</a>
		
		<a href="#" data-social="googleplus" class="social-google-plus">
			<i class="fa fa-google-plus"></i>
		</a>
		
		<a href="#" data-social="pinterest" class="social-pinterest">
			<i class="fa fa-pinterest-p"></i>
		</a>
		
	</div>
	
</div>