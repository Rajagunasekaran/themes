<?php 
	$url_light	= get_option( 'theme_logo_light', get_theme_file_uri( '/style/img/logo_light.png' ) ); 
	$url_dark 	= get_option( 'theme_logo', get_theme_file_uri( '/style/img/logo_dark.png' ) );
?>

<div class="logo-container">
	<div class="logo-wrap local-scroll">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
			<img class="logo" src="<?php echo esc_url( $url_light ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'title' ) ); ?>">
			<img class="logo-dark" src="<?php echo esc_url( $url_dark ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'title' ) ); ?>">
		</a>
	</div>
</div>