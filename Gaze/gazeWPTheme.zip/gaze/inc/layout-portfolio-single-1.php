<?php $header_images = get_post_meta( $post->ID, '_ebor_gallery_images', 1 ); ?>

<section id="portfolio-<?php the_ID(); ?>" <?php post_class( 'section-wrap-sm portfolio-single' ); ?>>
	<div class="container">
		<div class="row">
			
			<?php if( is_array( $header_images ) ) : ?>
			
				<div class="col-md-8">
					<div class="flickity-slider-wrap" id="slider-single" data-autoplay="false" data-arrows="true" data-slidedots="false">
						<?php 
							foreach( $header_images as $id => $content ){
								echo '
									<div class="gallery-cell work-item">
										<div class="work-container">
											<div class="work-img">'. wp_get_attachment_image( $id, 'large' ) .'</div>
										</div> 
									</div>
								';
							}
						?>
					</div>
				</div>
			
			<?php endif; ?>
			
			<div class="col-md-4 project-description">
				
				<div>
					<?php
						the_content();
						wp_link_pages();
					?>
				</div>
				
				<div class="project-info mt-30">
					<?php
						get_template_part( 'inc/content-portfolio', 'meta' );
						get_template_part( 'inc/content-portfolio', 'sharing' );
					?>
				</div>
				
			</div>
		
		</div>
	</div>
</section>

<?php 
	get_template_part( 'inc/content-portfolio', 'related' );
	
	get_template_part( 'inc/content-portfolio', 'nav' );