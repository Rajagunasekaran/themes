<?php if( has_post_thumbnail() ) : ?>

	<div class="entry-img">
		<a href="<?php the_permalink(); ?>" class="hover-scale">
			<?php the_post_thumbnail( 'large' ); ?>
		</a>
	</div>
	
<?php endif;