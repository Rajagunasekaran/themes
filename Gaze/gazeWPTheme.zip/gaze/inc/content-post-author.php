<div class="entry-author-box clearfix">
	
	<?php echo get_avatar( get_the_author_meta( 'email' ), 60, false, false, array( 'class' => 'author-img' ) ); ?>
	
	<div class="author-info">
		<h6 class="author-name"><?php echo get_the_author(); ?></h6>
		<?php echo wpautop( get_the_author_meta( 'description' ) ); ?>
	</div>
</div>