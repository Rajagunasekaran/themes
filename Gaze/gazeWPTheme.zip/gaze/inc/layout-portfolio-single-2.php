<?php $header_images = get_post_meta( $post->ID, '_ebor_gallery_images', 1 ); ?>

<section id="portfolio-<?php the_ID(); ?>" <?php post_class( 'section-wrap portfolio-single style-2' ); ?>>
	<div class="container">
		<div class="row">
		
			<div class="col-md-8 project-description">
				<?php
					the_content();
					wp_link_pages();
				?>
			</div>
			
			<div class="col-md-4 mt-mdm-40">
				<div class="project-info">
					<?php 
						get_template_part( 'inc/content-portfolio', 'meta' ); 
						get_template_part( 'inc/content-portfolio', 'sharing' );
					?>
				</div>
			</div>
			
		</div>
	</div>
</section>

<?php if( is_array( $header_images ) ) : ?>

<section>
	<div class="container-fluid">
		<div class="row">
			<?php 
				foreach( $header_images as $id => $content ){
					echo '<div class="col-sm-6 nopadding">'. wp_get_attachment_image( $id, 'large' ) .'</div>';
				}
			?>
		</div>
	</div>
</section>

<?php 
	endif;
	
	get_template_part( 'inc/content-portfolio', 'nav' );