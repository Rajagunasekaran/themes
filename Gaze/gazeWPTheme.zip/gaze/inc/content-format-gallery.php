<?php 
	$header_images = get_post_meta( $post->ID, '_ebor_gallery_images', 1 ); 
	if( is_array( $header_images ) ) :
?>

<div class="entry-slider">
	<div class="flexslider dots-inside" id="flexslider">
		<ul class="slides clearfix">
			<?php 
				foreach( $header_images as $id => $content ){
					echo '
						<li>
							<a href="'. get_permalink() .'">
								'. wp_get_attachment_image( $id, 'large' ) .'
							</a>
						</li>
						
					';
				}
			?>
		</ul>
	</div>
</div>

<?php endif;