<footer class="footer footer-type-1 bg-dark">
	
	<?php get_template_part( 'inc/content-footer', 'widgets' ); ?>
	
	<div class="bottom-footer">
		<div class="container">
			<div class="row">
			
				<div class="col-sm-6 copyright sm-text-center">
					<?php get_template_part( 'inc/content-footer', 'copyright' ); ?>
				</div>
				
				<div class="col-sm-4 col-sm-offset-2 footer-socials mt-mdm-10">
					<?php get_template_part( 'inc/content-footer', 'social-icons' ); ?>
				</div>
			
			</div>
		</div>
	</div>

</footer>