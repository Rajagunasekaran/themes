<?php 
	$prev_post = get_adjacent_post( false, '', true );
	$next_post = get_adjacent_post( false, '', false );
	
	if( empty( $prev_post ) && empty( $next_post ) ){
		return false;
	}
?>

<section class="project-nav">
	<div class="container">
		<nav>
			<ul class="row">
				
				<?php if( !empty( $prev_post ) ) : ?>
					<li class="page-prev col-xs-4">
						<a href="<?php echo esc_url( get_permalink( $prev_post->ID ) ); ?>">
							<i class="icon-Left-2"></i><?php esc_html_e( 'Prev', 'gaze' ); ?>
						</a>
					</li>
				<?php endif; ?>
				
				<li class="back-to-projects col-xs-4">
					<a href="<?php echo get_post_type_archive_link( 'portfolio' ); ?>"><?php esc_html_e( 'All Works', 'gaze' ); ?></a>
				</li>
				
				<?php if( !empty( $next_post ) ) : ?>
					<li class="page-next col-xs-4">
						<a href="<?php echo esc_url( get_permalink( $next_post->ID ) ); ?>">
							<?php esc_html_e( 'Next', 'gaze' ); ?><i class="icon-Right-2"></i>
						</a>
					</li>
				<?php endif; ?>
				
			</ul>
		</nav>
	</div>
</section>