<?php
	$sub_header_email     = get_option( 'sub_header_email', 'first.last@email.com' );
	$sub_header_telephone = get_option( 'sub_header_telephone', '+00 (123) 456 78 90' );
?>

<div class="top-bar hidden-xs">
	<div class="container">
		<div class="row">
			<div class="top-bar-links">
			
				<ul class="col-sm-7">
					
					<?php if( $sub_header_telephone ) : ?>
						<li class="top-bar-phone">
							<i class="fa fa-phone"></i>
							<a href="tel:<?php echo esc_attr( $sub_header_telephone ); ?>"><?php echo esc_html( $sub_header_telephone ); ?></a>
						</li>
					<?php endif; ?>
					
					<?php if( $sub_header_email) : ?>
						<li class="top-bar-email">
							<i class="fa fa-envelope"></i>
							<a href="<?php echo esc_url( $sub_header_email ); ?>"><?php echo esc_html( $sub_header_email ); ?></a>
						</li>   
					<?php endif; ?>	
					
				</ul>
				
				<div class="col-sm-5 social-icons nobase text-right">
					<?php 
						for( $i = 1; $i < 6; $i++ ){
							if( $url = get_option( "header_social_url_$i" ) ) {
								echo '
									<a href="'. esc_url( $url ) .'" target="_blank">
										<i class="fa '. esc_attr( get_option( "header_social_icon_$i" ) ) .'"></i>
									</a>
								';
							}
						} 
					?>
				</div>
			
			</div>
		</div>
	</div>
</div>