<header class="nav-type-5 sticky-on-mobile">

	<?php get_template_part( 'inc/content-header', 'search-full' ); ?>
	
	<nav class="navbar navbar-fixed-top">
		
		<div class="fs-menu" id="nav-overlay">
			<div class="overlay-menu">
				<?php
					if ( has_nav_menu( 'primary' ) ){
						
						wp_nav_menu( 
							array(
							    'theme_location'    => 'primary',
							    'depth'             => 1,
							    'container'         => false,
							    'container_class'   => false,
							    'menu_class'        => '',
							    'menu_id'           => false
							)
						);
						
					} else {
						
						echo '<ul><li><a href="'. admin_url('nav-menus.php') .'">Set up a navigation menu now</a></li></ul>';
						
					}
				?>
			</div>
		</div>
		
		<div class="navigation-overlay" id="sticky-nav">
			<div class="container-fluid semi-fluid relative clearfix">
				<div class="row">
				
					<div class="left"><?php get_template_part( 'inc/content-header', 'logo' ); ?></div>
					
					<div class="nav-icon-wrap right">
						<div id="nav-icon" class="style-2">
							<div class="nav-icon-inner">
								<a href="#" id="nav-icon-trigger-2" class="nav-icon-trigger">
									<span></span>
									<span></span>
									<span></span>
									<span></span>
								</a>
							</div>
						</div>
					</div>
				
				</div>
			</div> <!-- end container -->
		</div>
		
	</nav>
</header>