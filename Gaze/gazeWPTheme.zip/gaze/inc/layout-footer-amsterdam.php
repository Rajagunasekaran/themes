<footer class="footer footer-type-4 bg-white">
	<?php get_template_part( 'inc/content-footer', 'widgets' ); ?>
</footer> <!-- end footer -->