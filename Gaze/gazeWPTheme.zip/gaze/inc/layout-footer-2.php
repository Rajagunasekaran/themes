<footer class="footer footer-type-2 angle-top bg-dark">
	<div class="container">
		<div class="footer-widgets">
			<div class="row">
				<div class="col-md-4 col-md-offset-4 text-center">
					<div class="copyright">
						<?php get_template_part( 'inc/content-footer', 'copyright' ); ?>
					</div>
					<div class="footer-socials mt-10">
						<div class="social-icons text-center">
						<?php 
								for( $i = 1; $i < 6; $i++ ){
									if( $url = get_option("footer_social_url_$i") ) {
										echo '<a href="' . esc_url( $url ) . '" target="_blank"><i class="fa ' . esc_attr( get_option( "footer_social_icon_$i" ) ) . '"></i></a>';
									}
								} 
							?>
						</div>
					</div>
					<?php get_template_part( 'inc/content', 'back-to-top' ); ?>
				</div>
			</div>
		</div>
	</div>
</footer>