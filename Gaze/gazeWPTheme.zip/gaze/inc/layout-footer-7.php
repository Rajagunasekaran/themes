<footer class="footer footer-type-7 bg-white">
	<div class="container">
		<div class="footer-widgets top-divider pb-mdm-20">
			<div class="row">
			
				<div class="col-sm-6 copyright sm-text-center">
					<?php get_template_part( 'inc/content-footer', 'copyright' ); ?>
				</div>
				
				<div class="col-sm-6">
					<div class="footer-socials">
						<?php get_template_part( 'inc/content-footer', 'social-icons' ); ?>
					</div>
				</div>
			
			</div>
		</div>    
	</div>
</footer>