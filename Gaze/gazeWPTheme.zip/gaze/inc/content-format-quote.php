<div class="entry blockquote">
	<blockquote class="blockquote-style-1">
		<?php get_template_part( 'inc/content-post', 'meta' ); ?>
		<p><a href="<?php the_permalink(); ?>">"<?php echo get_the_content(); ?>"</a></p>
		<?php the_title( '<span>', '</span>' ); ?>
	</blockquote>
</div>