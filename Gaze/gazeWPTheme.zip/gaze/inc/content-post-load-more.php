<?php if( 'yes' == $wp_query->show_loadmore ) { ?>

	<div class="row mt-40">
		<?php echo ebor_blog_load_more(); ?>
	</div>

<?php } ?>