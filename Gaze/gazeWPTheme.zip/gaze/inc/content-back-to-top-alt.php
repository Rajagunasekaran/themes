<?php if( get_option( 'show_btt', 'yes' ) == 'yes' ) : ?>

	<div id="back-to-top" class="fixed-in-footer style-2">
		<a href="#top"><?php echo esc_html__( 'Back to Top', 'gaze' );  ?></a>
	</div>

<?php endif;