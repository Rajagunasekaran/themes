<?php
	if ( has_nav_menu( 'primary' ) ){
		
		wp_nav_menu( 
			array(
			    'theme_location'    => 'primary',
			    'depth'             => 3,
			    'container'         => false,
			    'container_class'   => false,
			    'menu_class'        => 'nav navbar-nav navbar-right',
			    'menu_id'           => false,
			    'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
			    'items_wrap'        => '<ul class="%2$s">%3$s</ul>',
			    'walker'            => new ebor_bootstrap_navwalker()
			)
		);
		
	} else {
		
		echo '<ul class="nav navbar-nav navbar-right"><li><a href="'. admin_url('nav-menus.php') .'">Set up a navigation menu now</a></li></ul>';
		
	}