<header class="nav-type-4">

	<?php get_template_part( 'inc/content-header', 'search-full' ); ?>
	
	<nav class="navbar">
		<div class="container header-wrap relative">
			<div class="row">
			
				<div class="navbar-header">
					<?php 
						get_template_part( 'inc/content-header', 'hamburger' ); 
						get_template_part( 'inc/content-header', 'logo' ); 
					?>
				</div> <!-- end navbar-header -->
				
				<div class="nav-wrap">
					<div class="collapse navbar-collapse" id="navbar-collapse">
						<?php
							if ( has_nav_menu( 'primary' ) ){
								
								wp_nav_menu( 
									array(
									    'theme_location'    => 'primary',
									    'depth'             => 3,
									    'container'         => false,
									    'container_class'   => false,
									    'menu_class'        => 'nav navbar-nav',
									    'menu_id'           => false,
									    'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
									    'items_wrap'        => '<ul class="%2$s">%3$s</ul>',
									    'walker'            => new ebor_bootstrap_navwalker()
									)
								);
								
							} else {
								
								echo '<ul class="nav navbar-nav"><li><a href="'. admin_url('nav-menus.php') .'">Set up a navigation menu now</a></li></ul>';
								
							}
						?>
					</div>
				</div> <!-- end col -->
				
				<div class="col-xs-12 hidden-sm hidden-xs">
					<div class="social-icons rounded clearfix">
						<?php 
							for( $i = 1; $i < 6; $i++ ){
								if( $url = get_option("header_social_url_$i") ) {
									echo '<a href="' . esc_url( $url ) . '" target="_blank"><i class="fa ' . esc_attr( get_option( "header_social_icon_$i" ) ) . '"></i></a>';
								}
							} 
						?>
					</div>
				</div>
			
			</div>
		</div> <!-- end container -->
	</nav> <!-- end navbar -->
</header>