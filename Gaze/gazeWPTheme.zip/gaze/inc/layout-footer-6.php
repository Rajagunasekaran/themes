<footer class="footer footer-type-6 bg-white">
	<div class="container">
		<div class="footer-widgets pb-mdm-20">
			
			<div class="row">
				<?php
					if( is_active_sidebar('footer1') && !( is_active_sidebar('footer2') ) && !( is_active_sidebar('footer3') ) ){
						echo '<div class="col-sm-12 text-center">';
							dynamic_sidebar('footer1');
						echo '</div>';
					}
						
					if( is_active_sidebar('footer2') && !( is_active_sidebar('footer3') ) ){
						echo '<div class="col-sm-6 col-xs-12 text-center">';
							dynamic_sidebar('footer1');
						echo '</div><div class="col-sm-6 col-xs-12 text-center">';
							dynamic_sidebar('footer2');
						echo '</div><div class="clear"></div>';
					}
						
					if( is_active_sidebar('footer3') ){
						echo '<div class="col-md-4 col-sm-6 col-xs-12 text-center">';
							dynamic_sidebar('footer1');
						echo '</div><div class="col-md-4 col-sm-6 col-xs-12 text-center">';
							dynamic_sidebar('footer2');
						echo '</div><div class="col-md-4 col-sm-6 col-xs-12 text-center">';
							dynamic_sidebar('footer3');
						echo '</div><div class="clear"></div>';
					}
				?>
			</div>

			<div class="row text-center mt-30">
				<div class="footer-socials style-2">
					<div class="social-icons text-center">
						<?php 
							for( $i = 1; $i < 6; $i++ ){
								if( $url = get_option("footer_social_url_$i") ) {
									echo '<a href="' . esc_url( $url ) . '" target="_blank"><i class="fa ' . esc_attr( get_option( "footer_social_icon_$i" ) ) . '"></i></a>';
								}
							} 
						?>
					</div>
				</div>
			</div>

		</div>    
	</div>
</footer>