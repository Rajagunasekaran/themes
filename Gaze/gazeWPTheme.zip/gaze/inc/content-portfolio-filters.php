<?php $cats = get_categories( 'taxonomy=portfolio_category' ); ?>

<div class="row">
	<div class="col-sm-12">
		<div class="portfolio-filter text-center">
			<div class="portfolio-filter-wrap">
				<a href="#" class="filter active" data-filter="*"><?php esc_html_e( 'All', 'gaze' ); ?></a>
				<?php
					if( is_array( $cats  )){
						foreach( $cats as $cat ){
							echo '<a href="#" data-filter=".'. esc_attr( $cat->slug ) .'" class="filter">'. $cat->name .'</a>';
						}
					}
				?>
			</div>
		</div>
	</div>
</div>