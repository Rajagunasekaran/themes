<div class="loader-mask">
	<div class="loader">
		<div></div>
		<div></div>
	</div>
</div>