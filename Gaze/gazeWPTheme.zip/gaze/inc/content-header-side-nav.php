<?php if( is_active_sidebar( 'side_nav' ) ) : ?>

<section class="sidenav">
	
	<?php dynamic_sidebar( 'side_nav' ); ?>
	
	<a href="#" id="sidenav-close">
		<i class="ui-close"></i>
	</a>
	
</section>

<?php endif;