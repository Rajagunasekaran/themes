<?php $url = get_option( 'theme_logo', get_theme_file_uri( '/style/img/logo_light.png' ) ); ?>

<footer class="footer bg-dark text-center">

	<div class="container">
		<div class="footer-widgets">
			<div class="row">

				<div class="col-md-4 col-md-offset-4 text-center">

					<div class="widget footer-logo mb-20">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
							<img class="logo-light" src="<?php echo esc_url( $url ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'title' ) ); ?>">
						</a>
					</div>

					<div class="footer-socials">
						<div class="social-icons nobase dark text-center">
						<?php 
							for( $i = 1; $i < 6; $i++ ){
								if( $url = get_option("footer_social_url_$i") ) {
									echo '<a href="' . esc_url( $url ) . '" target="_blank"><i class="fa ' . esc_attr( get_option( "footer_social_icon_$i" ) ) . '"></i></a>';
								}
							} 
						?>
						</div>
					</div>

					<div class="copyright mt-40">
						<?php get_template_part( 'inc/content-footer', 'copyright' ); ?>
					</div>
				</div>

			</div>
		</div>    
	</div>

</footer>