<header class="nav-type-7 transparent dark">

	<?php get_template_part( 'inc/content-header', 'search-full' ); ?>
	
	<nav class="navbar navbar-static-top">
		<div class="navigation" id="sticky-nav">
			<div class="container-fluid semi-fluid relative">
				<div class="row flex-parent">
				
					<div class="navbar-header flex-child">
						<?php 
							get_template_part( 'inc/content-header', 'logo' ); 
							get_template_part( 'inc/content-header', 'hamburger' ); 
						?>
					</div> <!-- end navbar-header -->
					
					<div class="nav-wrap flex-child">
						<div class="collapse navbar-collapse text-center" id="navbar-collapse">
							<?php
								if ( has_nav_menu( 'primary' ) ){
									
									wp_nav_menu( 
										array(
										    'theme_location'    => 'primary',
										    'depth'             => 3,
										    'container'         => false,
										    'container_class'   => false,
										    'menu_class'        => 'nav navbar-nav',
										    'menu_id'           => false,
										    'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
										    'items_wrap'        => '<ul class="%2$s">%3$s</ul>',
										    'walker'            => new ebor_bootstrap_navwalker()
										)
									);
									
								} else {
									
									echo '<ul class="nav navbar-nav"><li><a href="'. admin_url('nav-menus.php') .'">Set up a navigation menu now</a></li></ul>';
									
								}
							?>
						</div> <!-- end collapse -->
					</div> <!-- end col -->
					
					<div class="flex-child flex-right hidden-sm hidden-xs">
						<div class="nav-social-icons right">
							<div class="social-icons dark nobase">
								<?php 
									for( $i = 1; $i < 6; $i++ ){
										if( $url = get_option("header_social_url_$i") ) {
											echo '<a href="' . esc_url( $url ) . '" target="_blank"><i class="fa ' . esc_attr( get_option( "header_social_icon_$i" ) ) . '"></i></a>';
										}
									} 
								?>
							</div>
						</div>
					</div>
				
				</div> <!-- end row -->
			</div> <!-- end container -->
		</div> <!-- end navigation -->
	</nav> <!-- end navbar -->
</header>