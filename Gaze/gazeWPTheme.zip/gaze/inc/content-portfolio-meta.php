<?php 
	$additional = get_post_meta( $post->ID, '_ebor_meta_repeat_group', true ); 
	
	if( $additional ) :
?>

<hr>

<div class="product_meta">
	<?php 
		foreach( $additional as $index => $item ){
		
			echo '<div class="detail-wrap"><span class="detail-label">';
			
			if( isset( $item['_ebor_the_additional_title'] ) ){
				echo wp_kses_post( $item['_ebor_the_additional_title'] );
			}
				
			echo '</span><span class="detail-value">';
			
			if( isset( $item['_ebor_the_additional_detail'] ) ){
				echo wp_kses_post( $item['_ebor_the_additional_detail'] );
			}
				
			echo '</span></div>';
		}
	?>
</div>

<?php endif;