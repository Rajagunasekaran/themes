<div class="search-wrap">
	<div class="search-inner">
		<div class="search-cell">
			<?php get_search_form(); ?>
		</div>
	</div>
</div>