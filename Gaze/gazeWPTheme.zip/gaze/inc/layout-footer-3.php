<footer class="footer footer-type-3 bg-light">
   
  <?php get_template_part( 'inc/content-footer', 'widgets' ); ?>

  <div class="bottom-footer bg-white">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 copyright text-center">
          <?php get_template_part( 'inc/content-footer', 'copyright' ); ?>
        </div>
      </div>
    </div>
  </div> <!-- end bottom footer -->

</footer> <!-- end footer -->