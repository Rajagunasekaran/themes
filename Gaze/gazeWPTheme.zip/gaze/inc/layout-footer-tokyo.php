<footer class="footer footer-type-1 bg-dark">

	<?php get_template_part( 'inc/content-footer', 'widgets' ); ?>

	<div class="bottom-footer">
		<div class="container">
			<div class="row">              

				<div class="col-sm-6">
					<?php
						if ( has_nav_menu( 'footer' ) ){
							
							wp_nav_menu( 
								array(
								    'theme_location'    => 'footer',
								    'depth'             => 1,
								    'container'         => false,
								    'container_class'   => false,
								    'menu_class'        => 'bottom-footer-links sm-text-center',
								    'menu_id'           => false
								)
							);
							
						}
					?>
				</div>

				<div class="col-sm-6 copyright text-right sm-text-center">
					<?php get_template_part( 'inc/content-footer', 'copyright' ); ?>
				</div>

			</div>
		</div>
	</div> <!-- end bottom footer -->

</footer>