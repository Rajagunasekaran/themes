<div class="social-icons text-right sm-text-center">
	<?php 
		for( $i = 1; $i < 6; $i++ ){
			if( $url = get_option("footer_social_url_$i") ) {
				echo '<a href="' . esc_url( $url ) . '" target="_blank"><i class="fa ' . esc_attr( get_option( "footer_social_icon_$i" ) ) . '"></i></a>';
			}
		} 
	?>
</div>