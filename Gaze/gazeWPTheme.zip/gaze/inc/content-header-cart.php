<?php
	if(!( class_exists( 'woocommerce' ) )){
		return false;
	}
	
	global $woocommerce;
?>

<div class="nav-right hidden-sm hidden-xs">
	<ul>
		
		<li class="nav-register">
			<a href="<?php echo esc_url( wp_login_url() ); ?>"><?php esc_html_e( 'Log In / Register', 'gaze' ); ?></a>
		</li>
		
		<li class="nav-search-wrap style-2 hidden-sm hidden-xs">
			<a href="#" class="nav-search search-trigger">
				<i class="ui-search"></i>
			</a>
		</li>
		
		<li class="nav-cart">
			
			<div class="nav-cart-outer">
				<div class="nav-cart-inner">
					<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="nav-cart-icon">
						<span class="nav-cart-badge"><?php echo esc_html( $woocommerce->cart->get_cart_contents_count() ); ?></span>
					</a>
				</div>
			</div>
			
			<div class="nav-cart-container">
				
				<div class="nav-cart-items">
					
					<?php foreach ($woocommerce->cart->cart_contents as $cart_item_key => $cart_item) : ?>
					
						<?php $_product = $cart_item['data']; ?>
						
						<div class="nav-cart-item clearfix">
							<div class="nav-cart-img">
								<a href="<?php echo get_permalink( $cart_item['product_id'] ); ?>">
									<?php echo get_the_post_thumbnail( $cart_item['product_id'], 'shop_thumbnail' ); ?>
								</a>
							</div>
							<div class="nav-cart-title">
								<a href="<?php echo get_permalink( $cart_item['product_id'] ); ?>">
									<?php echo get_the_title( $cart_item['product_id'] ); ?>
								</a>
								<div class="nav-cart-price">
									<span><?php echo esc_html( $cart_item['quantity'] ); ?> x</span>
									<span><?php echo wc_price($_product->get_price()); ?></span>
								</div>
							</div>
						</div>
					    
					<?php endforeach; ?>

				</div>

				<div class="nav-cart-summary">
					<span><?php esc_html_e( 'Cart Subtotal', 'gaze' ); ?></span>
					<span class="total-price"><?php echo wp_specialchars_decode( $woocommerce->cart->get_cart_total() ); ?></span>
				</div>
				
				<div class="nav-cart-actions mt-20">
					<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="btn btn-md btn-dark">
						<span><?php esc_html_e( 'View Cart', 'gaze' ); ?></span>
					</a>
					<a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="btn btn-md btn-color mt-10">
						<span><?php esc_html_e( 'Proceed to Checkout', 'gaze' ); ?></span>
					</a>
				</div>
				
			</div>
		</li>
		
	</ul>
</div>