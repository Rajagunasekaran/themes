<?php

$videos = get_post_meta( $post->ID, '_ebor_the_oembed', true );

if( $videos ){
	echo '<div class="entry-video video-wrap">' . wp_oembed_get( esc_url( $videos ) ) . '</div>';
}