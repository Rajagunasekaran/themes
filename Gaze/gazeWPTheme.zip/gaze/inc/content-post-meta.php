<ul class="entry-meta">
	
	<?php if( is_sticky() ) : ?>
	
		<li class="entry-date">
			<i class="fa fa-link"></i>
			<?php esc_html_e( 'Featured Post', 'gaze' ); ?>
		</li>
		
	<?php endif; ?>
	
	<li class="entry-date">
		<i class="fa fa-calendar-o"></i>
		<?php the_time( get_option( 'date_format' ) ); ?>
	</li>
	
	<li class="entry-author">
		<i class="fa fa-user"></i>
		<?php the_author_link(); ?>
	</li> 
	
	<li class="entry-category">
		<i class="fa fa-folder-open"></i>
		<?php the_category( ', ' ); ?>
	</li>  
	
	<li class="entry-comments">
		<i class="fa fa-comment"></i>
		<a href="<?php the_permalink(); ?>">
			<?php 
				comments_number( 
					esc_html__( '0 Comments', 'gaze' ), 
					esc_html__( '1 Comment', 'gaze' ), 
					esc_html__( '% Comments', 'gaze' ) 
				); 
			?>
		</a>
	</li>  
	
</ul>  