<header class="nav-type-5">

	<?php get_template_part( 'inc/content-header', 'search-full' ); ?>
	
	<nav class="navbar navbar-static-top">
		
		<div class="fs-menu" id="nav-overlay">
			<div class="overlay-menu">
				<?php
					if ( has_nav_menu( 'primary' ) ){
						
						wp_nav_menu( 
							array(
							    'theme_location'    => 'primary',
							    'depth'             => 1,
							    'container'         => false,
							    'container_class'   => false,
							    'menu_class'        => '',
							    'menu_id'           => false
							)
						);
						
					} else {
						
						echo '<ul><li><a href="'. admin_url('nav-menus.php') .'">Set up a navigation menu now</a></li></ul>';
						
					}
				?>
			</div>
		</div>
		
		<div class="navigation-overlay">
			<div class="container relative clearfix">
				<div class="row">
					
					<div class="nav-social-icons left">
						<div class="social-icons nobase dark">
							<?php 
								for( $i = 1; $i < 6; $i++ ){
									if( $url = get_option("header_social_url_$i") ) {
										echo '<a href="' . esc_url( $url ) . '" target="_blank"><i class="fa ' . esc_attr( get_option( "header_social_icon_$i" ) ) . '"></i></a>';
									}
								} 
							?>
						</div>
					</div>
					
					<div class="position-center">
						<div class="logo-container">
							<div class="logo-wrap">
								<?php get_template_part( 'inc/content-header', 'logo' ); ?>
							</div>
						</div>
					</div>
					
					<div class="nav-icon-wrap right">
						<div id="nav-icon" class="style-2">
							<div class="nav-icon-inner">
								<a href="#" id="nav-icon-trigger-2" class="nav-icon-trigger">
									<span></span>
									<span></span>
									<span></span>
									<span></span>
								</a>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
	</nav>
</header>