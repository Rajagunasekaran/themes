<?php if( get_option( 'show_btt', 'yes' ) == 'yes' ) : ?>

	<div id="back-to-top">
		<a href="#top"><i class="fa fa-angle-up"></i></a>
	</div>

<?php endif;