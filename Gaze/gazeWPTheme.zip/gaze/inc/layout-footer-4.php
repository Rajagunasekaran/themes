<footer class="footer footer-type-4 bg-dark">

	<?php get_template_part( 'inc/content-footer', 'widgets' ); ?>

	<div class="bottom-footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 copyright text-center">
					<?php get_template_part( 'inc/content-footer', 'copyright' ); ?>
				</div>
			</div>
		</div>
	</div> <!-- end bottom footer -->
</footer> <!-- end footer -->