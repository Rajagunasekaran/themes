<header class="nav-type-1 transparent sticky-on-mobile">

	<?php get_template_part( 'inc/content-header', 'search-full' ); ?>
	
	<nav class="navbar navbar-fixed-top">
		<div class="navigation" id="sticky-nav">
			<div class="container-fluid semi-fluid relative">
				<div class="row">
					
					<div class="navbar-header">
						<?php 
							get_template_part( 'inc/content-header', 'hamburger' ); 
							get_template_part( 'inc/content-header', 'logo-light' ); 
						?>
					</div> <!-- end navbar-header -->
					
					<div class="nav-wrap right">
						<div class="collapse navbar-collapse text-center" id="navbar-collapse">
							<?php
								if ( has_nav_menu( 'primary' ) ){
									
									wp_nav_menu( 
										array(
										    'theme_location'    => 'primary',
										    'depth'             => 3,
										    'container'         => false,
										    'container_class'   => false,
										    'menu_class'        => 'nav navbar-nav',
										    'menu_id'           => false,
										    'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
										    'items_wrap'        => '<ul class="%2$s">%3$s</ul>',
										    'walker'            => new ebor_bootstrap_navwalker()
										)
									);
									
								} else {
									
									echo '<ul class="nav navbar-nav"><li><a href="'. admin_url('nav-menus.php') .'">Set up a navigation menu now</a></li></ul>';
									
								}
							?>
						</div> <!-- end collapse -->
					</div> <!-- end col -->         
				
				</div> <!-- end row -->
			</div> <!-- end container -->
		</div> <!-- end navigation -->
	</nav> <!-- end navbar -->
</header>