<?php get_header(); ?>

<section class="section-wrap page-404">
	<div class="container">
		<div class="row text-center">
			<div class="col-md-6 col-md-offset-3">
				
				<h1><?php esc_html_e( '404', 'gaze' ); ?></h1>
				
				<h2 class="mb-30"><?php esc_html_e( 'Oops... Page Not Found', 'gaze' ); ?></h2>
				
				<p class="mb-20">
					<?php esc_html_e( 'You can go back to', 'gaze' ); ?> 
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Homepage', 'gaze' ); ?></a> 
					<?php esc_html_e( 'or use search', 'gaze' ); ?>
				</p>
				
				<?php get_search_form(); ?>
				
			</div>
		</div>
	</div>
</section>

<?php get_footer();