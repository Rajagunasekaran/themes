<?php 

/**
 * Define theme folder URL, saves querying the template directory multiple times.
 */
define('EBOR_THEME_DIRECTORY', trailingslashit( get_template_directory_uri() ));
define('EBOR_REQUIRE_DIRECTORY', trailingslashit( get_template_directory() ));

require_once get_parent_theme_file_path( '/admin/theme_layouts.php' );
require_once get_parent_theme_file_path( '/admin/theme_functions.php' );
require_once get_parent_theme_file_path( '/admin/theme_filters.php' );
require_once get_parent_theme_file_path( '/admin/theme_menus_widgets.php' );
require_once get_parent_theme_file_path( '/admin/theme_support.php' );
require_once get_parent_theme_file_path( '/admin/theme_scripts.php' );
require_once get_parent_theme_file_path( '/admin/theme_options.php' );

/**
 * Some parts of the framework only need to run on admin views.
 * These would be those.
 * Calling these only on admin saves some operation time for the theme, everything in the name of speed.
 */
if( is_admin() ){
	if (!( class_exists( 'TGM_Plugin_Activation' ) )){
		require_once get_parent_theme_file_path( '/admin/class-tgm-plugin-activation.php' );
	}
		
	require_once get_parent_theme_file_path( '/admin/theme_metaboxes.php' );
}

/**
 * If visual composer is installed, grab all required files.
 * Wrapped in an if statement so that we can save parsing this if visual composer is not used.
 * It's a speed boost basically.
 */
if( function_exists( 'vc_set_as_theme' ) ){
	require_once get_parent_theme_file_path( '/vc_init.php' );
}

if( class_exists( 'woocommerce' ) ){
	require_once get_parent_theme_file_path( '/woocommerce_init.php' );
}