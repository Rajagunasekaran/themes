<?php 
	get_header(); 
	
	$total_results = $wp_query->found_posts;
	$items         = ( $total_results == '1' ) ? esc_html__( ' item.', 'gaze' ) : esc_html__( ' items.', 'gaze' );
	
	ebor_page_title( 
		get_search_query() . ', ' . $total_results . $items, 
		get_option( 'blog_image', '' ) 
	);
?>

<section class="section-wrap-sm blog-standard bg-light pb-50">
	<div class="container relative">
		<?php get_template_part( 'loop/loop-post', get_option( 'blog_layout', 'standard' ) ); ?>
	</div>
</section>
	
<?php get_footer();