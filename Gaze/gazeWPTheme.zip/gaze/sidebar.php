<?php if( is_active_sidebar( 'primary' ) ) : ?>

	<aside class="col-md-3 sidebar">
		<?php dynamic_sidebar( 'primary' ); ?>
	</aside>
	
<?php endif;