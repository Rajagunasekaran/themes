<?php 
	get_header();
	the_post();
	
	$layout = get_post_meta( $post->ID, '_ebor_portfolio_layout', 1 );
	
	if( '' == $layout || false == $layout || !( isset( $layout ) ) ){
		$layout = '1';
	}
	
	if( has_post_thumbnail() ){
		ebor_page_title( 
			get_the_title(), 
			get_the_post_thumbnail_url( $post->ID, 'full' ) 
		);
	}
	
	get_template_part( 'inc/layout-portfolio-single', $layout );
	
	get_footer();