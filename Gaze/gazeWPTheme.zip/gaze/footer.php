<?php 
	get_template_part( 'inc/layout-footer', ebor_get_footer_layout() );
	get_template_part( 'inc/content', 'back-to-top' ); 
?>

</div><!-- end content wrapper -->
</div><!-- end main wrapper -->

<?php wp_footer(); ?>
</body>
</html>