<?php 

/**
 * Build theme options
 * Uses the Ebor_Options class found in the ebor-framework plugin
 * Panels are WP 4.0+!!!
 * 
 * @since 1.0.0
 * @author tommusrhodus
 */
if( class_exists('Ebor_Options') ){
	
	$social_options = array_values(ebor_get_social_icons());
	$ebor_options = new Ebor_Options;
	$theme = wp_get_theme();
	$theme_name = $theme->get( 'Name' );
	$yesNo = array('yes' => 'Yes', 'no' => 'No');
	$header_options = ebor_get_header_options();
	$footer_layouts = ebor_get_footer_options();
	$blog_options = array_flip(ebor_get_blog_layouts());
	$portfolio_options = array_flip(ebor_get_portfolio_layouts());
	$team_options = array_flip(ebor_get_team_layouts());

	foreach( $social_options as $social_option ){
		$final_social_options[$social_option] = str_replace('sa-', '', $social_option);
	}
	
	$ebor_options->add_panel( $theme_name . ': Header Settings', 215, 'All of the controls in this section directly relate to the header and logos of ' . $theme_name);
	
	//Header Settings
	$ebor_options->add_section('logo_settings_section', 'Logo Settings', 10, $theme_name . ': Header Settings');
	
	//Logo Options
	$ebor_options->add_setting('image', 'theme_logo', 'Logo', 'logo_settings_section', EBOR_THEME_DIRECTORY . 'style/img/logo_dark.png', 5);
	$ebor_options->add_setting('image', 'theme_logo_light', 'Light Logo', 'logo_settings_section', EBOR_THEME_DIRECTORY . 'style/img/logo_light.png', 5);

	$ebor_options->add_section('header_layout_section', 'Layout Settings', 10, $theme_name . ': Header Settings', '<strong>Please Note:</strong> Your choice here will not affect every page if you installed our demo data. Some of our installed demo data pages, specifically the homepages, have a header override set.');
	$ebor_options->add_setting('select', 'header_layout', 'Global Header Layout', 'header_layout_section', '1', 20, $header_options);
	$ebor_options->add_setting('select', 'show_search', 'Show search in menu? (applicable layouts only)', 'header_layout_section', 'yes', 25, $yesNo);
	$ebor_options->add_setting('select', 'show_sidebar_toggle', 'Show sidebar toggle in menu? (applicable layouts only)', 'header_layout_section', 'yes', 30, $yesNo);
	
	//header Icons
	$ebor_options->add_section('header_social_section', 'Social Settings', 10, $theme_name . ': Header Settings');
	for( $i = 1; $i < 6; $i++ ){
		$ebor_options->add_setting('select', 'header_social_icon_' . $i, 'Header Social Icon ' . $i, 'header_social_section', 'none', 20 + $i + $i, $final_social_options);
		$ebor_options->add_setting('input', 'header_social_url_' . $i, 'Header Social URL ' . $i, 'header_social_section', '', 21 + $i + $i);
	}

	//Top Bar Settings
	$ebor_options->add_section('header_top_bar_section', 'Top Bar Settings', 20, $theme_name . ': Header Settings');
	$ebor_options->add_setting('input', 'sub_header_email', 'Email Address', 'header_top_bar_section', 'first.last@email.com', 10);
	$ebor_options->add_setting('input', 'sub_header_telephone', 'Telephone Number', 'header_top_bar_section', '+00 (123) 456 78 90', 15);

	//Team options
	$ebor_options->add_panel( $theme_name . ': Team Settings', 215, 'All of the controls in this section directly relate to team area of ' . $theme_name);
	$ebor_options->add_section('team_archive_section', 'Team Archive Settings', 15, $theme_name . ': Team Settings');
	$ebor_options->add_setting('select', 'team_layout', 'Global Team Layout', 'team_archive_section', '4-col', 5, $team_options);
	$ebor_options->add_setting('input', 'team_title', 'Team Title', 'team_archive_section', 'Our Team', 10);
	$ebor_options->add_setting('image', 'team_image', 'Team Title Background Image', 'team_archive_section', '', 15);

	//Colours
	$ebor_options->add_setting('color', 'colour_accent', 'Accent Colour', 'colors', '#4be1ce', 5);

	/**
	 * All Portfolio Settings
	 */
	$ebor_options->add_panel( $theme_name . ': Portfolio Settings', 220, 'All of the controls in this section directly relate to the control of Portfolio items within ' . $theme_name);
	
	/**
	 * Portfolio Archive settings
	 */
	$ebor_options->add_section('portfolio_archive_section', 'Portfolio Archive Settings', 15, $theme_name . ': Portfolio Settings');
	$ebor_options->add_setting('select', 'portfolio_layout', 'Global Portfolio Layout', 'portfolio_archive_section', '4-col', 5, $portfolio_options);
	$ebor_options->add_setting('input', 'portfolio_title', 'Portfolio Title', 'portfolio_archive_section', 'Our Portfolio', 10);
	$ebor_options->add_setting('image', 'portfolio_image', 'Portfolio Title Background Image', 'portfolio_archive_section', '', 15);
	
	//Blog Settings
	$ebor_options->add_panel( $theme_name . ': Blog Settings', 215, 'All of the controls in this section directly relate to blog area of ' . $theme_name);
	$ebor_options->add_section('blog_archive_section', 'Blog Archive Settings', 15, $theme_name . ': Blog Settings');
	$ebor_options->add_setting('select', 'blog_layout', 'Global Blog Layout', 'blog_archive_section', 'standard', 5, $blog_options);
	$ebor_options->add_setting('input', 'blog_title', 'Blog Title', 'blog_archive_section', 'Our Blog', 10);
	$ebor_options->add_setting('image', 'blog_image', 'Blog Title Background Image', 'blog_archive_section', '', 15);

	$ebor_options->add_section('single_post_section', 'Single Post Settings', 15, $theme_name . ': Blog Settings');	
	$ebor_options->add_setting('select', 'show_sharing', 'Show sharing buttons?', 'single_post_section', 'yes', 10, $yesNo);
	$ebor_options->add_setting('select', 'show_author', 'Show author info?', 'single_post_section', 'yes', 10, $yesNo);
	
	$ebor_options->add_panel( $theme_name . ': Footer Settings', 245, 'All of the controls in this section directly relate to the control of footer design within ' . $theme_name);
	$ebor_options->add_section('footer_social_settings_section', 'Footer Social Settings', 20, $theme_name . ': Footer Settings');
	
	$ebor_options->add_section('footer_settings_section', 'Footer Settings', 30, $theme_name . ': Footer Settings');
	$ebor_options->add_setting('select', 'footer_layout', 'Global Footer Layout', 'footer_settings_section', '1', 5, $footer_layouts);
	
	//Footer Icons
	for( $i = 1; $i < 6; $i++ ){
		$ebor_options->add_setting('select', 'footer_social_icon_' . $i, 'Footer Social Icon ' . $i, 'footer_social_settings_section', 'none', 20 + $i + $i, $final_social_options);
		$ebor_options->add_setting('input', 'footer_social_url_' . $i, 'Footer Social URL ' . $i, 'footer_social_settings_section', '', 21 + $i + $i);
	}
	
	$ebor_options->add_setting('textarea', 'footer_copyright', 'Copyright Message', 'footer_settings_section', '<a href="http://www.tommusrhodus.com">Gaze Premium WordPress Theme by TommusRhodus</a>', 20);
	$ebor_options->add_setting('select', 'show_btt', 'Show back to top link?', 'footer_settings_section', 'yes', 25, $yesNo);
	$ebor_options->add_setting('textarea', 'footer_payment_info', 'Payment Info (Ecommerce Footer)', 'footer_settings_section', '<i class="fa fa-cc-paypal"></i><i class="fa fa-cc-visa"></i><i class="fa fa-cc-mastercard"></i><i class="fa fa-cc-discover"></i><i class="fa fa-cc-amex"></i>', 30);

}