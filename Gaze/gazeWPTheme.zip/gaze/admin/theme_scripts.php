<?php 

/**
 * Fonts URL
 * Load google font families for this theme
 * @since version 1.0
 * @author TommusRhodus
 */ 
if(!( function_exists('ebor_fonts_url') )){
	function ebor_fonts_url(){
	    $font_url = '';

	    /*
	    	Translators: If there are characters in your language that are not supported
	   		by chosen font(s), translate this to 'off'. Do not translate into your own language.
	     */
	    if ( 'off' !== _x( 'on', 'Google font: on or off', 'gaze' ) ) {
	        $font_url = add_query_arg( 'family', urlencode( str_replace('+', ' ', 'Barlow:400,600,700|Roboto:400,400i,700|Noto+Serif:400i') ), "//fonts.googleapis.com/css" );
	    }
	    return $font_url;
	}
}

/**
 * Ebor Load Scripts
 * Properly Enqueues Scripts & Styles for the theme
 * @since version 1.0
 * @author TommusRhodus
 */ 
if(!( function_exists('ebor_load_scripts') )){
	function ebor_load_scripts() {
	
		$theme_data = wp_get_theme();
		$version    = $theme_data->get( 'Version' );
		
		//Enqueue Styles
		wp_enqueue_style( 
			'smpl-themes-google-font', 
			ebor_fonts_url(), 
			array(), 
			$version 
		);
		
		wp_enqueue_style( 
			'bootstrap', 
			get_theme_file_uri( 'style/css/bootstrap.min.css' ), 
			array(), 
			$version 
		);
		
		wp_enqueue_style( 
			'ebor-plugins', 
			get_theme_file_uri( 'style/css/plugins.css' ), 
			array(), 
			$version 
		);
		
		wp_enqueue_style( 
			'ebor-icons', 
			get_theme_file_uri( 'style/css/font-icons.css' ), 
			array(), 
			$version 
		);

		wp_enqueue_style( 
			'ebor-style', 
			get_stylesheet_uri(), 
			array(), 
			$version 
		);
		
		//Enqueue Scripts
		wp_enqueue_script( 
			'bootstrap', 
			get_theme_file_uri( 'style/js/bootstrap.min.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'ebor-fitvids', 
			get_theme_file_uri( 'style/js/fitvids.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'jquery-easing', 
			get_theme_file_uri( 'style/js/easing.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 'images-loaded' );
		
		wp_enqueue_script( 
			'isotope', 
			get_theme_file_uri( 'style/js/isotope.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'jquery-goodshare', 
			get_theme_file_uri( 'style/js/goodshare.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'ebor-appear', 
			get_theme_file_uri( 'style/js/appear.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'ebor-count-to', 
			get_theme_file_uri( 'style/js/countto.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'ebor-easypiechart', 
			get_theme_file_uri( 'style/js/easypiechart.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'ebor-flexslider', 
			get_theme_file_uri( 'style/js/flexslider.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'ebor-localscroll', 
			get_theme_file_uri( 'style/js/localscroll.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'ebor-typed', 
			get_theme_file_uri( 'style/js/typed.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'owl-carousel', 
			get_theme_file_uri( 'style/js/owlcarousel.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'ebor-magnific-popup', 
			get_theme_file_uri( 'style/js/magnific.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'ebor-flickity', 
			get_theme_file_uri( 'style/js/flickity.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'ebor-scroll-reveal', 
			get_theme_file_uri( 'style/js/scrollreveal.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'ebor-final-countdown', 
			get_theme_file_uri( 'style/js/finalcountdown.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'ebor-twitter-post-fetcher', 
			get_theme_file_uri( 'style/js/twitter.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		wp_enqueue_script( 
			'ebor-scripts', 
			get_theme_file_uri( 'style/js/scripts.js' ), 
			array('jquery'), 
			$version, 
			true  
		);
		
		//Enqueue Comments
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}

		$accent_colour  = get_option( 'colour_accent', '#4be1ce' );
		$accent_colour_rgb	= ebor_hex2rgb($accent_colour);
		
		$skin = '
			::-moz-selection {
				color: #fff;
				background: '. $accent_colour .';
			}
			::-webkit-selection {
				color: #fff;
				background: '. $accent_colour .';
			}
			::selection {
				color: #fff;
				background: '. $accent_colour .';
			}
			a, a:focus, blockquote > span, .blockquote-style-1, .dropcap.style-1, .bullets li:before, .arrows i, .checks i, .navbar-nav > li > a:hover, .navbar-nav > .active > a, .navigation.scrolling .navbar-nav > li > a:hover, .navigation.scrolling .navbar-nav > .active > a, .navigation.scrolling .navbar-nav > .active > a:focus, .navigation.scrolling .navbar-nav > .active > a:hover, .navbar-nav > .open > a, .navbar-nav > .open > a:focus, .navbar-nav > .open > a:hover, .nav-right.menu-socials a:hover, .navigation.sticky .nav-btn-holder .btn:hover span, .mobile-links li > a:hover, .nav-cart-title > a:hover, .nav-register a:hover, .sidenav a:hover, .nav-item-submenu li a:hover, .overlay-menu ul li.active > a, .overlay-menu ul li a:hover, #typed, .testimonials .testimonial a, .features-list i, #tweets .tweet a:hover, .service-tabs .nav.nav-tabs > li.active a i, .time-period, .profile table td a:hover, .contact-info a:hover, .entry-meta li a:hover, .entry-title a:hover, .entry .blockquote-style-1 p > a:hover, .pagination .current, .widget.categories ul li a:hover, .work-description h3 a:hover, .project-nav li a:hover, .service-item-box.style-2 i, .service-item-box.style-4 i, .service-item-box.style-5 i, .service-item-box.style-7 i, .service-item-box.arrow-next:after, .lead-heading strong, .accordion .panel-heading > a.minus, .nav.nav-tabs > li.active > a, .nav.nav-tabs > li.active > a:hover, .nav.nav-tabs > li.active > a:focus, .nav.nav-tabs > li > a:hover, .nav.nav-tabs > li > a:focus, .statistic.with-icon i, .product-details .product-title:hover, .product-list-widget a:hover, .single-product .add-to-wishlist a:hover, .product_meta span a:hover, .shop_table .product-name > a:hover, .portfolio-filter.style-2 a.active, .tp-caption.address i, .tp-caption.phone i, .tp-caption.email i, .tp-caption.email a:hover, .intro.style-6 .subtitle, .owl-custom-arrows .prev:hover, .owl-custom-arrows .next:hover {
				color: '. $accent_colour .';
			}
			.bg-color, .loader div, .dropcap.style-2, .highlight, .hero-landing-bg, .newsletter .newsletter-submit.btn, header.transparent .navigation.scrolling #nav-icon:hover span, .navigation.sticky .nav-btn-holder .btn, .nav-cart-remove:hover, .navbar-toggle:focus .icon-bar, .navbar-toggle:hover .icon-bar, #back-to-top:hover, .pagination a:hover, .tags a:hover, .tags.light a:hover, .service-item-box.style-3 .icon-holder, .pricing-table.best:before, .progress-bar, .accordion .panel-heading > a > span, .nav.nav-tabs > li.active:before, .btn.btn-transparent:hover, .btn.btn-white:hover, .btn.btn-stroke:hover, .btn.btn-color, .btn.btn-light:hover, .social-icons:not(.colored) a:hover, .newsletter-submit.btn:hover, .product-img .product-quickview:hover, .product-img .product-actions a:hover, .ui-slider .ui-slider-range, .product-remove .remove:hover, .owl-page.active span, .flickity-page-dots .dot.is-selected, .nav-cart-badge {
				background-color: '. $accent_colour .';
			}
			.btn.btn-color:hover {
				background-color: #2cdcc6;
			}
			.work-item.hover-6 .hover-overlay {
				background-color: rgba('. $accent_colour_rgb .', .75);
			}
			.bottom-line:after, .blockquote-style-2, .navigation.sticky .nav-btn-holder .btn:hover, .underline-link:after, .contact-form.style-2 textarea:focus, .pagination .current, .widget.search .searchbox:focus, .portfolio-filter.style-2 a.active, .tabs-bb .nav.nav-tabs > li.active > a, input[type="text"]:focus, input[type="password"]:focus, input[type="date"]:focus, input[type="datetime"]:focus, input[type="datetime-local"]:focus, input[type="month"]:focus, input[type="week"]:focus, input[type="email"]:focus, input[type="number"]:focus, input[type="search"]:focus, input[type="tel"]:focus, input[type="time"]:focus, input[type="url"]:focus, textarea:focus {
				border-color: '. $accent_colour .';
			}
			@media (max-width: 991px) {
				header.transparent .navbar-nav > .active > a, header.transparent .navbar-nav > .active > a:focus, header.transparent .navbar-nav > .active > a:hover, header.transparent .navbar-nav > li > a:hover, header.transparent .navbar-nav > li > a:focus {
					color: '. $accent_colour .';
				}
				.nav-btn-holder .btn.btn-white {
					background-color: '. $accent_colour .';
				}
			}
		';
		
		wp_add_inline_style( 'ebor-style', $skin );
		
	}
	add_action('wp_enqueue_scripts', 'ebor_load_scripts', 110);
}


if(!( function_exists('ebor_admin_load_scripts') )){
	function ebor_admin_load_scripts(){
	
		wp_enqueue_style( 'ebor-theme-admin-css', EBOR_THEME_DIRECTORY . 'admin/ebor-theme-admin.css' );
		wp_enqueue_style( 'ebor-icons', get_theme_file_uri( 'style/css/font-icons.css' ) );	
		wp_enqueue_script( 'ebor-theme-admin-js', EBOR_THEME_DIRECTORY . 'admin/ebor-theme-admin.js', array('jquery'), false, true );
		
	}
	add_action('admin_enqueue_scripts', 'ebor_admin_load_scripts', 200);
}