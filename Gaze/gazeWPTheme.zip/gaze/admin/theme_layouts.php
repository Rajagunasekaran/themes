<?php 

/**
 * Returns an array of all available portfolio single layouts
 * 
 * @val array
 * @since 1.0.0
 * @package gaze
 * @author TommusRhodus
 */
if(!( function_exists('ebor_get_portfolio_single_layouts') )){
	function ebor_get_portfolio_single_layouts(){
		
		$options = array(
			'Left Content'  => '1',
			'Top Content'   => '2'
		);
		
		if( has_filter('ebor_add_portfolio_single_layouts') ) {
			$options = apply_filters('ebor_add_portfolio_single_layouts', $options);
		}
		
		return $options;
		
	}
}

/**
 * Returns an array of all available blog layouts
 * 
 * @val array
 * @since 1.0.0
 * @package Gaze
 * @author TommusRhodus
 */
if(!( function_exists('ebor_get_blog_layouts') )){
	function ebor_get_blog_layouts(){
		
		$options = array(
			'Standard'           => 'standard',
			'Standard & Sidebar' => 'standard-sidebar',
			'Masonry'            => 'masonry',
			'Masonry & Sidebar'  => 'masonry-sidebar',
			'Grid'               => 'grid',
			'Grid & Sidebar'     => 'grid-sidebar',
			'Carousel'           => 'carousel'
		);
		
		if( has_filter('ebor_add_blog_layouts') ) {
			$options = apply_filters('ebor_add_blog_layouts', $options);
		}
		
		return $options;
		
	}
}

/**
 * Returns an array of all available portfolio layouts
 * 
 * @val array
 * @since 1.0.0
 * @package Gaze
 * @author TommusRhodus
 */
if(!( function_exists('ebor_get_portfolio_layouts') )){
	function ebor_get_portfolio_layouts(){
		
		$options = array(
			'Portfolio w/ Description 1 Column'  => 'description-1-col',
			'Portfolio w/ Description 2 Columns' => 'description-2-col',
			'Masonry'                            => 'masonry',
			'Masonry Wide'                       => 'masonry-wide',
			'Masonry 3 Column'                   => 'vienna',
			'Grid'                               => 'grid',
			'Carousel'                           => 'carousel',
			'Carousel Alt'                       => 'carousel-alt',
			'Carousel Alt with Gutter'			 => 'carousel-alt-gutter',
			'5 Column Portfolio Wide'            => '5-col-wide',
			'4 Column Portfolio'                 => '4-col',
			'4 Column Portfolio w/ Title'        => '4-col-title',
			'4 Column Portfolio Wide'            => '4-col-wide',
			'4 Column Portfolio Wide Alt'        => 'athens',
			'3 Column Portfolio'                 => '3-col',
			'3 Column Portfolio w/ Title'        => '3-col-title',
			'3 Column Portfolio Wide'            => '3-col-wide',
			'2 Column Portfolio'                 => '2-col',
			'2 Column Portfolio w/ Title'        => '2-col-title'
		);
		
		if( has_filter('ebor_add_portfolio_layouts') ) {
			$options = apply_filters('ebor_add_portfolio_layouts', $options);
		}
		
		return $options;
		
	}
}

/**
 * Returns an array of all available testimonial layouts
 * 
 * @val array
 * @since 1.0.0
 * @package Gaze
 * @author TommusRhodus
 */
if(!( function_exists('ebor_get_testimonial_layouts') )){
	function ebor_get_testimonial_layouts(){
		
		$options = array(
			'Carousel' => 'carousel',
			'Slider'   => 'slider'
		);
		
		if( has_filter('ebor_add_testimonial_layouts') ) {
			$options = apply_filters('ebor_add_testimonial_layouts', $options);
		}
		
		return $options;
		
	}
}

/**
 * Returns an array of all available team layouts
 * 
 * @val array
 * @since 1.0.0
 * @package Gaze
 * @author TommusRhodus
 */
if(!( function_exists('ebor_get_team_layouts') )){
	function ebor_get_team_layouts(){
		
		$options = array(
			'Grid'      => 'grid',
			'Grid Alt'  => 'grid-alt'
		);
		
		if( has_filter('ebor_add_team_layouts') ) {
			$options = apply_filters('ebor_add_team_layouts', $options);
		}
		
		return $options;
		
	}
}

/**
 * Returns an array of all available client layouts
 * 
 * @val array
 * @since 1.0.0
 * @package Gaze
 * @author TommusRhodus
 */
if(!( function_exists('ebor_get_client_layouts') )){
	function ebor_get_client_layouts(){
		
		$options = array(
			'Carousel' => 'carousel',
			'Grid'     => 'grid'
		);
		
		if( has_filter('ebor_add_client_layouts') ) {
			$options = apply_filters('ebor_add_client_layouts', $options);
		}
		
		return $options;
		
	}
}

/**
 * Returns an array of all available header layouts
 * 
 * @val array
 * @since 1.0.0
 * @package gaze
 * @author TommusRhodus
 */
if(!( function_exists('ebor_get_header_options') )){
	function ebor_get_header_options(){
		$options = array(
			'blank' => 'No Header',
			'1'     => 'Light Classic Header',
			'3'     => 'Light Classic Header With Top Bar',
			'4'     => 'Sidebar Vertical Header',
			'6'     => 'Transparent Classic Header (Light Text)',
			'7'     => 'Transparent Classic Header (Dark Text)',
			'5'     => 'Modal Header',
			'modal-boxed' => 'Boxed Modal Header',
			'shop' => 'Ecommerce Header '
		);
		
		if( has_filter('ebor_add_header_layouts') ) {
			$options = apply_filters('ebor_add_header_layouts', $options);
		}
		
		return $options;	
	}
}

/**
 * Returns an array of all available footer layouts
 * 
 * @val array
 * @since 1.0.0
 * @package gaze
 * @author TommusRhodus
 */
if(!( function_exists('ebor_get_footer_options') )){
	function ebor_get_footer_options(){
		$options = array(
			'blank'      => 'No Footer',
			'1'          => 'Widgets Footer - Dark',			
			'3'          => 'Widgets Footer - Light',
			'2'          => 'Minimal Angled Footer - Dark',
			'4'          => 'Widgets Footer Alternative - Dark',			
			'sydney'	 => 'Widgets Footer Alternative - Light',
			'5'          => 'Simple Logo Footer - Light',
			'5-dark'	 => 'Simple Logo Footer - Dark',
			'6'          => 'Widgets Footer 3 Columns - Light',
			'7'          => 'Simple Footer - Light',
			'amsterdam'  => 'Widgets Footer Minimal - Light',			
			'shanghai'   => 'Super Minimal Footer  - Dark',
			'tokyo'   	 => 'Widgets Footer + Menu - Dark',
			'shop'   	 => 'Widgets Footer Ecommerce - Light',
			'athens'   	 => 'Super Minimal Footer Centered  - Light',
		);
		
		if( has_filter('ebor_add_footer_layouts') ) {
			$options = apply_filters('ebor_add_footer_layouts', $options);
		}
		
		return $options;	
	}
}