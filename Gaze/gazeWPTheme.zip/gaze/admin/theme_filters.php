<?php 

if(!( function_exists( 'ebor_merlin_local_import_files' ) )){
	function ebor_merlin_local_import_files() {
		return array(
			array(
			    'import_file_name'             => 'Gaze Demo Data',
			    'import_file_url'              => get_theme_file_uri( '/admin/demo-data/content.xml' ),
			    'import_widget_file_url'       => get_theme_file_uri( '/admin/demo-data/widgets.wie' ),
			    'import_customizer_file_url'   => get_theme_file_uri( '/admin/demo-data/customizer.dat' ),
			    'import_preview_image_url'     => get_theme_file_uri( '/screenshot.png' ),
			    'import_notice'                => esc_html__( 'After you import this demo, you will have to setup the slider separately.', 'gaze' ),
			    'preview_url'                  => 'http://gaze.tommusdemos.wpengine.com',
			)
		);
	}
	add_filter( 'merlin_import_files', 'ebor_merlin_local_import_files' );
}

/**
 * Execute custom code after the whole import has finished.
 */
if(!( function_exists( 'ebor_merlin_after_import_setup' ) )){
	function ebor_merlin_after_import_setup() {
		
		// Assign menus to their locations.
	    $main_menu = get_term_by( 'name', 'Standard Navigation', 'nav_menu' );
	
	    set_theme_mod( 'nav_menu_locations', array(
	            'primary'  => $main_menu->term_id
	        )
	    );
	
	    // Assign front page and posts page (blog page).
	    $front_page_id = get_page_by_title( 'Business New York' );
	    $blog_page_id  = get_page_by_title( 'Blog' );
	
	    update_option( 'show_on_front', 'page' );
	    update_option( 'page_on_front', $front_page_id->ID );
	    update_option( 'page_for_posts', $blog_page_id->ID );
		    
	}
	add_action( 'merlin_after_all_import', 'ebor_merlin_after_import_setup' );
}

/**
 * OCDI filters
 */
if( class_exists('OCDI_Plugin') ){
	
	function ebor_ocdi_plugin_intro_text( $default_text ) {
	    $default_text .= '
	    	<div class="ocdi__intro-text">
	    		<h3>Read this before importing demo data!</h3>
	    		<p>We have prepared full written & video documentation to make your life with Gaze much more easy. It is worth spending a few minutes with this to familiarise yourself with the theme & its plugins before jumping in with your demo data, so <a href="https://tommusrhodus.ticksy.com/articles/" target="_blank">please read the theme documentation</a> before importing the demo data.</p>
	    		<hr />
	    	</div>
	    ';
	
	    return $default_text;
	}
	add_filter( 'pt-ocdi/plugin_intro_text', 'ebor_ocdi_plugin_intro_text' );
	
	function ebor_ocdi_confirmation_dialog_options ( $options ) {
	    return array_merge( $options, array(
	        'width'       => 600,
	        'dialogClass' => 'wp-dialog',
	        'resizable'   => false,
	        'height'      => 'auto',
	        'modal'       => true,
	    ) );
	}
	add_filter( 'pt-ocdi/confirmation_dialog_options', 'ebor_ocdi_confirmation_dialog_options', 10, 1 );
	
	//Setup basic demo import
	function ebor_import_files() {
		
		$import_notice_vc = '
			<h3>Ready to Import Gaze Demo Data?</h3>
			<p>Please ensure all required plugins in "appearance => install plugins" are installed before running this demo importer.</p>
			<p>Since you\'re importing Gaze Demo Data, please ensure Visual Composer is enabled in "plugins".</p>
			<p><a href="https://tommusrhodus.ticksy.com/articles/" target="_blank">Please read the theme documentation.</a></p>
		';
				
	    return array(
	        array(
	            'import_file_name'             => 'Gaze + Visual Composer Demo Data',
	            'import_file_url'              => get_theme_file_uri( '/admin/demo-data/content.xml' ),
	            'import_widget_file_url'       => get_theme_file_uri( '/admin/demo-data/widgets.wie' ),
	            'import_customizer_file_url'   => get_theme_file_uri( '/admin/demo-data/customizer.dat' ),
	            'import_preview_image_url'     => get_theme_file_uri( '/screenshot.png' ),
	            'import_notice'                => $import_notice_vc,
	        ),
	    );
	    
	}
	add_filter( 'pt-ocdi/import_files', 'ebor_import_files' );
	
	//Setup front page and menus
	function ebor_after_import_setup() {
		
	    // Assign menus to their locations.
	    $main_menu = get_term_by( 'name', 'Standard Navigation', 'nav_menu' );
	
	    set_theme_mod( 'nav_menu_locations', array(
	            'primary'  => $main_menu->term_id
	        )
	    );
	
	    // Assign front page and posts page (blog page).
	    $front_page_id = get_page_by_title( 'Business New York' );
	    $blog_page_id  = get_page_by_title( 'Blog' );
	
	    update_option( 'show_on_front', 'page' );
	    update_option( 'page_on_front', $front_page_id->ID );
	    update_option( 'page_for_posts', $blog_page_id->ID );
	
	}
	add_action( 'pt-ocdi/after_import', 'ebor_after_import_setup' );
	
	//Remove Branding
	add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );
	
	//Save customize options
	add_action( 'pt-ocdi/enable_wp_customize_save_hooks', '__return_true' );
	
	//Stop thumbnail generation
	add_filter( 'pt-ocdi/regenerate_thumbnails_in_content_import', '__return_false' );
	
}

/**
 * Filter menu item classes into wp_get_nav_menu_items() array return
 */
if(!( function_exists('ebor_nav_menu_classes') )){
	function ebor_nav_menu_classes($items, $menu, $args) {
	    _wp_menu_item_classes_by_context($items);
	    return $items;
	}
	add_filter( 'wp_get_nav_menu_items', 'ebor_nav_menu_classes', 10, 3 );
}

/**
 * Add a clearfix to the end of the_content()
 */
if(!( function_exists('ebor_add_clearfix') )){ 
	function ebor_add_clearfix( $content ) { 
		$content = $content .= '<div class="clearfix"></div>';
	    return $content;
	}
	add_filter( 'the_content', 'ebor_add_clearfix' ); 
}

if(!( function_exists('ebor_excerpt_length') )){
	function ebor_excerpt_length( $length ) {
		return 45;
	}
	add_filter( 'excerpt_length', 'ebor_excerpt_length', 999 );
}

if(!( function_exists('ebor_excerpt_more') )){
	function ebor_excerpt_more( $more ) {
		return '...';
	}
	add_filter('excerpt_more', 'ebor_excerpt_more');
}

function ebor_cf7_remove_attr_size( $content ) {
	$content = preg_replace('/ size=".*?"/i', ' ', $content);
	return $content;
}
add_filter( 'wpcf7_form_elements', 'ebor_cf7_remove_attr_size' );

if(!( function_exists('ebor_tinymce_fix') )){
	function ebor_tinymce_fix( $init ){
	    $init['extended_valid_elements'] = 'i[*]';
	    return $init;
	}
	add_filter('tiny_mce_before_init', 'ebor_tinymce_fix');
}

if(!( function_exists('ebor_add_body_classes') )){ 
	function ebor_add_body_classes($classes) {
        
        $classes[] = 'relative';
        
        return $classes;
        
	}
	add_filter('body_class', 'ebor_add_body_classes');
}

/**
 * Add additional settings to gallery shortcode
 */
if(!( function_exists('ebor_add_gallery_settings') )){ 
	function ebor_add_gallery_settings(){
?>
	
		<script type="text/html" id="tmpl-stack-gallery-setting">
			<h3>Gaze Theme Gallery Settings</h3>
			<label class="setting">
				<span><?php esc_html_e('Gallery Layout', 'gaze'); ?></span>
				<select data-setting="layout">
					<option value="default">Default Layout</option>    
					<option value="carousel">Gaze Carousel</option>
					<option value="carousel-alt">Gaze Carousel Alternative ( 3 Items )</option>
					<option value="carousel-alt-4">Gaze Carousel Alternative ( 4 Items )</option>
					<option value="slider">Gaze Slider</option>
					<option value="photography-slider">Gaze Photography Slider</option>
					<option value="fullwidth-slider">Gaze Fullwidth Slider</option>
				</select>
			</label>
		</script>
	
		<script>
			jQuery(document).ready(function(){
				jQuery.extend(wp.media.gallery.defaults, { layout: 'default' });
				
				wp.media.view.Settings.Gallery = wp.media.view.Settings.Gallery.extend({
					template: function(view){
					  return wp.media.template('gallery-settings')(view)
					       + wp.media.template('stack-gallery-setting')(view);
					}
				});
			});
		</script>
	  
<?php
	}
	add_action('print_media_templates', 'ebor_add_gallery_settings');
}


/**
 * Custom gallery shortcode
 *
 * Filters the standard WordPress gallery shortcode.
 *
 * @since 1.0.0
 */
if(!( function_exists('ebor_post_gallery') )){
	function ebor_post_gallery( $output, $attr) {
		
		global $post, $wp_locale;
	
	    static $instance = 0;
	    $instance++;
	
	    // We're trusting author input, so let's at least make sure it looks like a valid orderby statement
	    if ( isset( $attr['orderby'] ) ) {
	        $attr['orderby'] = sanitize_sql_orderby( $attr['orderby'] );
	        if ( !$attr['orderby'] )
	            unset( $attr['orderby'] );
	    }
	
	    extract(shortcode_atts(array(
	        'order'      => 'ASC',
	        'orderby'    => 'menu_order ID',
	        'id'         => $post->ID,
	        'itemtag'    => 'div',
	        'icontag'    => 'dt',
	        'captiontag' => 'dd',
	        'columns'    => 3,
	        'size'       => 'large',
	        'include'    => '',
	        'exclude'    => '',
	        'layout'     => ''
	    ), $attr));
	
	    $id = intval($id);
	    if ( 'RAND' == $order )
	        $orderby = 'none';
	
	    if ( !empty($include) ) {
	        $include = preg_replace( '/[^0-9,]+/', '', $include );
	        $_attachments = get_posts( array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
	
	        $attachments = array();
	        foreach ( $_attachments as $key => $val ) {
	            $attachments[$val->ID] = $_attachments[$key];
	        }
	    } elseif ( !empty($exclude) ) {
	        $exclude = preg_replace( '/[^0-9,]+/', '', $exclude );
	        $attachments = get_children( array('post_parent' => $id, 'exclude' => $exclude, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
	    } else {
	        $attachments = get_children( array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
	    }
	
	    if ( empty($attachments) )
	        return '';
	
	    if ( is_feed() ) {
	        $output = "\n";
	        foreach ( $attachments as $att_id => $attachment )
	            $output .= wp_get_attachment_link($att_id, $size, true) . "\n";
	        return $output;
	    }

	    if( 'carousel' == $layout ){
			          
	    	$output = '<div id="works-slider" class="flickity-slider-wrap items-4 mfp-hover" data-autoplay="true" data-arrows="true" data-slidedots="false">';
	    	
	    	foreach ( $attachments as $id => $attachment ) {  
	    		
	    		$src = wp_get_attachment_image_src( $id, 'full' );
	    		
	    		$output .= '
	    			<div class="gallery-cell work-item hover-trigger hover-3">
	    				<div class="work-container">
	    					<div class="work-img">
	    						<a href="'. $src[0] .'" class="lightbox-img">
	    						
	    							'. wp_get_attachment_image($id, 'large') .'
	    							
	    							<div class="hover-overlay" data-overlay="5">
	    								<div class="work-description">
	    									<h3>Vimeo Video</h3>
	    									<span>Photography</span>
	    								</div>
	    							</div>
	    							
	    						</a>              
	    					</div>
	    				</div> 
	    			</div>
	    		';

	    	}
	    	
	    	$output .= '</div>';
	    	
	    	return $output;
	    	
	    }
	    
	    if( 'carousel-alt' == $layout ){
	    			          
	    	$output = '<div id="owl-3-items" class="works-grid with-title gutter owl-carousel owl-theme owl-dark-dots">';
	    	
	    	foreach ( $attachments as $id => $attachment ) {  
	    		
	    		$src = wp_get_attachment_image_src( $id, 'full' );
	    		
	    		$output .= '
	    			<div class="work-item hover-trigger hover-3">
	    				<div class="work-container">
	    					<div class="work-img">
	    						<a href="'. $src[0] .'" class="lightbox-img">
	    						
	    							'. wp_get_attachment_image($id, 'large') .'
	    							
	    							<div class="hover-overlay" data-overlay="5">
	    								<div class="work-description">
	    									<h3>Vimeo Video</h3>
	    									<span>Photography</span>
	    								</div>
	    							</div>
	    							
	    						</a>              
	    					</div>
	    				</div> 
	    			</div>
	    		';

	    	}
	    	
	    	$output .= '</div>';
	    	
	    	return $output;
	    	
	    }
	    
	    if( 'carousel-alt-4' == $layout ){
	    			          
	    	$output = '<div id="apps-slider" class="flickity-slider-wrap with-spacing items-4" data-autoplay="false" data-arrows="false" data-slidedots="true">';
	    	
	    	foreach ( $attachments as $id => $attachment ) {  
	    		
	    		$src = wp_get_attachment_image_src( $id, 'full' );
	    		
	    		$output .= '
					<div class="gallery-cell work-item">
						<div class="work-container">
							<div class="work-img">'. wp_get_attachment_image($id, 'large') .'</div>
						</div> 
					</div>
	    		';

	    	}
	    	
	    	$output .= '</div>';
	    	
	    	return $output;
	    	
	    }
	    
	    if( 'slider' == $layout ){
	    	    			          
	    	$output = '<div id="slider-single" class="flickity-slider-wrap" data-autoplay="true" data-arrows="true" data-slidedots="false">';
	    	
	    	foreach ( $attachments as $id => $attachment ) {  

	    		$output .= '
	    			<div class="gallery-cell work-item">
	    				<div class="work-container">
	    					<div class="work-img">
	    						'. wp_get_attachment_image($id, 'large') .'           
	    					</div>
	    				</div> 
	    			</div>
	    		';

	    	}
	    	
	    	$output .= '</div>';
	    	
	    	return $output;
	    	
	    }
		
		if( 'photography-slider' == $layout ){
			    	    			          
	    	$output = '<div id="photography-slider" class="flickity-slider-wrap" data-autoplay="false" data-arrows="true" data-slidedots="false">';
	    	
	    	foreach ( $attachments as $id => $attachment ) {  
	    		$output .= wp_get_attachment_image($id, 'large');
	    	}
	    	
	    	$output .= '</div>';
	    	
	    	return $output;
	    	
	    }
	    
	    if( 'fullwidth-slider' == $layout ){
	    
		    $output = '<div id="showcases-slider" class="flickity-slider-wrap dark-dots mfp-hover" data-autoplay="true" data-arrows="false" data-slidedots="true">';
				
				foreach ( $attachments as $id => $attachment ) {  
					$output .= '
						<div class="gallery-cell work-item">
							<div class="work-container">
								<div class="work-img">'. wp_get_attachment_image( $id, 'full' ) .'</div>
							</div> 
						</div>
					';
				}
				
				
				
			$output .= '</div>';
			
			return $output;
	    
	    }
				
				
	}
	add_filter( 'post_gallery', 'ebor_post_gallery', 10, 2 );
}



/**
 * Add items to end of menu
 *
 * Filters the standard WordPress gallery shortcode.
 *
 * @since 1.0.0
 */
if(!( function_exists('ebor_add_search_to_nav') )){
	function ebor_add_search_to_nav( $items, $args ) {
	
		$show_search         = get_option( 'show_search', 'yes' );
		$show_sidebar_toggle = get_option( 'show_sidebar_toggle', 'yes' );
		
		if( $args->theme_location == 'primary' ) {
		
	    	$items .= '<li class="nav-right hidden-sm hidden-xs"><ul>';
	    	
			if( 'yes' == $show_search ) {
				$items .= '
					<li class="nav-search-wrap hidden-sm hidden-xs">
						<a href="#" class="nav-search search-trigger">
							<i class="ui-search"></i>
						</a>
					</li>
				';
			}
			
			if( 'yes' == $show_sidebar_toggle ) {
				$items .= '
					<li class="nav-icon-wrap hidden-sm hidden-xs">
						<div id="nav-icon">
							<div class="nav-icon-inner">
								<a href="#" id="nav-icon-trigger" class="nav-icon-trigger">
									<span></span>
									<span></span>
									<span></span>
									<span></span>
								</a>
							</div>
						</div>
					</li>
				';
			}
						
			$items .= '</ul></li>';
			
		}
		
	    return $items;
	    
	}
	add_filter( 'wp_nav_menu_items', 'ebor_add_search_to_nav', 10, 2 );
}