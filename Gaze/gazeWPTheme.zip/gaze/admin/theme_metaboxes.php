<?php 

/**
 * Build theme metaboxes
 * Uses the cmb metaboxes class found in the ebor framework plugin
 * More details here: https://github.com/WebDevStudios/Custom-Metaboxes-and-Fields-for-WordPress
 * 
 * @since 1.0.0
 * @author tommusrhodus
 */
if(!( function_exists('ebor_custom_metaboxes') )){
	function ebor_custom_metaboxes( $meta_boxes ) {
		
		$prefix         = '_ebor_';
		$custom_menus   = array();
		$menus          = get_terms( 'nav_menu', array( 'hide_empty' => false ) );
		$social_options = ebor_get_icons();
		$footer_options = ebor_get_footer_options();
		$header_options = ebor_get_header_options();
		
		$footer_overrides['none'] = 'Do Not Override Footer Option On This Page';
		foreach( $footer_options as $key => $value ){
			$footer_overrides[$key] = 'Override Footer: ' . $value; 	
		}
		
		$header_overrides['none'] = 'Do Not Override Header Option On This Page';
		foreach( $header_options as $key => $value ){
			$header_overrides[$key] = 'Override Header: ' . $value; 	
		}
		
		if ( is_array( $menus ) && ! empty( $menus ) ) {
			foreach ( $menus as $single_menu ) {
				if ( is_object( $single_menu ) && isset( $single_menu->name, $single_menu->slug ) ) {
					$custom_menus[ $single_menu->slug ] = $single_menu->name;
				}
			}
		}
		
		$meta_boxes[] = array(
			'id'           => 'blog_layout_metabox',
			'title'        => esc_html__('Blog Item Layout Options', 'gaze'),
			'object_types' => array('post'), // post type
			'context'      => 'normal',
			'priority'     => 'high',
			'show_names'   => true, // Show field names on the left
			'fields'       => array(
				array(
					'name' => esc_html__( 'Featured Content Images', 'gaze' ),
					'desc' => esc_html__( 'Drag & Drop to Reorder', 'gaze' ),
					'id'   => $prefix . 'gallery_images',
					'type' => 'file_list',
				),
				array(
					'name' => esc_html__( 'Video Featured Content oEmbed', 'gaze' ),
					'desc' => 'Enter a Youtube or Vimeo URL. Supports services listed <a href="http://codex.wordpress.org/Embeds" target="_blank">here</a>',
					'id'   => $prefix . 'the_oembed',
					'type' => 'oembed',
				),
			)
		);
		
		$meta_boxes[] = array(
			'id'           => 'portfolio_layout_metabox',
			'title'        => esc_html__('Portfolio Item Layout Options', 'gaze'),
			'object_types' => array('portfolio'), // post type
			'context'      => 'normal',
			'priority'     => 'high',
			'show_names'   => true, // Show field names on the left
			'fields'       => array(
				array(
					'name'        => 'Featured Content Position',
					'id'          => $prefix . 'portfolio_layout',
					'type'        => 'select',
					'options'     => array_flip( ebor_get_portfolio_single_layouts() ),
					'default'     => 'feature-left',
					'description' => 'Where will you show the featured content? Post content will be relative to this.'
				),
				array(
					'name' => esc_html__('Featured Content Images', 'gaze' ),
					'desc' => esc_html__('Drag & Drop to Reorder', 'gaze' ),
					'id'   => $prefix . 'gallery_images',
					'type' => 'file_list',
				),
				array(
				    'id'          => $prefix . 'meta_repeat_group',
				    'type'        => 'group',
				    'description' => esc_html__( 'Meta Titles & Descriptions', 'gaze' ),
				    'options'     => array(
				        'add_button'    => esc_html__( 'Add Another Entry', 'gaze' ),
				        'remove_button' => esc_html__( 'Remove Entry', 'gaze' ),
				        'sortable'      => true, // beta
				    ),
				    'fields'       => array(
						array(
							'name' => esc_html__('Additional Item Title', 'gaze'),
							'desc' => esc_html__("Title of your Additional Meta", 'gaze'),
							'id'   => $prefix . 'the_additional_title',
							'type' => 'text'
						),
						array(
							'name' => esc_html__('Additional Item Detail', 'gaze'),
							'desc' => esc_html__("Detail of your Additional Meta", 'gaze'),
							'id'   => $prefix . 'the_additional_detail',
							'type' => 'text'
						),
				    ),
				),
			)
		);

		/**
		 * Mega menu metaboxes
		 */
		$meta_boxes[] = array(
			'id' => 'mega_menu_metabox',
			'title' => esc_html__('Menus to Show in Mega Menu Dropdown', 'gaze'),
			'object_types' => array('mega_menu'), // post type
			'context' => 'normal',
			'priority' => 'high',
			'show_names' => true, // Show field names on the left
			'fields' => array(
				array(
					'name' => esc_html__('Menu Title 1', 'gaze'),
					'desc' => '(Optional) Enter a title for this menu to show in the mega menu.',
					'id'   => $prefix . 'menu_title_1',
					'type' => 'text',
				),
				array(
				    'name'             => 'Menu Column 1',
				    'desc'             => 'Select an option',
				    'id'               => $prefix . 'menu_1',
				    'type'             => 'select',
				    'show_option_none' => true,
				    'default'          => '',
				    'options'          => $custom_menus,
				),
				array(
					'name' => esc_html__('Menu Title 2', 'gaze'),
					'desc' => '(Optional) Enter a title for this menu to show in the mega menu.',
					'id'   => $prefix . 'menu_title_2',
					'type' => 'text',
				),
				array(
				    'name'             => 'Menu Column 2',
				    'desc'             => 'Select an option',
				    'id'               => $prefix . 'menu_2',
				    'type'             => 'select',
				    'show_option_none' => true,
				    'default'          => '',
				    'options'          => $custom_menus,
				),
				array(
					'name' => esc_html__('Menu Title 3', 'gaze'),
					'desc' => '(Optional) Enter a title for this menu to show in the mega menu.',
					'id'   => $prefix . 'menu_title_3',
					'type' => 'text',
				),
				array(
				    'name'             => 'Menu Column 3',
				    'desc'             => 'Select an option',
				    'id'               => $prefix . 'menu_3',
				    'type'             => 'select',
				    'show_option_none' => true,
				    'default'          => '',
				    'options'          => $custom_menus,
				),
				array(
					'name' => esc_html__('Menu Title 4', 'gaze'),
					'desc' => '(Optional) Enter a title for this menu to show in the mega menu.',
					'id'   => $prefix . 'menu_title_4',
					'type' => 'text',
				),
				array(
				    'name'             => 'Menu Column 4',
				    'desc'             => 'Select an option',
				    'id'               => $prefix . 'menu_4',
				    'type'             => 'select',
				    'show_option_none' => true,
				    'default'          => '',
				    'options'          => $custom_menus,
				)
			)
		);
		
		/**
		 * Social Icons for Team Members
		 */
		$meta_boxes[] = array(
			'id' => 'social_metabox',
			'title' => esc_html__('Team Member Details', 'gaze'),
			'object_types' => array('team'), // post type
			'context' => 'normal',
			'priority' => 'high',
			'show_names' => true, // Show field names on the left
			'fields' => array(
				array(
					'name' => esc_html__('Job Title', 'gaze'),
					'desc' => '(Optional) Enter a Job Title for this Team Member',
					'id'   => $prefix . 'the_job_title',
					'type' => 'text',
				),
				array(
				    'id'          => $prefix . 'team_social_icons',
				    'type'        => 'group',
				    'options'     => array(
				        'add_button'    => esc_html__( 'Add Another Icon', 'gaze' ),
				        'remove_button' => esc_html__( 'Remove Icon', 'gaze' ),
				        'sortable'      => true
				    ),
				    'fields' => array(
						array(
							'name'    => 'Social Icon',
							'desc'    => 'What icon would you like for this team members first social profile?',
							'id'      => $prefix . 'social_icon',
							'type'    => 'select',
							'options' => $social_options
						),
						array(
							'name' => esc_html__('URL for Social Icon', 'gaze'),
							'desc' => esc_html__("Enter the URL for Social Icon 1 e.g www.google.com", 'gaze'),
							'id'   => $prefix . 'social_icon_url',
							'type' => 'text'
						),
				    ),
				),
			)
		);
		
		/**
		 * Testimonial job titles
		 */
		$meta_boxes[] = array(
			'id' => 'testimonial_metabox',
			'title' => esc_html__( 'Testimonial Details', 'gaze' ),
			'object_types' => array( 'testimonial' ), // post type
			'context' => 'normal',
			'priority' => 'high',
			'show_names' => true, // Show field names on the left
			'fields' => array(
				array(
					'name' => esc_html__( 'Job Title', 'gaze' ),
					'id'   => $prefix . 'the_job_title',
					'type' => 'text',
				)
			)
		);
		
		$meta_boxes[] = array(
			'id' => 'client_metabox',
			'title' => esc_html__( 'Client URL', 'gaze' ),
			'object_types' => array( 'client' ), // post type
			'context' => 'normal',
			'priority' => 'high',
			'show_names' => true, // Show field names on the left
			'fields' => array(
				array(
					'name' => esc_html__( 'The Client URL', 'gaze' ),
					'id'   => $prefix . 'the_client_url',
					'type' => 'text',
				)
			)
		);
		
		$meta_boxes[] = array(
			'id' => 'page_override_metabox',
			'title' => esc_html__( 'Page Overrides', 'gaze' ),
			'object_types' => array( 'page', 'portfolio', 'team', 'post', 'career', 'product' ), // post type
			'context' => 'normal',
			'priority' => 'low',
			'show_names' => true, // Show field names on the left
			'fields' => array(
				array(
					'name'         => esc_html__( 'Override Header?', 'gaze' ),
					'desc'         => esc_html__( 'Header Layout is set in "appearance" -> "customise". To override this for this page only, use this control.', 'gaze' ),
					'id'           => $prefix . 'header_override',
					'type'         => 'select',
					'options'      => $header_overrides,
					'std'          => 'none'
				),
				array(
					'name'         => esc_html__( 'Override Footer?', 'gaze' ),
					'desc'         => esc_html__( 'Footer Layout is set in "appearance" -> "customise". To override this for this page only, use this control.', 'gaze' ),
					'id'           => $prefix . 'footer_override',
					'type'         => 'select',
					'options'      => $footer_overrides,
					'std'          => 'none'
				)
			)
		);
		
		return $meta_boxes;
		
	}
	add_filter( 'cmb2_meta_boxes', 'ebor_custom_metaboxes' );
}