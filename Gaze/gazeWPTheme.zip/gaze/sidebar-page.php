<?php if( is_active_sidebar( 'page' ) ) : ?>

	<aside class="col-md-3 sidebar">
		<?php dynamic_sidebar( 'page' ); ?>
	</aside>
	
<?php endif;