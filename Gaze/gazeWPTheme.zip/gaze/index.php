<?php 
	get_header(); 
	
	ebor_page_title( 
		get_option( 'blog_title', 'Our Blog' ), 
		get_option( 'blog_image', '' ) 
	);
?>

<section class="section-wrap-sm blog-standard bg-light pb-50">
	<div class="container relative">
		<?php get_template_part( 'loop/loop-post', get_option( 'blog_layout', 'standard' ) ); ?>
	</div>
</section>
	
<?php
	get_footer();