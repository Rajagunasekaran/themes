<?php 
	get_header();
	the_post();
	
	$show_sharing = get_option( 'show_sharing', 'yes' );
?>

<section id="team-<?php the_ID(); ?>" <?php post_class( 'section-wrap-sm post-single bg-light pb-50' ); ?>>
	<div class="container relative">
		<div class="row">
			
			<div class="col-md-5 mb-50">
				<?php the_post_thumbnail( 'large' ); ?>
			</div>
			
			<div class="col-md-7 post-content mb-50">
				<article class="entry-item">
					<div class="entry-wrap">
						<div class="entry">
							<div class="entry-content">
							
								<div class="article">
									<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
									<h5><?php echo get_post_meta( $post->ID, '_ebor_the_job_title', 1 ); ?></h5>
									<?php
										the_content();
										wp_link_pages();
									?>
								</div><!-- end article -->
								
								<?php
									if( $show_sharing == 'yes' )
										get_template_part( 'inc/content-post', 'sharing' );
								?>
							
							</div><!-- end entry content -->
						</div>
					</div>
				</article>
			</div><!-- end col -->
			
		</div><!-- end row -->
	</div><!-- end container -->
</section><!-- end blog standard -->

<?php get_footer();