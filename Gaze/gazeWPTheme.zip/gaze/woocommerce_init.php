<?php 

if(!( function_exists('ebor_woocommerce_page_template') )){
	function ebor_woocommerce_page_template( $template ){
		global $post;
		
		if( is_archive() || is_404() || is_home() || !( isset($post->post_content) ) || is_search() )
			return $template;
			
		if( 
			has_shortcode($post->post_content, 'woocommerce_cart') || 
			has_shortcode($post->post_content, 'woocommerce_checkout') || 
			has_shortcode($post->post_content, 'woocommerce_my_account') 
		){
			
			$new_template = locate_template( array( 'page_woocommerce.php' ) );
			
			if (!( '' == $new_template )){
				return $new_template;
			}
			
		}
		
		return $template;
	}
	add_filter( 'template_include', 'ebor_woocommerce_page_template', 99 );
}