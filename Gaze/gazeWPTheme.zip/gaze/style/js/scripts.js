(function($){

  "use strict"; 
  
  jQuery.fn.setAllToMaxHeight = function(){
  	return this.css({ 'height' : '' }).height( Math.max.apply(this, jQuery.map( this , function(e){ return jQuery(e).height() }) ) );
  }
  
  //Fix all font awesome icons
  jQuery('i[class*="fa-"]').addClass('fa');
  
  var twitterId = $('#tweets').attr('data-user-name');
  var maxTweets = $('#tweets').attr('data-max-tweets');
  
  // Twitter Feed
  var config1 = {
    "profile": {"screenName": jQuery('#tweets').attr('data-user-name')},
    "domId": 'tweets',
    "showUser": false,
    "showInteraction": false,
    "showPermalinks": false,
    "maxTweets": jQuery('#tweets').attr('data-max-tweets'),
	"showRetweet": false,
    "enableLinks": true
  };
  twitterFetcher.fetch(config1);

  $(window).on('load', function() {
  	
  	jQuery('.product-grid').setAllToMaxHeight();
  	
  	//WordPress
  	jQuery('.btn').not(':has(span)').wrapInner('<span />');
  	
  	jQuery('input[type="radio"], input[type="checkbox"]').each(function(i){
  		var $this = jQuery(this);
  		$this.attr( 'id', 'item-'+ i ).next().wrap('<label for="item-'+ i +'" />');
  	});
  	
  	if( jQuery( '.nav-type-4' ).length ){
  		jQuery( 'body').addClass( 'vertical-nav' );
  	}

    // Preloader
    $('.loader').fadeOut();
    $('.loader-mask').delay(350).fadeOut('slow');
    initTwittslider();
    initOwlCarousel();
    initCounters();

    $(window).trigger("resize");

  });


  // Init
  initMasonry();
  squareDiv();


  $(window).resize(function(){
	
	jQuery('.product-grid').setAllToMaxHeight();
    container_full_height_init();
    megaMenu();
    megaMenuWide();
    squareDiv();    
    
    if (minWidth(992)) {
      $('.navigation').removeClass('sticky');
      $('.local-scroll.desktop-offset-0').localScroll({offset: {top: -60},duration: 1500,easing:'easeInOutExpo'});
      $('.local-scroll.mobile-offset-0').localScroll({offset: {top: 0},duration: 1500,easing:'easeInOutExpo'});
    } else {
      $('.local-scroll.mobile-offset-0').localScroll({offset: {top: -60},duration: 1500,easing:'easeInOutExpo'});
      $('.local-scroll.desktop-offset-0').localScroll({offset: {top: 0},duration: 1500,easing:'easeInOutExpo'});
    }

  });
  

  /* Detect Browser Size
  -------------------------------------------------------*/
  var minWidth;
  if (Modernizr.mq('(min-width: 0px)')) {
    // Browsers that support media queries
    minWidth = function (width) {
      return Modernizr.mq('(min-width: ' + width + 'px)');
    };
  }
  else {
    // Fallback for browsers that does not support media queries
    minWidth = function (width) {
      return $(window).width() >= width;
    };
  }


  /* Sticky Navigation
  -------------------------------------------------------*/
  $(window).scroll(function(){

    scrollToTop();
    var windowWidth = $(window).width();
    var $stickyNav = $('#sticky-nav');
    var $navbarFixedTop = $('.navbar-fixed-top');

    if ($(window).scrollTop() > 190 & minWidth(992)) {
      $stickyNav.addClass("sticky");
    } else {
      $stickyNav.removeClass("sticky");
    }

    if ($(window).scrollTop() > 200 & minWidth(992)) {
      $stickyNav.addClass("offset");
    } else {
      $stickyNav.removeClass("offset");
    }

    if ($(window).scrollTop() > 500 & minWidth(992)) {
      $stickyNav.addClass("scrolling");
    } else {
      $stickyNav.removeClass("scrolling");
    }


    if ($(window).scrollTop() > 190 ){
      $navbarFixedTop.addClass("sticky");
    } else {
      $navbarFixedTop.removeClass("sticky");
    }

    if ($(window).scrollTop() ){
      $(".sidenav").removeClass('opened');
      $('.main-wrapper').removeClass('sidenav-opened');
      $('#nav-icon').removeClass('open');
    } else {
      return false;
    }

  });
  

  /* Onepage Nav
  -------------------------------------------------------*/
  $('#onepage-nav').on('click', 'li > a', function() {
    $(".navbar-collapse").collapse('hide');
  });


  // Smooth Scroll Navigation
  $('.local-scroll').localScroll({offset: {top: -60},duration: 1500,easing:'easeInOutExpo'});
  $('.local-scroll-no-offset').localScroll({offset: {top: 0},duration: 1500,easing:'easeInOutExpo'});


  /* Full screen Navigation
  -------------------------------------------------------*/
  $('#nav-icon-trigger-2').on("click", function(e){
    e.preventDefault();
    $('#nav-icon, #nav-overlay').toggleClass('open');
    $('body').toggleClass('fs-open');

    $(function(){   
      var delay = 0
      $('.overlay-menu > ul > li').each(function(){
        $(this).css({animationDelay: delay+'s'})
        delay += 0.1
      }) 
    })
  });


  /* Sidenav
  -------------------------------------------------------*/
  var $mainWrapper = $('.main-wrapper');
  var $sidenav = $(".sidenav");

  $("#nav-icon-trigger, #sidenav-close").on('click', function(e) {
    e.preventDefault();
    e.stopPropagation();    

    $sidenav.toggleClass('opened');
    $mainWrapper.toggleClass('sidenav-opened');
  });

  $mainWrapper.on('click',function() {
    $(this).removeClass('sidenav-opened');
    $sidenav.removeClass('opened');    
  });


  /* Dropdown Navigation
  -------------------------------------------------------*/
  var $dropdownTrigger = $('.dropdown-trigger');
  $dropdownTrigger.on('click', function() {

    if ($(this).hasClass("active")) {
      $(this).removeClass("active");
    }

    else {
      $(this).addClass("active");
    }
  });


  /* Search
  -------------------------------------------------------*/
  var $searchWrap = $('.search-wrap');
  var $navSearch = $('.nav-search');
  var $searchClose = $('#search-close');

  $('.search-trigger').on('click',function(e){
    e.preventDefault();
    $searchWrap.animate({opacity: 'toggle'},500);
    $navSearch.add($searchClose).addClass("open");
  });

  $('.search-close').on('click',function(e){
    e.preventDefault();
    $searchWrap.animate({opacity: 'toggle'},500);
    $navSearch.add($searchClose).removeClass("open");
  });

  function closeSearch(){
    $searchWrap.fadeOut(200);
    $navSearch.add($searchClose).removeClass("open");
  }
    
  $(document.body).on('click',function(e) {
    closeSearch();
  });

  $(".search-trigger, .main-search-input").on('click',function(e) {
    e.stopPropagation();
  });


  /* Mobile Detect
  -------------------------------------------------------*/
  if (/Android|iPhone|iPad|iPod|BlackBerry|Windows Phone/i.test(navigator.userAgent || navigator.vendor || window.opera)) {
     $("html").addClass("mobile");
     $('.dropdown-toggle').attr('data-toggle', 'dropdown');
  }
  else {
    $("html").removeClass("mobile");
  }

  /* IE Detect
  -------------------------------------------------------*/
  if(Function('/*@cc_on return document.documentMode===10@*/')()){ $("html").addClass("ie"); }


  /* Mega Menu
  -------------------------------------------------------*/
  function megaMenu(){
    $('.megamenu').each(function () {
      $(this).css('width', $('.container').width());
      var offset = $(this).closest('.dropdown').offset();
      offset = offset.left;
      var containerOffset = $(window).width() - $('.container').outerWidth();
      containerOffset = containerOffset /2;
      offset = offset - containerOffset - 15;
      $(this).css('left', -offset);
    });
  }

  function megaMenuWide(){
    $('.megamenu-wide').each(function () {
      $(this).css('width', $(window).outerWidth());
      var offset = $(this).closest('.dropdown').offset();
      offset = offset.left;
      var containerOffset = $(window).width() - $(window).outerWidth();
      containerOffset = containerOffset /2;
      offset = offset - containerOffset - 0;
      $(this).css('left', -offset);
    });
  }


  /* Counters
  -------------------------------------------------------*/
  function initCounters() {
    $('.statistic').appear(function() {
      $('.statistic-timer').countTo({
        speed: 4000,
        refreshInterval: 60,
        formatter: function (value, options) {
          return value.toFixed(options.decimals);
        }
      });      
    });
  }

  /* Twitter Slider
  -------------------------------------------------------*/
  function initTwittslider(){
    $('.twitter-slider #tweets ul').addClass('owl-carousel owl-theme light-arrows text-center').attr('id', 'owl-single');
  }


  /* Owl Carousel
  -------------------------------------------------------*/

  function initOwlCarousel(){
    (function($){
      "use strict";

      /* Testimonials
      -------------------------------------------------------*/

      $("#owl-testimonials").owlCarousel({      
        navigation: false,
        navigationText: ["<i class='icon-Left-2'></i>", "<i class='icon-Right-2'></i>"],
        autoHeight: true,
        slideSpeed: 300,
        pagination: true,
        paginationSpeed: 400,
        singleItem: true,
        stopOnHover: true      
      });

      // 2 Boxes
      $("#owl-testimonials-boxes-2").owlCarousel({      
        navigation: false,
        slideSpeed: 300,
        pagination: true,
        paginationSpeed: 400,
        stopOnHover: true,
        itemsCustom: [
          [0, 1],      
          [450, 1],
          [700, 2],
          [1200, 2]
        ],      
      });

      /* Partners Logo
      -------------------------------------------------------*/

      $("#owl-partners").owlCarousel({
        autoPlay: 3000,
        pagination: false,
        itemsCustom: [
          [0, 2],
          [370, 3],
          [550, 4],
          [700, 5],
          [1000, 6]
        ],
      });

      /* 3 Items
      -------------------------------------------------------*/

      $("#owl-3-items").owlCarousel({
        // autoPlay: 3000,
        pagination: true,
        navigation: false,
        navigationText: ["<i class='icon-Left-2'></i>", "<i class='icon-Right-2'></i>"],
        itemsCustom: [
          [0, 1],
          [370, 1],
          [550, 2],
          [700, 3],
          [1000, 3]
        ],
      });

      /* 3 Items
      -------------------------------------------------------*/

      var owl3ItemsArrows = $("#owl-3-items-arrows").owlCarousel({
        pagination: false,
        navigation: false,
        navigationText: ["<i class='icon-Left-2'></i>", "<i class='icon-Right-2'></i>"],
        itemsCustom: [
          [0, 1],
          [370, 1],
          [550, 2],
          [700, 3],
          [1000, 3]
        ],
      });

      // Custom Navigation Events
      $(".next").on('click',function(){
          owl3ItemsArrows.trigger('owl.next');
      });
      $(".prev").on('click',function(){
          owl3ItemsArrows.trigger('owl.prev');
      });
      

      /* Shop Items Slider
      -------------------------------------------------------*/

      $("#owl-shop-items-slider").owlCarousel({
        // autoPlay: 2500,
        pagination: false,
        navigation: true,
        navigationText: ["<i class='icon-Left-2'></i>", "<i class='icon-Right-2'></i>"],
        itemsCustom: [
          [0, 1],
          [370, 2],
          [550, 3],
          [700, 4],
          [1000, 4]
        ],
      })


      /* Single Image
      -------------------------------------------------------*/

      $("#owl-single").owlCarousel({     
        navigation: false,
        pagination: true,
        slideSpeed: 300,
        paginationSpeed: 400,
        singleItem: true,
        navigationText: ["<i class='icon-Left-2'></i>", "<i class='icon-Right-2'></i>"]
      })

    })(jQuery);
  };


  /* Blog Masonry / FlexSlider
  -------------------------------------------------------*/

  $('#flexslider').flexslider({
    animation: "slide",
    controlNav: true,
    directionNav: false,
    touch: true,
    slideshow: false,
    prevText: ["<i class='icon-Left-2'></i>"],
    nextText: ["<i class='icon-Right-2'></i>"],
    start: function(){
      var $container = $('.masonry');
      $container.imagesLoaded( function() {
        $container.isotope({
          itemSelector: '.masonry-item',
          layoutMode: 'masonry'
        });
      });
    }
  });


  /* Flickity Slider
  -------------------------------------------------------*/
  var $flickitySliderWrap = $('.flickity-slider-wrap');

  if ($flickitySliderWrap.data('autoplay')) {
    var dataAutoPlay = true;
  } else {
    var dataAutoPlay = false;
  }

  if ($flickitySliderWrap.data('arrows')) {
    var dataArrows = true;
  } else {
    var dataArrows = false;
  }

  if ($flickitySliderWrap.data('slidedots')) {
    var dataSlideDots = true;
  } else {
    var dataSlideDots = false;
  }
  
  $(document).on("vc-full-width-row", function(){
  	$flickitySliderWrap.flickity('resize');
  });
  

  // Featured Works
  $('#works-slider').flickity({
    cellAlign: 'left',
    contain: true,
    wrapAround: true,
    autoPlay: dataAutoPlay,
    prevNextButtons: dataArrows,
    percentPosition: true,
    imagesLoaded: true,
    lazyLoad: 1,
    pageDots: dataSlideDots,
    draggable: true,
    selectedAttraction : 0.1,
    friction: 0.6,
    rightToLeft: false,
    arrowShape: 'M 15,50 L 60,95 L 65,90 L 25,50  L 65,10 L 60,5 Z'
  });

  // Photography slider
  $('#photography-slider').flickity({
    cellAlign: 'center',
    wrapAround: true,
    autoPlay: dataAutoPlay,
    prevNextButtons: dataArrows,
    percentPosition: false,
    imagesLoaded: true,
    lazyLoad: 1,
    pageDots: dataSlideDots,
    draggable: true,
    selectedAttraction : 0.1,
    friction: 0.6,
    rightToLeft: false,
    arrowShape: 'M 15,50 L 60,95 L 65,90 L 25,50  L 65,10 L 60,5 Z'
  });

  // Showcases slider
  $('#showcases-slider').flickity({
    cellAlign: 'center',
    wrapAround: true,
    autoPlay: dataAutoPlay,
    prevNextButtons: dataArrows,
    percentPosition: false,
    imagesLoaded: true,
    lazyLoad: 1,
    pageDots: dataSlideDots,
    draggable: true,
    selectedAttraction : 0.1,
    friction: 0.6,
    rightToLeft: false,
    arrowShape: 'M 15,50 L 60,95 L 65,90 L 25,50  L 65,10 L 60,5 Z'
  });

  // Featured Works
  $('#apps-slider').flickity({
    cellAlign: 'left',
    groupCells: true,
    contain: true,
    wrapAround: true,
    autoPlay: dataAutoPlay,
    prevNextButtons: dataArrows,
    percentPosition: true,
    imagesLoaded: true,
    lazyLoad: 1,
    pageDots: dataSlideDots,
    draggable: true,
    selectedAttraction : 0.1,
    friction: 0.6,
    rightToLeft: false,
    arrowShape: 'M 15,50 L 60,95 L 65,90 L 25,50  L 65,10 L 60,5 Z'
  });

  // main large image (shop product)
  var $gallery = $('#gallery-main').flickity({
    cellAlign: 'center',
    contain: true,
    wrapAround: true,
    autoPlay: false,
    prevNextButtons: true,
    percentPosition: true,
    imagesLoaded: true,
    lazyLoad: 1,
    pageDots: false,
    selectedAttraction : 0.1,
    friction: 0.6,
    rightToLeft: false,
    arrowShape: 'M 10,50 L 60,100 L 65,95 L 20,50  L 65,5 L 60,0 Z'
  });

  // thumbs
  $('.gallery-thumbs').flickity({
    asNavFor: '#gallery-main',
    contain: true,
    cellAlign: 'left',
    wrapAround: false,
    autoPlay: false,
    prevNextButtons: false,
    percentPosition: true,
    imagesLoaded: true,
    pageDots: false,
    selectedAttraction : 0.1,
    friction: 0.6,
    rightToLeft: false
  });

  // Single item
  $('#slider-single').flickity({
    cellAlign: 'left',
    contain: true,
    wrapAround: true,
    autoPlay: dataAutoPlay,
    prevNextButtons: dataArrows,
    percentPosition: true,
    imagesLoaded: true,
    lazyLoad: 1,
    pageDots: dataSlideDots,
    selectedAttraction : 0.1,
    friction: 0.6,
    rightToLeft: false,
    arrowShape: 'M 10,50 L 60,100 L 65,100 L 15,50  L 65,0 L 60,0 Z'
  });

  var $gallery = $('.mfp-hover');

  $gallery.on( 'dragStart.flickity', function( event, pointer ) {
    $(this).addClass('is-dragging');
  })

  $gallery.on( 'dragEnd.flickity', function( event, pointer ) {
    $(this).removeClass('is-dragging');
  })

  $gallery.magnificPopup({
    delegate: '.lightbox-img, .lightbox-video',
    callbacks: {
      elementParse: function(item) {
      if(item.el.context.className == 'lightbox-video') {
          item.type = 'iframe';
        } else {
          item.type = 'image';
        }
      }
    },    
    type: 'image',
    closeBtnInside:false,
    gallery:{
      enabled:true
    }
  });


  /* Lightbox popup
  -------------------------------------------------------*/
  $('.lightbox-img, .lightbox-video').magnificPopup({
    callbacks: {
      elementParse: function(item) {
      if(item.el.context.className == 'lightbox-video') {
          item.type = 'iframe';
        } else {
          item.type = 'image';
        }
      }
    },
    type: 'image',
    closeBtnInside:false,
    gallery: {
      enabled:true
    },
    image: {
      titleSrc: 'title',
      verticalFit: true
    }
  });

  // Single video lightbox
  $('.single-video-lightbox').magnificPopup({
    type: 'iframe',
    closeBtnInside:false,
    tLoading: 'Loading image #%curr%...'
  });


  /* Final Countdown (Coming soon)
  -------------------------------------------------------*/
  var dataEnd = $("#countdown").attr('data-end-date');
  $("#countdown")
  .countdown(dataEnd, function(event) {
    var $this = $(this).html(event.strftime(''
    + '<div><span>%D</span><label>Days</label></div>'
    + '<div><span>%H</span><label>Hours</label></div>'
    + '<div><span>%M</span><label>Minutes</label></div>'
    + '<div><span>%S</span><label>Seconds</label></div>'));
  });


  /* Full Height Container
  -------------------------------------------------------*/

  function container_full_height_init(){
    (function($){
      $(".container-full-height").height($(window).height());
    })(jQuery);
  }

  /* Typing Text
  -------------------------------------------------------*/
  $(function(){
    $("#typed").typed({
      stringsElement: $('#typing-text'),
      typeSpeed: 30,
      backDelay: 1500,
      loop: true
    });
  });  


  /* Progress Bars
  -------------------------------------------------------*/
  var $section = $('.progress').eq(0).parents('section').appear(function() {

    function loadDaBars() {
      $('.progress').each(function(index) {
        var $this = $(this),
        bar = $this.find('.progress-bar'),
        barWidth = bar.attr('aria-valuenow');
        setTimeout(function() {              
          bar.css({"width": barWidth + '%'});
        }, index * 200);
      });
    };
    loadDaBars();
    
  });


  /* Pie Charts
  -------------------------------------------------------*/
  $('.chart').appear(function() {

    $(this).easyPieChart({

      animate:{
      duration:1500,
      enabled:true
      },
      scaleColor:false,
      trackColor:'#f5f5f5',
      easing: 'easeOutBounce',
      lineWidth: 3,
      size: 160,
      lineCap: 'square',

      onStep: function(from, to, percent) {
        $(this.el).find('.percent').text(Math.round(percent));
      }
    });
    var chart = window.chart = $('.chart').data('easyPieChart');
    $('.js_update').on('click', function() {
      chart.update(Math.random()*200-100);
    });
  });

  
  /* Accordion
  -------------------------------------------------------*/
  function toggleChevron(e) {
    $(e.target)
    .prev('.panel-heading')
    .find("a")
    .toggleClass('plus minus');
  }
  $('#accordion').on('hide.bs.collapse', toggleChevron);
  $('#accordion').on('show.bs.collapse', toggleChevron);


  /* Toggle
  -------------------------------------------------------*/
  var allToggles = $(".toggle > .panel-content").hide();
  
  $(".toggle").on('click', '> .acc-panel > a', function(){

    if ($(this).hasClass("active")) {
      $(this).parent().next().slideUp("easeOutExpo");
      $(this).removeClass("active");
    }

    else {
      $(this).parent().next(".panel-content");
      $(this).addClass("active");
      $(this).parent().next().slideDown("easeOutExpo");
    }
    
    return false;       
  });


  /* Nav Toggles
  -------------------------------------------------------*/
  $(".nav-item-submenu").hide();

  $(".nav-item-toggle").on('click', '> a', function(e){
    e.preventDefault();
    if ($(this).hasClass("active")) {
      $(this).next().slideUp("easeOutExpo");
      $(this).removeClass("active");
    }

    else {
      $(this).next(".nav-item-submenu");
      $(this).addClass("active");
      $(this).next().slideDown("easeOutExpo");
    }

  });


  /* Tooltip
  -------------------------------------------------------*/
  $(function () {
    $('[data-toggle="tooltip"]').tooltip({container: 'body'});
  })


  /* Square div (Oslo)
  -------------------------------------------------------*/
  function squareDiv() {
    var a = $('.work-item-description');
    var b = $('#square-div');
    a.width(b.width());
    a.height(b.height());
  }


  /* Portfolio Isotope
  -------------------------------------------------------*/

  var $portfolio = $('#portfolio-grid');
  $portfolio.imagesLoaded( function() {     
    $portfolio.isotope({
      isOriginLeft: true,
      stagger: 30
    });
    $portfolio.isotope();
  });


  /* Masonry
  -------------------------------------------------------*/
  function initMasonry(){

    var $masonry = $('#masonry-grid');
    $masonry.imagesLoaded( function() {
      $masonry.isotope({
        itemSelector: '.work-item',
        layoutMode: 'masonry',
        percentPosition: true,
        resizable: false,
        isResizeBound: false,
        masonry: { columnWidth: '.work-item.quarter' }
      });
    });

    $masonry.isotope();
  }

  // Isotope filter
  var $portfolioFilter = $('#portfolio-grid, #masonry-grid');
  $('.portfolio-filter').on( 'click', 'a', function(e) {
    e.preventDefault();
    var filterValue = $(this).attr('data-filter');
    $portfolioFilter.isotope({ filter: filterValue });
    $('.portfolio-filter a').removeClass('active');
    $(this).closest('a').addClass('active');
  });


  /* Scroll reveal
  -------------------------------------------------------*/
  $(".animated-from-left").wrapInner('<div class="animation-wrap"><div class="animated-left-full"></div></div>');
  window.sr = ScrollReveal();

  sr.reveal('.animated-left-full', {
    reset: false,
    duration: 1000,
    mobile: false,
    delay: 400,
    scale: 1,
    origin: 'left',
    distance: '100%',
    viewOffset: { top: 100, right: 0, bottom: 0, left: 0 }
  });

  sr.reveal('.animated-bottom', {
    reset: false,
    duration: 1000,
    mobile: false,
    delay: 400,
    scale: 1,
    origin: 'bottom',
    viewOffset: { top: 100, right: 0, bottom: 0, left: 0 }
  });

  sr.reveal('.animated-left', {
    reset: false,
    duration: 1000,
    mobile: false,
    delay: 400,
    scale: 1,
    origin: 'left',
    distance: '100px',
    viewOffset: { top: 100, right: 0, bottom: 0, left: 0 }
  });

  sr.reveal('.animated-right', {
    reset: false,
    duration: 1000,
    mobile: false,
    delay: 400,
    scale: 1,
    origin: 'right',
    distance: '100px',
    viewOffset: { top: 100, right: 0, bottom: 0, left: 0 }
  });

  sr.reveal('.animated-top', {
    reset: false,
    duration: 1000,
    mobile: false,
    delay: 400,
    scale: 1,
    origin: 'top',
    viewOffset: { top: 100, right: 0, bottom: 0, left: 0 }
  });

  sr.reveal('.animated-queue', {
    reset: false,
    mobile: false,
    scale: 1,
    easing: 'ease-in-out',
    origin: 'bottom',
    viewOffset: { top: 200, right: 0, bottom: 0, left: 0 },
    duration: 1000 }, 50);



  /* Grid/list Switch
  -------------------------------------------------------*/
  function get_grid(){
    $('.list').removeClass('list-active');
    $('.grid').addClass('grid-active');
    $('.product-item').animate({opacity:0},function(){
      $('.shop-catalogue').removeClass('list-view').addClass('grid-view');
      $('.product').addClass('product-grid').removeClass('product-list');
      $('.product-item').stop().animate({opacity:1});
    });
  }

  function get_list(){
    $('.grid').removeClass('grid-active');
    $('.list').addClass('list-active');
    $('.product-item').animate({opacity:0},function(){
      $('.shop-catalogue').removeClass('grid-view').addClass('list-view');
      $('.product').addClass('product-list').removeClass('product-grid');
      $('.product-item').stop().animate({opacity:1});
    });
  }

  $('#list').on('click', function(e){
    e.preventDefault(); 
    get_list();
  });

  $('#grid').on('click', function(e){
    e.preventDefault(); 
    get_grid();
  });

  /* FitVIds
  -------------------------------------------------------*/
  $("body").fitVids();

  /* Scroll to Top
  -------------------------------------------------------*/
  (function() {
    var docElem = document.documentElement,
      didScroll = false;
      document.querySelector( '#back-to-top' );
    function init() {
      window.addEventListener( 'scroll', function() {
        if( !didScroll ) {
          didScroll = true;
          setTimeout( scrollPage, 50 );
        }
      }, false );
    }    
  });

  function scrollToTop() {
    var scroll = $(window).scrollTop();
    var $backToTop = $("#back-to-top");
    if (scroll >= 50) {
      $backToTop.addClass("show");
    } else {
      $backToTop.removeClass("show");
    }
  }

  $('a[href="#top"]').on('click',function(){
    $('html, body').animate({scrollTop: 0}, 1350, "easeInOutQuint");
    return false;
  });


})(jQuery);

/**
 * Load more functionality
 */
jQuery('#load-more').click(function(){
	
	var $this = jQuery(this),
		url = $this.attr('href'),
		btnText = jQuery(this).find('span');

	btnText.text($this.attr('data-loading'));
	
	jQuery.get(url, function(data){
		var $data = jQuery(data).find('.works-grid > .work-item');

		imagesLoaded( $data, function(){

			jQuery('#portfolio-grid').append( $data ).isotope( 'appended', $data );
			
			setTimeout(function(){
				jQuery(window).trigger('resize');
				$this.remove();
			}, 600);
			
		});
		
	});
	
	return false;
});

jQuery('#blog-load-more').click(function(){
	
	var $this = jQuery(this),
		url = $this.attr('href'),
		btnText = jQuery(this).find('span');

	btnText.text($this.attr('data-loading'));
	
	jQuery.get(url, function(data){
		var $data = jQuery(data).find('.blog-masonry > .masonry-item');

		imagesLoaded( $data, function(){

			jQuery('.blog-masonry').append( $data ).isotope( 'appended', $data );
			
			setTimeout(function(){
				jQuery(window).trigger('resize');
				$this.remove();
			}, 600);
			
		});
		
	});
	
	return false;
});


/* Style Switcher
-------------------------------------------------------*/

/*jQuery(".main-wrapper").after(
  '<div id="customizer" class="s-close"><span class="corner"><i class="fa fa-cog"></i></span><div id="options" class="text-center"><a href="https://themeforest.net/item/gaze-premium-multipurpose-html-template/19234009?ref=DeoThemes" class="btn btn-md btn-color mt-40 mb-40"><span>Purchase Now</span></a><h6 class="uppercase">Select Demo</h6><ul class="demo-list clearfix">' +
  '<li><a href="index-tokyo.html" target="_blank"><img src="img/demos/tokyo.jpg" alt=""></a></li>' +
  '<li><a href="index-sydney.html" target="_blank"><img src="img/demos/sydney.jpg" alt=""></a></li>' +
  '<li><a href="index-ny.html" target="_blank"><img src="img/demos/ny.jpg" alt=""></a></li>' +
  '<li><a href="index-paris.html" target="_blank"><img src="img/demos/paris.jpg" alt=""></a></li>' +
  '<li><a href="index-toronto.html" target="_blank"><img src="img/demos/toronto.jpg" alt=""></a></li>' +
  '<li><a href="index-melbourne.html" target="_blank"><img src="img/demos/melbourne.jpg" alt=""></a></li>' +
  '<li><a href="index-vancouver.html" target="_blank"><img src="img/demos/vancouver.jpg" alt=""></a></li>' +
  '<li><a href="index-athens.html" target="_blank"><img src="img/demos/athens.jpg" alt=""></a></li>' +
  '<li><a href="index-milan.html" target="_blank"><img src="img/demos/milan.jpg" alt=""></a></li>' +
  '<li><a href="index-oslo.html" target="_blank"><img src="img/demos/oslo.jpg" alt=""></a></li>' +
  '<li><a href="index-vienna.html" target="_blank"><img src="img/demos/vienna.jpg" alt=""></a></li>' +
  '<li><a href="index-madrid.html" target="_blank"><img src="img/demos/madrid.jpg" alt=""></a></li>' +
  '<li><a href="index-amsterdam.html" target="_blank"><img src="img/demos/amsterdam.jpg" alt=""></a></li>' +
  '<li><a href="index-stockholm.html" target="_blank"><img src="img/demos/stockholm.jpg" alt=""></a></li>' +
  '<li><a href="index-berlin.html" target="_blank"><img src="img/demos/berlin.jpg" alt=""></a></li>' +
  '<li><a href="index-manila.html" target="_blank"><img src="img/demos/manila.jpg" alt=""></a></li>' +
  '<li><a href="index-shanghai.html" target="_blank"><img src="img/demos/shanghai.jpg" alt=""></a></li>' +
  '<li><a href="index-london.html" target="_blank"><img src="img/demos/london.jpg" alt=""></a></li>' +
  '<li><a href="coming-soon.html" target="_blank"><img src="img/demos/coming_soon.jpg" alt=""></a></li>' +
  '</ul></div></div>'
);

jQuery(".corner").on('click',function (){
	jQuery("#customizer").toggleClass("s-open");
});*/