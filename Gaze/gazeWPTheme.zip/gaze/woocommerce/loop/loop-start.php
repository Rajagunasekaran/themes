<?php 
	/**
	 * @author  TommusRhodus
	 * @package WooCommerce/Templates
	 * @version 9.9.9
	 */
	  global $wp_query;
?>

<div class="clearfix woocommerce-loop-start"></div>

<div class="woocommerce catalogue shop-catalogue grid-view">
	<div class="row items-grid">
		
<?php if(!( 'yes' == $wp_query->is_shortcode )) : ?>
		<div class="col-md-9">
		
		<?php 
			/**
			 * woocommerce_before_shop_loop hook.
			 *
			 * @hooked wc_print_notices - 10
			 * @hooked woocommerce_result_count - 20
			 * @hooked woocommerce_catalog_ordering - 30
			 */
			do_action( 'woocommerce_before_shop_loop' );
		?>
		
		<div class="clearfix"></div>
			
		<div class="row">
<?php endif;
		