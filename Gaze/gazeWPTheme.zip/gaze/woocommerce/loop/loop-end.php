<?php 
	/**
	 * @author  TommusRhodus
	 * @package WooCommerce/Templates
	 * @version 9.9.9
	 */
	 global $wp_query;
if(!( 'yes' == $wp_query->is_shortcode )) : ?>

	</div></div><?php get_sidebar( 'shop' ); ?>
	
<?php endif; ?>

</div></div>