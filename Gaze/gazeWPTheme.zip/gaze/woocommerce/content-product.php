<?php
	/**
	 * @author  TommusRhodus
	 * @package WooCommerce/Templates
	 * @version 9.9.9
	 */
	if ( ! defined( 'ABSPATH' ) ) {
		exit; // Exit if accessed directly
	}
	
	global $product;
	
	// Ensure visibility
	if ( empty( $product ) || ! $product->is_visible() ) {
		return;
	}
?>

<div class="col-md-4 col-xs-6 product product-grid">
	<div class="product-item">
		
		<div class="product-img">
			
			<a href="<?php the_permalink(); ?>">
				<?php
					/**
					 * woocommerce_before_shop_loop_item_title hook.
					 *
					 * @hooked woocommerce_show_product_loop_sale_flash - 10
					 * @hooked woocommerce_template_loop_product_thumbnail - 10
					 */
					do_action( 'woocommerce_before_shop_loop_item_title' );
				?>
			</a>
			
			<div class="product-actions">
				<a href="<?php echo esc_url( add_query_arg( 'add-to-cart', get_the_ID(), get_permalink() ) ); ?>" class="product-add-to-compare" data-toggle="tooltip" data-placement="bottom" title="<?php esc_attr_e( 'Add to cart', 'gaze' ); ?>">
					<i class="fa fa-shopping-cart"></i>
				</a>
			</div>
			
			<a href="<?php the_permalink(); ?>" class="product-quickview"><?php esc_html_e( 'Quick View', 'gaze' ); ?></a>
			
		</div>
		
		<div class="product-details">
			
			<?php
				/**
				 * woocommerce_shop_loop_item_title hook.
				 *
				 * @hooked woocommerce_template_loop_product_title - 10
				 */
				do_action( 'woocommerce_shop_loop_item_title' );
			
				/**
				 * woocommerce_after_shop_loop_item_title hook.
				 *
				 * @hooked woocommerce_template_loop_rating - 5
				 * @hooked woocommerce_template_loop_price - 10
				 */
				do_action( 'woocommerce_after_shop_loop_item_title' );
			?>
			
		</div>
		
	</div>
</div>