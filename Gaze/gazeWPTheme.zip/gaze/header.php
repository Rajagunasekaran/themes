<!doctype html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<?php 
	get_template_part( 'inc/content', 'preloader' ); 
	get_template_part( 'inc/content-header', 'side-nav' ); 
?>

<div class="main-wrapper oh">

<?php get_template_part( 'inc/layout-header', ebor_get_header_layout() ); ?>

<div class="content-wrapper oh">

<?php if( class_exists( 'woocommerce' ) && 'shop' == ebor_get_header_layout() ) : ?>

<div class="container">
	<?php woocommerce_breadcrumb( array( 'delimiter' => '', 'wrap_before' => '<ol class="breadcrumb">', 'wrap_after' => '</ol>', 'before' => '<li>', 'after' => '</li>' ) ); ?>
</div>

<?php endif;