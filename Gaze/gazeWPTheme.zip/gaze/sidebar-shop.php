<?php if( is_active_sidebar( 'shop' ) ) : ?>

	<aside class="col-md-3 sidebar">
		<?php dynamic_sidebar( 'shop' ); ?>
	</aside>

<?php endif;