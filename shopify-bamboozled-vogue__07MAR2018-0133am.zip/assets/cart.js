/* for free shipping charge */
var minOrderAmt = 50;
var n_maxOrderQty = 10;
var in_maxOrderQty = 6;
var show_popup = 1, shipto_country = '';

$('form.cart-form input[name="checkout"]').click(function(ev){
  if(cart_amount < minOrderAmt && show_popup) {
    ev.preventDefault();
    $.featherlight($('#shipping-info'));
    return false;
  }
  sessionStorage.setItem("shipto", "");
  return true;
});

$(document).on('click', '#shipping-info a.continue', function(ev){
  show_popup = 0;
  $('form.cart-form input[name="checkout"]').click();
});

$(document).on('click', '.featherlight .shiping-to', function(ev){
  shipto_country = $('.featherlight #shipto_country').val();
  shipto_country = parseInt(shipto_country);
  if(shipto_country != 0) {
    sessionStorage.setItem("shipto", shipto_country);
    $.featherlight.current().close();
  }
  console.log(sessionStorage.getItem("shipto"));
  
  var maxqty = sessionStorage.getItem("shipto") == 1 ? n_maxOrderQty : in_maxOrderQty;
  
  if(cartQty > maxqty){
    $('.cart-order-info').removeClass('hide');
    $('.cart-totals .button').prop('disabled', true).addClass('hide');
  } else {
    $('.cart-order-info').addClass('hide');
    $('.cart-totals .button').prop('disabled', false).removeClass('hide');
  }
});

$(function(){
  console.log(sessionStorage.getItem("shipto"));
  var shippingcountry_fl = $('#shipping-country-popup');
  if(shippingcountry_fl.length && template == 'cart' && sessionStorage.getItem("shipto") == ''){
    $.featherlight($('#shipping-country-popup'), {variant: 'shipping-country-featherlight', closeOnClick: false, closeOnEsc: false});
  }
  
  var maxqty = sessionStorage.getItem("shipto") == 1 ? n_maxOrderQty : in_maxOrderQty;

  if(cartQty > maxqty){
    $('.cart-order-info').removeClass('hide');
    $('.cart-totals .button').prop('disabled', true).addClass('hide');
  } else {
    $('.cart-order-info').addClass('hide');
    $('.cart-totals .button').prop('disabled', false).removeClass('hide');
  }
});
