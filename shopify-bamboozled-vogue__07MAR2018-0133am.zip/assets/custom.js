$(function() {
  
  /*toggle sub menu*/
  $('.navigation-secondary-list li a.has-sublist').click(function(ev) {
    $('.navigation-sublist').slideUp();
    if(!$(this).hasClass('sub-nav-open')) {
      ev.preventDefault();
      $('.navigation-secondary-list li a.has-sublist').removeClass('sub-nav-open');
      $(this).addClass('sub-nav-open');
      $(this).next('.navigation-sublist').slideDown(); 
    } else {
      $('.navigation-secondary-list li a.has-sublist').removeClass('sub-nav-open');
      return true;
    }
  });
  
});

// newsletter popup
var newsletter_fl = $('#newsletter-popup');

if(newsletter_fl.length && template == 'index' ){
  setTimeout(function(){
    $.featherlight(newsletter_fl, {variant: 'newsletter-featherlight'});
  }, 1000);
}

// alert messanger
function showStatusMessage(msg, timeout){
  timeout = timeout || 2000;
  $('.status-msg .inner-msg').html(msg);
  $('.status-msg').addClass('visible');
  setTimeout(function(){$('.status-msg').removeClass('visible');}, timeout);
}


