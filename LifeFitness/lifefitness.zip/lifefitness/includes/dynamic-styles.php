<?php

function lifefitness_ninzio_include_dynamic_styles() {
wp_enqueue_style('dynamic-styles', get_template_directory_uri() . '/css/dynamic-styles.css');

	lifefitness_ninzio_global_variables();

	if (defined('THEME_PANEL')) {
		theme_panel_demo_configurations_dynamic_styles();
	}
	
	$lifefitness_ninzio_main_color = (isset($GLOBALS['lifefitness_ninzio']['main-color']) && !empty($GLOBALS['lifefitness_ninzio']['main-color'])) ? $GLOBALS['lifefitness_ninzio']['main-color'] : '#16c3b1';

	$nz_h1_header_social_links = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-social-links']) && $GLOBALS['lifefitness_ninzio']['h1-desk-social-links'] == 1) ? "true" : "false";
	$nz_h3_header_social_links = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-social-links']) && $GLOBALS['lifefitness_ninzio']['h3-desk-social-links'] == 1) ? "true" : "false";
	$nz_h5_header_social_links = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-social-links']) && $GLOBALS['lifefitness_ninzio']['h5-desk-social-links'] == 1) ? "true" : "false";

	/*	STYLING OPTIONS
	/*-------------------------*/

		$nz_site_back_col   = (isset($GLOBALS['lifefitness_ninzio']['site-background']['background-color']) && $GLOBALS['lifefitness_ninzio']['site-background']['background-color']) ? $GLOBALS['lifefitness_ninzio']['site-background']['background-color'] : "#ffffff";
		$nz_site_back_img   = (isset($GLOBALS['lifefitness_ninzio']['site-background']['background-image']) && $GLOBALS['lifefitness_ninzio']['site-background']['background-image']) ? esc_url($GLOBALS['lifefitness_ninzio']['site-background']['background-image']) : "";
		$nz_site_back_r     = (isset($GLOBALS['lifefitness_ninzio']['site-background']['background-repeat']) && $GLOBALS['lifefitness_ninzio']['site-background']['background-repeat']) ? $GLOBALS['lifefitness_ninzio']['site-background']['background-repeat'] : "no-repeat";
		$nz_site_back_s     = (isset($GLOBALS['lifefitness_ninzio']['site-background']['background-size']) && $GLOBALS['lifefitness_ninzio']['site-background']['background-size']) ? $GLOBALS['lifefitness_ninzio']['site-background']['background-size'] : "inherit";
		$nz_site_back_a     = (isset($GLOBALS['lifefitness_ninzio']['site-background']['background-attachment']) && $GLOBALS['lifefitness_ninzio']['site-background']['background-attachment']) ? $GLOBALS['lifefitness_ninzio']['site-background']['background-attachment'] : "inherit";
		$nz_site_back_p     = (isset($GLOBALS['lifefitness_ninzio']['site-background']['background-position']) && $GLOBALS['lifefitness_ninzio']['site-background']['background-position']) ? $GLOBALS['lifefitness_ninzio']['site-background']['background-position'] : "left top";

	/*	TYPOGRAPHY OPTIONS
	/*-------------------------*/
		
		$nz_main_font_size          = (isset($GLOBALS['lifefitness_ninzio']['main-typo']['font-size']) && $GLOBALS['lifefitness_ninzio']['main-typo']['font-size']) ? $GLOBALS['lifefitness_ninzio']['main-typo']['font-size'] : "13px";
		$nz_main_line_height        = (isset($GLOBALS['lifefitness_ninzio']['main-typo']['line-height']) && $GLOBALS['lifefitness_ninzio']['main-typo']['line-height']) ? $GLOBALS['lifefitness_ninzio']['main-typo']['line-height'] : "22px";
		$nz_main_font_family        = (isset($GLOBALS['lifefitness_ninzio']['main-typo']['font-family']) && $GLOBALS['lifefitness_ninzio']['main-typo']['font-family']) ? $GLOBALS['lifefitness_ninzio']['main-typo']['font-family'] : "Arial, Helvetica, sans-serif";
		$nz_headings_font_family    = (isset($GLOBALS['lifefitness_ninzio']['headings-typo']['font-family']) && $GLOBALS['lifefitness_ninzio']['headings-typo']['font-family']) ? $GLOBALS['lifefitness_ninzio']['headings-typo']['font-family'] : $nz_main_font_family;
		$nz_headings_text_transform = (isset($GLOBALS['lifefitness_ninzio']['headings-typo']['text-transform']) && $GLOBALS['lifefitness_ninzio']['headings-typo']['text-transform']) ? $GLOBALS['lifefitness_ninzio']['headings-typo']['text-transform'] : "none";
		$nz_h1_font_size            = (isset($GLOBALS['lifefitness_ninzio']['h1-typo']['font-size']) && $GLOBALS['lifefitness_ninzio']['h1-typo']['font-size']) ? $GLOBALS['lifefitness_ninzio']['h1-typo']['font-size'] : "50px";
		$nz_h1_line_height          = (isset($GLOBALS['lifefitness_ninzio']['h1-typo']['line-height']) && $GLOBALS['lifefitness_ninzio']['h1-typo']['line-height']) ? $GLOBALS['lifefitness_ninzio']['h1-typo']['line-height'] : "60px";
		$nz_h2_font_size            = (isset($GLOBALS['lifefitness_ninzio']['h2-typo']['font-size']) && $GLOBALS['lifefitness_ninzio']['h2-typo']['font-size']) ? $GLOBALS['lifefitness_ninzio']['h2-typo']['font-size'] : "40px";
		$nz_h2_line_height          = (isset($GLOBALS['lifefitness_ninzio']['h2-typo']['line-height']) && $GLOBALS['lifefitness_ninzio']['h2-typo']['line-height']) ? $GLOBALS['lifefitness_ninzio']['h2-typo']['line-height'] : "50px";
		$nz_h3_font_size            = (isset($GLOBALS['lifefitness_ninzio']['h3-typo']['font-size']) && $GLOBALS['lifefitness_ninzio']['h3-typo']['font-size']) ? $GLOBALS['lifefitness_ninzio']['h3-typo']['font-size'] : "30px";
		$nz_h3_line_height          = (isset($GLOBALS['lifefitness_ninzio']['h3-typo']['line-height']) && $GLOBALS['lifefitness_ninzio']['h3-typo']['line-height']) ? $GLOBALS['lifefitness_ninzio']['h3-typo']['line-height'] : "40px";
		$nz_h4_font_size            = (isset($GLOBALS['lifefitness_ninzio']['h4-typo']['font-size']) && $GLOBALS['lifefitness_ninzio']['h4-typo']['font-size']) ? $GLOBALS['lifefitness_ninzio']['h4-typo']['font-size'] : "24px";
		$nz_h4_line_height          = (isset($GLOBALS['lifefitness_ninzio']['h4-typo']['line-height']) && $GLOBALS['lifefitness_ninzio']['h4-typo']['line-height']) ? $GLOBALS['lifefitness_ninzio']['h4-typo']['line-height'] : "34px";
		$nz_h5_font_size            = (isset($GLOBALS['lifefitness_ninzio']['h5-typo']['font-size']) && $GLOBALS['lifefitness_ninzio']['h5-typo']['font-size']) ? $GLOBALS['lifefitness_ninzio']['h5-typo']['font-size'] : "18px";
		$nz_h5_line_height          = (isset($GLOBALS['lifefitness_ninzio']['h5-typo']['line-height']) && $GLOBALS['lifefitness_ninzio']['h5-typo']['line-height']) ? $GLOBALS['lifefitness_ninzio']['h5-typo']['line-height'] : "28px";
		$nz_h6_font_size            = (isset($GLOBALS['lifefitness_ninzio']['h6-typo']['font-size']) && $GLOBALS['lifefitness_ninzio']['h6-typo']['font-size']) ? $GLOBALS['lifefitness_ninzio']['h6-typo']['font-size'] : "16px";
		$nz_h6_line_height          = (isset($GLOBALS['lifefitness_ninzio']['h6-typo']['line-height']) && $GLOBALS['lifefitness_ninzio']['h6-typo']['line-height']) ? $GLOBALS['lifefitness_ninzio']['h6-typo']['line-height'] : "26px";

	/*	HEADER
	/*-------------------------*/

		$nz_header_bar         = (isset($GLOBALS['lifefitness_ninzio']['header-bar']) && $GLOBALS['lifefitness_ninzio']['header-bar'] == 1) ? "true" : "false";
		$nz_header_bar_color_1 = (isset($GLOBALS['lifefitness_ninzio']['header-bar-color-1']) && $GLOBALS['lifefitness_ninzio']['header-bar-color-1']) ? $GLOBALS['lifefitness_ninzio']['header-bar-color-1'] : "#01b0ef";
		$nz_header_bar_color_2 = (isset($GLOBALS['lifefitness_ninzio']['header-bar-color-2']) && $GLOBALS['lifefitness_ninzio']['header-bar-color-2']) ? $GLOBALS['lifefitness_ninzio']['header-bar-color-2'] : "#fdab2e";
		$nz_header_bar_color_3 = (isset($GLOBALS['lifefitness_ninzio']['header-bar-color-3']) && $GLOBALS['lifefitness_ninzio']['header-bar-color-3']) ? $GLOBALS['lifefitness_ninzio']['header-bar-color-3'] : "#fd5c4e";

		$nz_mob_height = (isset($GLOBALS['lifefitness_ninzio']['mob-height']) && $GLOBALS['lifefitness_ninzio']['mob-height']) ? $GLOBALS['lifefitness_ninzio']['mob-height'] : "50";

		// VERSION 1

		$nz_h1_desk_height                   = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-height']) && $GLOBALS['lifefitness_ninzio']['h1-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h1-desk-height'] : "90";
		$nz_h1_fixed_height                  = (isset($GLOBALS['lifefitness_ninzio']['h1-fixed-height']) && $GLOBALS['lifefitness_ninzio']['h1-fixed-height']) ? $GLOBALS['lifefitness_ninzio']['h1-fixed-height'] : "90";
		$nz_h1_header_top_back_color         = (isset($GLOBALS['lifefitness_ninzio']['h1-header-top-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-header-top-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-header-top-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-header-top-back-color']['alpha']) : "#16c3b1";
		$nz_h1_header_top_border_color       = (isset($GLOBALS['lifefitness_ninzio']['h1-header-top-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-header-top-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-header-top-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-header-top-border-color']['alpha']) : "";
		
		$nz_h1_header_top_menu_color_reg     = (isset($GLOBALS['lifefitness_ninzio']['h1-header-top-menu-color']['regular']) && !empty($GLOBALS['lifefitness_ninzio']['h1-header-top-menu-color']['regular'])) ? $GLOBALS['lifefitness_ninzio']['h1-header-top-menu-color']['regular'] : '#999999';
		$nz_h1_header_top_menu_color_hov     = (isset($GLOBALS['lifefitness_ninzio']['h1-header-top-menu-color']['hover']) && !empty($GLOBALS['lifefitness_ninzio']['h1-header-top-menu-color']['hover'])) ? $GLOBALS['lifefitness_ninzio']['h1-header-top-menu-color']['hover'] : '#16c3b1';
		
		$nz_h1_header_top_menu_font_weight    = (isset($GLOBALS['lifefitness_ninzio']['h1-header-top-menu-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h1-header-top-menu-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h1-header-top-menu-typo']['font-weight'] : "normal";
		$nz_h1_header_top_menu_font_size      = (isset($GLOBALS['lifefitness_ninzio']['h1-header-top-menu-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h1-header-top-menu-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h1-header-top-menu-typo']['font-size'] : "14px";
		$nz_h1_header_top_menu_text_transform = (isset($GLOBALS['lifefitness_ninzio']['h1-header-top-menu-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h1-header-top-menu-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h1-header-top-menu-typo']['text-transform'] : "none";

		$nz_h1_top_button_text_color         = (isset($GLOBALS['lifefitness_ninzio']['h1-top-button-text-color']) && !empty($GLOBALS['lifefitness_ninzio']['h1-top-button-text-color'])) ? $GLOBALS['lifefitness_ninzio']['h1-top-button-text-color'] : '#999999';
		$nz_h1_top_button_back_color         = (isset($GLOBALS['lifefitness_ninzio']['h1-top-button-back-color']) && !empty($GLOBALS['lifefitness_ninzio']['h1-top-button-back-color'])) ? $GLOBALS['lifefitness_ninzio']['h1-top-button-back-color'] : '#ffffff';

		$nz_h1_desk_sidebar_toggle_color         = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-sidebar-toggle-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-sidebar-toggle-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-sidebar-toggle-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-sidebar-toggle-color']['alpha']) : "transparent";
		$nz_h1_desk_sidebar_toggle_border_color  = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-sidebar-toggle-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-sidebar-toggle-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-sidebar-toggle-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-sidebar-toggle-border-color']['alpha']) : "transparent";

		$nz_h1_desk_back_color               = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-back-color']['alpha']) : "#ffffff";
		$nz_h1_desk_border_color             = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-border-color']['alpha']) : "";
		$nz_h1_desk_separator_color          = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-separator-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-separator-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-separator-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-separator-color']['alpha']) : "";
		$nz_h1_desk_cart_back_color          = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-cart-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-cart-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-cart-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-cart-back-color']['alpha']) : "";
		$nz_h1_desk_cart_text_color          = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-cart-text-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-cart-text-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-cart-text-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-cart-text-color']['alpha']) : "";
		$nz_h1_desk_menu_effect_color        = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-menu-effect-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-menu-effect-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-menu-effect-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-menu-effect-color']['alpha']) : "#16c3b1";
		$nz_h1_desk_menu_color_reg           = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-menu-color']['regular']) && $GLOBALS['lifefitness_ninzio']['h1-desk-menu-color']['regular']) ? $GLOBALS['lifefitness_ninzio']['h1-desk-menu-color']['regular'] : "#999999";
		$nz_h1_desk_menu_color_hov           = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-menu-color']['hover']) && $GLOBALS['lifefitness_ninzio']['h1-desk-menu-color']['hover']) ? $GLOBALS['lifefitness_ninzio']['h1-desk-menu-color']['hover'] : "#999999";
		$nz_h1_desk_submenu_back_color       = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-back-color']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-back-color'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-submenu-back-color'] : '#292929';
		$nz_h1_desk_submenu_color_reg        = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-color']['regular']) && $GLOBALS['lifefitness_ninzio']['h1-desk-submenu-color']['regular']) ? $GLOBALS['lifefitness_ninzio']['h1-desk-submenu-color']['regular'] : "#999999";
		$nz_h1_desk_submenu_color_hov        = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-color']['hover']) && $GLOBALS['lifefitness_ninzio']['h1-desk-submenu-color']['hover']) ? $GLOBALS['lifefitness_ninzio']['h1-desk-submenu-color']['hover'] : "#ffffff";

		$nz_h1_desk_menu_m = (class_exists( 'ReduxFramework' )) ? (isset($GLOBALS['lifefitness_ninzio']['h1-desk-menu-m']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-menu-m'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-menu-m'] : '0' : '20';
		$nz_h1_desk_menu_m_1600              = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-menu-m-1600']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-menu-m-1600'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-menu-m-1600'] : $nz_h1_desk_menu_m;
		$nz_h1_desk_ls_w    	             = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-lw']['width']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-lw']['width'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-lw']['width'] : "149px"; 
		$nz_h1_desk_menu_font_weight         = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-menu-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-menu-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-menu-typo']['font-weight'] : "normal";
		$nz_h1_desk_menu_font_size           = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-menu-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-menu-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-menu-typo']['font-size'] : "14px";
		$nz_h1_desk_menu_font_family         = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-menu-typo']['font-family']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-menu-typo']['font-family'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-menu-typo']['font-family'] : "Arial, Helvetica, sans-serif";
		$nz_h1_desk_menu_text_transform      = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-menu-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-menu-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-menu-typo']['text-transform'] : "none";
		$nz_h1_desk_submenu_font_size        = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['font-size'] : "14px";
		$nz_h1_desk_submenu_font_weight      = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['font-weight'] : "400";
		$nz_h1_desk_submenu_line_height      = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['line-height']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['line-height'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['line-height'] : "24px";
		$nz_h1_desk_submenu_font_family      = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['font-family']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['font-family'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['font-family'] : "Arial, Helvetica, sans-serif";
		$nz_h1_desk_submenu_text_transform   = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-submenu-typo']['text-transform'] : "none";
		$nz_h1_desk_megamenu_text_transform  = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-typo']['text-transform'] : $nz_h1_desk_menu_text_transform;
		$nz_h1_desk_megamenu_font_weight     = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-typo']['font-weight'] : $nz_h1_desk_menu_font_weight;
		$nz_h1_desk_megamenu_font_size       = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-typo']['font-size'] : $nz_h1_desk_menu_font_size;
		$nz_h1_desk_megamenu_color           = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-typo']['color']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-typo']['color'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-typo']['color'] : "#ffffff";
		$nz_h1_desk_megamenu_top_border      = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-border']) && !empty($GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-border'])) ? $GLOBALS['lifefitness_ninzio']['h1-desk-megamenu-top-border'] : "";

		$nz_h1_megamenu_buttons_back_color   = (isset($GLOBALS['lifefitness_ninzio']['h1-megamenu-buttons-back-color']) && !empty($GLOBALS['lifefitness_ninzio']['h1-megamenu-buttons-back-color'])) ? $GLOBALS['lifefitness_ninzio']['h1-megamenu-buttons-back-color'] : '#16c3b1';
		$nz_h1_megamenu_buttons_text_color   = (isset($GLOBALS['lifefitness_ninzio']['h1-megamenu-buttons-text-color']) && !empty($GLOBALS['lifefitness_ninzio']['h1-megamenu-buttons-text-color'])) ? $GLOBALS['lifefitness_ninzio']['h1-megamenu-buttons-text-color'] : '#ffffff';

		$nz_h1_desk_fixed_back_color         = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-fixed-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-fixed-back-color']['alpha']) : $nz_h1_desk_back_color;
		$nz_h1_desk_fixed_separator_color    = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-separator-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-fixed-separator-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-separator-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-fixed-separator-color']['alpha']) : "";
		
		$nz_h1_desk_fixed_cart_back_color    = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-cart-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-fixed-cart-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-cart-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-fixed-cart-back-color']['alpha']) : $nz_h1_desk_cart_back_color;
		$nz_h1_desk_fixed_cart_text_color    = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-cart-text-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-fixed-cart-text-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-cart-text-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-fixed-cart-text-color']['alpha']) : $nz_h1_desk_cart_text_color;

		$nz_h1_desk_fixed_menu_effect_color  = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-menu-effect-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-fixed-menu-effect-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-menu-effect-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-fixed-menu-effect-color']['alpha']) : $nz_h1_desk_menu_effect_color;
		$nz_h1_desk_fixed_menu_color_reg     = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-menu-color']['regular']) && $GLOBALS['lifefitness_ninzio']['h1-desk-fixed-menu-color']['regular']) ? $GLOBALS['lifefitness_ninzio']['h1-desk-fixed-menu-color']['regular'] : $nz_h1_desk_menu_color_reg;
		$nz_h1_desk_fixed_menu_color_hov     = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-menu-color']['hover']) && $GLOBALS['lifefitness_ninzio']['h1-desk-fixed-menu-color']['hover']) ? $GLOBALS['lifefitness_ninzio']['h1-desk-fixed-menu-color']['hover'] : $nz_h1_desk_menu_color_hov;

		$nz_h1_desk_fixed_sidebar_toggle_color         = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-sidebar-toggle-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-fixed-sidebar-toggle-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-sidebar-toggle-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-fixed-sidebar-toggle-color']['alpha']) : $nz_h1_desk_sidebar_toggle_color;
		$nz_h1_desk_fixed_sidebar_toggle_border_color  = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-sidebar-toggle-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h1-desk-fixed-sidebar-toggle-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h1-desk-fixed-sidebar-toggle-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h1-desk-fixed-sidebar-toggle-border-color']['alpha']) : $nz_h1_desk_sidebar_toggle_border_color;
		
		// VERSION 2

		$nz_h2_desk_height                   = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-height']) && $GLOBALS['lifefitness_ninzio']['h2-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h2-desk-height'] : "90";
		$nz_h2_fixed_height                  = (isset($GLOBALS['lifefitness_ninzio']['h2-fixed-height']) && $GLOBALS['lifefitness_ninzio']['h2-fixed-height']) ? $GLOBALS['lifefitness_ninzio']['h2-fixed-height'] : "90";
		$nz_h2_header_top_back_color         = (isset($GLOBALS['lifefitness_ninzio']['h2-header-top-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-header-top-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-header-top-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-header-top-back-color']['alpha']) : "#16c3b1";
		$nz_h2_header_top_border_color       = (isset($GLOBALS['lifefitness_ninzio']['h2-header-top-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-header-top-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-header-top-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-header-top-border-color']['alpha']) : "";

		$nz_h2_header_top_menu_color_reg     = (isset($GLOBALS['lifefitness_ninzio']['h2-header-top-menu-color']['regular']) && !empty($GLOBALS['lifefitness_ninzio']['h2-header-top-menu-color']['regular'])) ? $GLOBALS['lifefitness_ninzio']['h2-header-top-menu-color']['regular'] : '#999999';
		$nz_h2_header_top_menu_color_hov     = (isset($GLOBALS['lifefitness_ninzio']['h2-header-top-menu-color']['hover']) && !empty($GLOBALS['lifefitness_ninzio']['h2-header-top-menu-color']['hover'])) ? $GLOBALS['lifefitness_ninzio']['h2-header-top-menu-color']['hover'] : '#16c3b1';
		
		$nz_h2_header_top_menu_font_weight    = (isset($GLOBALS['lifefitness_ninzio']['h2-header-top-menu-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h2-header-top-menu-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h2-header-top-menu-typo']['font-weight'] : "normal";
		$nz_h2_header_top_menu_font_size      = (isset($GLOBALS['lifefitness_ninzio']['h2-header-top-menu-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h2-header-top-menu-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h2-header-top-menu-typo']['font-size'] : "14px";
		$nz_h2_header_top_menu_text_transform = (isset($GLOBALS['lifefitness_ninzio']['h2-header-top-menu-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h2-header-top-menu-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h2-header-top-menu-typo']['text-transform'] : "none";

		$nz_h2_top_button_text_color         = (isset($GLOBALS['lifefitness_ninzio']['h2-top-button-text-color']) && !empty($GLOBALS['lifefitness_ninzio']['h2-top-button-text-color'])) ? $GLOBALS['lifefitness_ninzio']['h2-top-button-text-color'] : '#999999';
		$nz_h2_top_button_back_color         = (isset($GLOBALS['lifefitness_ninzio']['h2-top-button-back-color']) && !empty($GLOBALS['lifefitness_ninzio']['h2-top-button-back-color'])) ? $GLOBALS['lifefitness_ninzio']['h2-top-button-back-color'] : '#ffffff';

		$nz_h2_desk_sidebar_toggle_color         = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-sidebar-toggle-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-desk-sidebar-toggle-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-desk-sidebar-toggle-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-desk-sidebar-toggle-color']['alpha']) : "transparent";
		$nz_h2_desk_sidebar_toggle_border_color  = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-sidebar-toggle-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-desk-sidebar-toggle-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-desk-sidebar-toggle-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-desk-sidebar-toggle-border-color']['alpha']) : "transparent";

		$nz_h2_desk_cart_back_color          = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-cart-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-desk-cart-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-desk-cart-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-desk-cart-back-color']['alpha']) : "";
		$nz_h2_desk_cart_text_color          = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-cart-text-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-desk-cart-text-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-desk-cart-text-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-desk-cart-text-color']['alpha']) : "";

		$nz_h2_desk_back_color               = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-desk-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-desk-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-desk-back-color']['alpha']) : "#ffffff";
		$nz_h2_desk_border_color             = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-desk-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-desk-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-desk-border-color']['alpha']) : "";
		$nz_h2_desk_menu_effect_color        = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-menu-effect-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-desk-menu-effect-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-desk-menu-effect-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-desk-menu-effect-color']['alpha']) : "#16c3b1";
		$nz_h2_desk_menu_color_reg           = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-menu-color']['regular']) && $GLOBALS['lifefitness_ninzio']['h2-desk-menu-color']['regular']) ? $GLOBALS['lifefitness_ninzio']['h2-desk-menu-color']['regular'] : "#999999";
		$nz_h2_desk_menu_color_hov           = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-menu-color']['hover']) && $GLOBALS['lifefitness_ninzio']['h2-desk-menu-color']['hover']) ? $GLOBALS['lifefitness_ninzio']['h2-desk-menu-color']['hover'] : "#999999";
		$nz_h2_desk_submenu_back_color       = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-back-color']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-back-color'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-submenu-back-color'] : '#292929';
		$nz_h2_desk_submenu_color_reg        = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-color']['regular']) && $GLOBALS['lifefitness_ninzio']['h2-desk-submenu-color']['regular']) ? $GLOBALS['lifefitness_ninzio']['h2-desk-submenu-color']['regular'] : "#999999";
		$nz_h2_desk_submenu_color_hov        = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-color']['hover']) && $GLOBALS['lifefitness_ninzio']['h2-desk-submenu-color']['hover']) ? $GLOBALS['lifefitness_ninzio']['h2-desk-submenu-color']['hover'] : "#ffffff";

		$nz_h2_desk_menu_m                   = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-menu-m']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-menu-m'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-menu-m'] : '0';
		$nz_h2_desk_menu_m_1600              = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-menu-m-1600']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-menu-m-1600'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-menu-m-1600'] : $nz_h2_desk_menu_m;
		$nz_h2_desk_ls_w    	             = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-lw']['width']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-lw']['width'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-lw']['width'] : "149px"; 
		$nz_h2_desk_menu_font_weight         = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-menu-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-menu-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-menu-typo']['font-weight'] : "normal";
		$nz_h2_desk_menu_font_size           = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-menu-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-menu-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-menu-typo']['font-size'] : "14px";
		$nz_h2_desk_menu_font_family         = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-menu-typo']['font-family']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-menu-typo']['font-family'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-menu-typo']['font-family'] : "Arial, Helvetica, sans-serif";
		$nz_h2_desk_menu_text_transform      = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-menu-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-menu-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-menu-typo']['text-transform'] : "none";
		$nz_h2_desk_submenu_font_size        = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['font-size'] : "14px";
		$nz_h2_desk_submenu_font_weight      = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['font-weight'] : "400";
		$nz_h2_desk_submenu_line_height      = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['line-height']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['line-height'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['line-height'] : "24px";
		$nz_h2_desk_submenu_font_family      = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['font-family']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['font-family'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['font-family'] : "Arial, Helvetica, sans-serif";
		$nz_h2_desk_submenu_text_transform   = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-submenu-typo']['text-transform'] : "none";
		$nz_h2_desk_megamenu_text_transform  = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-typo']['text-transform'] : $nz_h2_desk_menu_text_transform;
		$nz_h2_desk_megamenu_font_weight     = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-typo']['font-weight'] : $nz_h2_desk_menu_font_weight;
		$nz_h2_desk_megamenu_font_size       = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-typo']['font-size'] : $nz_h2_desk_menu_font_size;
		$nz_h2_desk_megamenu_color           = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-typo']['color']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-typo']['color'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-typo']['color'] : "#ffffff";
		$nz_h2_desk_megamenu_top_border      = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-border']) && !empty($GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-border'])) ? $GLOBALS['lifefitness_ninzio']['h2-desk-megamenu-top-border'] : "";

		$nz_h2_megamenu_buttons_back_color   = (isset($GLOBALS['lifefitness_ninzio']['h2-megamenu-buttons-back-color']) && !empty($GLOBALS['lifefitness_ninzio']['h2-megamenu-buttons-back-color'])) ? $GLOBALS['lifefitness_ninzio']['h2-megamenu-buttons-back-color'] : '#16c3b1';
		$nz_h2_megamenu_buttons_text_color   = (isset($GLOBALS['lifefitness_ninzio']['h2-megamenu-buttons-text-color']) && !empty($GLOBALS['lifefitness_ninzio']['h2-megamenu-buttons-text-color'])) ? $GLOBALS['lifefitness_ninzio']['h2-megamenu-buttons-text-color'] : '#ffffff';

		$nz_h2_desk_fixed_back_color         = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-desk-fixed-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-desk-fixed-back-color']['alpha']) : $nz_h2_desk_back_color;
		$nz_h2_desk_fixed_menu_effect_color  = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-menu-effect-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-desk-fixed-menu-effect-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-menu-effect-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-desk-fixed-menu-effect-color']['alpha']) : $nz_h2_desk_menu_effect_color;
		$nz_h2_desk_fixed_menu_color_reg     = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-menu-color']['regular']) && $GLOBALS['lifefitness_ninzio']['h2-desk-fixed-menu-color']['regular']) ? $GLOBALS['lifefitness_ninzio']['h2-desk-fixed-menu-color']['regular'] : $nz_h2_desk_menu_color_reg;
		$nz_h2_desk_fixed_menu_color_hov     = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-menu-color']['hover']) && $GLOBALS['lifefitness_ninzio']['h2-desk-fixed-menu-color']['hover']) ? $GLOBALS['lifefitness_ninzio']['h2-desk-fixed-menu-color']['hover'] : $nz_h2_desk_menu_color_hov;

		$nz_h2_desk_fixed_cart_back_color    = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-cart-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-desk-fixed-cart-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-cart-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-desk-fixed-cart-back-color']['alpha']) : $nz_h2_desk_cart_back_color;
		$nz_h2_desk_fixed_cart_text_color    = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-cart-text-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-desk-fixed-cart-text-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-cart-text-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-desk-fixed-cart-text-color']['alpha']) : $nz_h2_desk_cart_text_color;

		$nz_h2_desk_fixed_sidebar_toggle_color         = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-sidebar-toggle-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-desk-fixed-sidebar-toggle-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-sidebar-toggle-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-desk-fixed-sidebar-toggle-color']['alpha']) : $nz_h2_desk_sidebar_toggle_color;
		$nz_h2_desk_fixed_sidebar_toggle_border_color  = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-sidebar-toggle-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h2-desk-fixed-sidebar-toggle-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h2-desk-fixed-sidebar-toggle-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h2-desk-fixed-sidebar-toggle-border-color']['alpha']) : $nz_h2_desk_sidebar_toggle_border_color;

		// VERSION 3

		$nz_h3_desk_height                   = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-height']) && $GLOBALS['lifefitness_ninzio']['h3-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h3-desk-height'] : "90";
		$nz_h3_fixed_height                  = (isset($GLOBALS['lifefitness_ninzio']['h3-fixed-height']) && $GLOBALS['lifefitness_ninzio']['h3-fixed-height']) ? $GLOBALS['lifefitness_ninzio']['h3-fixed-height'] : "90";
		
		$nz_h3_desk_social_links_color     = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-social-links-color']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-social-links-color'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-social-links-color'] : '#999999';
		$nz_h3_desk_sidebar_toggle_color         = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-sidebar-toggle-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-sidebar-toggle-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-sidebar-toggle-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-sidebar-toggle-color']['alpha']) : "transparent";
		$nz_h3_desk_sidebar_toggle_border_color  = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-sidebar-toggle-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-sidebar-toggle-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-sidebar-toggle-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-sidebar-toggle-border-color']['alpha']) : "transparent";
		$nz_h3_desk_back_color               = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-back-color']['alpha']) : "#ffffff";
		$nz_h3_desk_border_color             = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-border-color']['alpha']) : "";
		$nz_h3_desk_separator_color          = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-separator-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-separator-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-separator-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-separator-color']['alpha']) : "";
		$nz_h3_desk_menu_effect_color        = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-menu-effect-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-menu-effect-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-menu-effect-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-menu-effect-color']['alpha']) : "#16c3b1";
		$nz_h3_desk_menu_color_reg           = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-menu-color']['regular']) && $GLOBALS['lifefitness_ninzio']['h3-desk-menu-color']['regular']) ? $GLOBALS['lifefitness_ninzio']['h3-desk-menu-color']['regular'] : "#999999";
		$nz_h3_desk_menu_color_hov           = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-menu-color']['hover']) && $GLOBALS['lifefitness_ninzio']['h3-desk-menu-color']['hover']) ? $GLOBALS['lifefitness_ninzio']['h3-desk-menu-color']['hover'] : "#999999";
		$nz_h3_desk_submenu_back_color       = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-back-color']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-back-color'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-submenu-back-color'] : '#292929';
		$nz_h3_desk_submenu_color_reg        = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-color']['regular']) && $GLOBALS['lifefitness_ninzio']['h3-desk-submenu-color']['regular']) ? $GLOBALS['lifefitness_ninzio']['h3-desk-submenu-color']['regular'] : "#999999";
		$nz_h3_desk_submenu_color_hov        = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-color']['hover']) && $GLOBALS['lifefitness_ninzio']['h3-desk-submenu-color']['hover']) ? $GLOBALS['lifefitness_ninzio']['h3-desk-submenu-color']['hover'] : "#ffffff";

		$nz_h3_desk_cart_back_color          = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-cart-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-cart-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-cart-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-cart-back-color']['alpha']) : "";
		$nz_h3_desk_cart_text_color          = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-cart-text-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-cart-text-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-cart-text-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-cart-text-color']['alpha']) : "";
		
		$nz_h3_desk_menu_m                   = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-menu-m']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-menu-m'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-menu-m'] : '0';
		$nz_h3_desk_menu_m_1600              = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-menu-m-1600']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-menu-m-1600'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-menu-m-1600'] : $nz_h3_desk_menu_m;
		$nz_h3_desk_ls_w    	             = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-lw']['width']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-lw']['width'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-lw']['width'] : "149px"; 
		$nz_h3_desk_menu_font_weight         = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-menu-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-menu-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-menu-typo']['font-weight'] : "normal";
		$nz_h3_desk_menu_font_size           = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-menu-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-menu-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-menu-typo']['font-size'] : "14px";
		$nz_h3_desk_menu_font_family         = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-menu-typo']['font-family']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-menu-typo']['font-family'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-menu-typo']['font-family'] : "Arial, Helvetica, sans-serif";
		$nz_h3_desk_menu_text_transform      = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-menu-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-menu-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-menu-typo']['text-transform'] : "none";
		$nz_h3_desk_submenu_font_size        = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['font-size'] : "14px";
		$nz_h3_desk_submenu_font_weight      = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['font-weight'] : "400";
		$nz_h3_desk_submenu_line_height      = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['line-height']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['line-height'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['line-height'] : "24px";
		$nz_h3_desk_submenu_font_family      = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['font-family']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['font-family'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['font-family'] : "Arial, Helvetica, sans-serif";
		$nz_h3_desk_submenu_text_transform   = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-submenu-typo']['text-transform'] : "none";
		$nz_h3_desk_megamenu_text_transform  = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-typo']['text-transform'] : $nz_h3_desk_menu_text_transform;
		$nz_h3_desk_megamenu_font_weight     = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-typo']['font-weight'] : $nz_h3_desk_menu_font_weight;
		$nz_h3_desk_megamenu_font_size       = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-typo']['font-size'] : $nz_h3_desk_menu_font_size;
		$nz_h3_desk_megamenu_color           = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-typo']['color']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-typo']['color'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-typo']['color'] : "#ffffff";
		$nz_h3_desk_megamenu_top_border      = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-border']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-border'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-megamenu-top-border'] : "";

		$nz_h3_megamenu_buttons_back_color   = (isset($GLOBALS['lifefitness_ninzio']['h3-megamenu-buttons-back-color']) && !empty($GLOBALS['lifefitness_ninzio']['h3-megamenu-buttons-back-color'])) ? $GLOBALS['lifefitness_ninzio']['h3-megamenu-buttons-back-color'] : '#16c3b1';
		$nz_h3_megamenu_buttons_text_color   = (isset($GLOBALS['lifefitness_ninzio']['h3-megamenu-buttons-text-color']) && !empty($GLOBALS['lifefitness_ninzio']['h3-megamenu-buttons-text-color'])) ? $GLOBALS['lifefitness_ninzio']['h3-megamenu-buttons-text-color'] : '#ffffff';

		$nz_h3_desk_fixed_back_color         = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-fixed-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-fixed-back-color']['alpha']) : $nz_h3_desk_back_color;
		$nz_h3_desk_fixed_separator_color    = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-separator-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-fixed-separator-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-separator-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-fixed-separator-color']['alpha']) : "";
		$nz_h3_desk_fixed_menu_effect_color  = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-menu-effect-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-fixed-menu-effect-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-menu-effect-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-fixed-menu-effect-color']['alpha']) : $nz_h3_desk_menu_effect_color;
		$nz_h3_desk_fixed_menu_color_reg     = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-menu-color']['regular']) && $GLOBALS['lifefitness_ninzio']['h3-desk-fixed-menu-color']['regular']) ? $GLOBALS['lifefitness_ninzio']['h3-desk-fixed-menu-color']['regular'] : $nz_h3_desk_menu_color_reg;
		$nz_h3_desk_fixed_menu_color_hov     = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-menu-color']['hover']) && $GLOBALS['lifefitness_ninzio']['h3-desk-fixed-menu-color']['hover']) ? $GLOBALS['lifefitness_ninzio']['h3-desk-fixed-menu-color']['hover'] : $nz_h3_desk_menu_color_hov;

		$nz_h3_desk_fixed_social_links_color     = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-social-links-color']) && !empty($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-social-links-color'])) ? $GLOBALS['lifefitness_ninzio']['h3-desk-fixed-social-links-color'] : $nz_h3_desk_social_links_color;

		$nz_h3_desk_fixed_sidebar_toggle_color         = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-sidebar-toggle-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-fixed-sidebar-toggle-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-sidebar-toggle-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-fixed-sidebar-toggle-color']['alpha']) : $nz_h3_desk_sidebar_toggle_color;
		$nz_h3_desk_fixed_sidebar_toggle_border_color  = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-sidebar-toggle-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-fixed-sidebar-toggle-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-sidebar-toggle-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-fixed-sidebar-toggle-border-color']['alpha']) : $nz_h3_desk_sidebar_toggle_border_color;

		$nz_h3_desk_fixed_cart_back_color    = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-cart-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-fixed-cart-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-cart-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-fixed-cart-back-color']['alpha']) : $nz_h3_desk_cart_back_color;
		$nz_h3_desk_fixed_cart_text_color    = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-cart-text-color']['color']) && $GLOBALS['lifefitness_ninzio']['h3-desk-fixed-cart-text-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h3-desk-fixed-cart-text-color']['color'],$GLOBALS['lifefitness_ninzio']['h3-desk-fixed-cart-text-color']['alpha']) : $nz_h3_desk_cart_text_color;

		// VERSION 5

		$nz_h5_desk_height                   = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-height']) && $GLOBALS['lifefitness_ninzio']['h5-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h5-desk-height'] : "90";
		$nz_h5_fixed_height                  = (isset($GLOBALS['lifefitness_ninzio']['h5-fixed-height']) && $GLOBALS['lifefitness_ninzio']['h5-fixed-height']) ? $GLOBALS['lifefitness_ninzio']['h5-fixed-height'] : "90";
		$nz_h5_header_top_back_color         = (isset($GLOBALS['lifefitness_ninzio']['h5-header-top-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-header-top-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-header-top-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-header-top-back-color']['alpha']) : "#16c3b1";
		$nz_h5_header_top_border_color       = (isset($GLOBALS['lifefitness_ninzio']['h5-header-top-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-header-top-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-header-top-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-header-top-border-color']['alpha']) : "";
		
		$nz_h5_header_top_menu_color_reg     = (isset($GLOBALS['lifefitness_ninzio']['h5-header-top-menu-color']['regular']) && !empty($GLOBALS['lifefitness_ninzio']['h5-header-top-menu-color']['regular'])) ? $GLOBALS['lifefitness_ninzio']['h5-header-top-menu-color']['regular'] : '#999999';
		$nz_h5_header_top_menu_color_hov     = (isset($GLOBALS['lifefitness_ninzio']['h5-header-top-menu-color']['hover']) && !empty($GLOBALS['lifefitness_ninzio']['h5-header-top-menu-color']['hover'])) ? $GLOBALS['lifefitness_ninzio']['h5-header-top-menu-color']['hover'] : '#16c3b1';
		
		$nz_h5_header_top_menu_font_weight    = (isset($GLOBALS['lifefitness_ninzio']['h5-header-top-menu-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h5-header-top-menu-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h5-header-top-menu-typo']['font-weight'] : "normal";
		$nz_h5_header_top_menu_font_size      = (isset($GLOBALS['lifefitness_ninzio']['h5-header-top-menu-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h5-header-top-menu-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h5-header-top-menu-typo']['font-size'] : "14px";
		$nz_h5_header_top_menu_text_transform = (isset($GLOBALS['lifefitness_ninzio']['h5-header-top-menu-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h5-header-top-menu-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h5-header-top-menu-typo']['text-transform'] : "none";

		$nz_h5_top_button_text_color         = (isset($GLOBALS['lifefitness_ninzio']['h5-top-button-text-color']) && !empty($GLOBALS['lifefitness_ninzio']['h5-top-button-text-color'])) ? $GLOBALS['lifefitness_ninzio']['h5-top-button-text-color'] : '#999999';
		$nz_h5_top_button_back_color         = (isset($GLOBALS['lifefitness_ninzio']['h5-top-button-back-color']) && !empty($GLOBALS['lifefitness_ninzio']['h5-top-button-back-color'])) ? $GLOBALS['lifefitness_ninzio']['h5-top-button-back-color'] : '#ffffff';

		$nz_h5_desk_sidebar_toggle_color         = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-sidebar-toggle-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-desk-sidebar-toggle-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-desk-sidebar-toggle-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-desk-sidebar-toggle-color']['alpha']) : "transparent";
		$nz_h5_desk_sidebar_toggle_border_color  = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-sidebar-toggle-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-desk-sidebar-toggle-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-desk-sidebar-toggle-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-desk-sidebar-toggle-border-color']['alpha']) : "transparent";

		$nz_h5_desk_back_color               = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-desk-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-desk-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-desk-back-color']['alpha']) : "#ffffff";
		$nz_h5_desk_menu_back_color          = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-menu-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-desk-menu-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-desk-menu-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-desk-menu-back-color']['alpha']) : "#ffffff";
		$nz_h5_desk_border_color             = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-desk-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-desk-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-desk-border-color']['alpha']) : "";
		$nz_h5_desk_separator_color          = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-separator-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-desk-separator-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-desk-separator-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-desk-separator-color']['alpha']) : "";

		$nz_h5_desk_cart_back_color          = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-cart-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-desk-cart-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-desk-cart-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-desk-cart-back-color']['alpha']) : "";
		$nz_h5_desk_cart_text_color          = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-cart-text-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-desk-cart-text-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-desk-cart-text-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-desk-cart-text-color']['alpha']) : "";
		
		$nz_h5_desk_search_border_color	     = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-search-border-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-desk-search-border-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-desk-search-border-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-desk-search-border-color']['alpha']) : "#eeeeee";
		$nz_h5_desk_search_text_color        = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-search-text-color']) && $GLOBALS['lifefitness_ninzio']['h5-desk-search-text-color']) ? $GLOBALS['lifefitness_ninzio']['h5-desk-search-text-color'] : "#999999";

		$nz_h5_desk_menu_effect_color        = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-menu-effect-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-desk-menu-effect-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-desk-menu-effect-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-desk-menu-effect-color']['alpha']) : "#16c3b1";
		$nz_h5_desk_menu_color_reg           = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-menu-color']['regular']) && $GLOBALS['lifefitness_ninzio']['h5-desk-menu-color']['regular']) ? $GLOBALS['lifefitness_ninzio']['h5-desk-menu-color']['regular'] : "#999999";
		$nz_h5_desk_menu_color_hov           = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-menu-color']['hover']) && $GLOBALS['lifefitness_ninzio']['h5-desk-menu-color']['hover']) ? $GLOBALS['lifefitness_ninzio']['h5-desk-menu-color']['hover'] : "#999999";
		$nz_h5_desk_submenu_back_color       = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-back-color']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-back-color'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-submenu-back-color'] : '#292929';
		$nz_h5_desk_submenu_color_reg        = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-color']['regular']) && $GLOBALS['lifefitness_ninzio']['h5-desk-submenu-color']['regular']) ? $GLOBALS['lifefitness_ninzio']['h5-desk-submenu-color']['regular'] : "#999999";
		$nz_h5_desk_submenu_color_hov        = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-color']['hover']) && $GLOBALS['lifefitness_ninzio']['h5-desk-submenu-color']['hover']) ? $GLOBALS['lifefitness_ninzio']['h5-desk-submenu-color']['hover'] : "#ffffff";

		$nz_h5_desk_menu_m                   = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-menu-m']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-menu-m'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-menu-m'] : '0';
		$nz_h5_desk_ls_w    	             = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-lw']['width']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-lw']['width'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-lw']['width'] : "149px"; 
		$nz_h5_desk_menu_font_weight         = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-menu-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-menu-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-menu-typo']['font-weight'] : "normal";
		$nz_h5_desk_menu_font_size           = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-menu-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-menu-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-menu-typo']['font-size'] : "14px";
		$nz_h5_desk_menu_font_family         = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-menu-typo']['font-family']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-menu-typo']['font-family'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-menu-typo']['font-family'] : "Arial, Helvetica, sans-serif";
		$nz_h5_desk_menu_text_transform      = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-menu-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-menu-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-menu-typo']['text-transform'] : "none";
		$nz_h5_desk_submenu_font_size        = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['font-size'] : "14px";
		$nz_h5_desk_submenu_font_weight      = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['font-weight'] : "400";
		$nz_h5_desk_submenu_line_height      = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['line-height']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['line-height'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['line-height'] : "24px";
		$nz_h5_desk_submenu_font_family      = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['font-family']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['font-family'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['font-family'] : "Arial, Helvetica, sans-serif";
		$nz_h5_desk_submenu_text_transform   = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-submenu-typo']['text-transform'] : "none";
		$nz_h5_desk_megamenu_text_transform  = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-typo']['text-transform']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-typo']['text-transform'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-typo']['text-transform'] : $nz_h5_desk_menu_text_transform;
		$nz_h5_desk_megamenu_font_weight     = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-typo']['font-weight']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-typo']['font-weight'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-typo']['font-weight'] : $nz_h5_desk_menu_font_weight;
		$nz_h5_desk_megamenu_font_size       = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-typo']['font-size']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-typo']['font-size'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-typo']['font-size'] : $nz_h5_desk_menu_font_size;
		$nz_h5_desk_megamenu_color           = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-typo']['color']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-typo']['color'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-typo']['color'] : "#ffffff";
		$nz_h5_desk_megamenu_top_border      = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-border']) && !empty($GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-border'])) ? $GLOBALS['lifefitness_ninzio']['h5-desk-megamenu-top-border'] : "";

		$nz_h5_megamenu_buttons_back_color   = (isset($GLOBALS['lifefitness_ninzio']['h5-megamenu-buttons-back-color']) && !empty($GLOBALS['lifefitness_ninzio']['h5-megamenu-buttons-back-color'])) ? $GLOBALS['lifefitness_ninzio']['h5-megamenu-buttons-back-color'] : '#16c3b1';
		$nz_h5_megamenu_buttons_text_color   = (isset($GLOBALS['lifefitness_ninzio']['h5-megamenu-buttons-text-color']) && !empty($GLOBALS['lifefitness_ninzio']['h5-megamenu-buttons-text-color'])) ? $GLOBALS['lifefitness_ninzio']['h5-megamenu-buttons-text-color'] : '#ffffff';

		$nz_h5_desk_fixed_menu_back_color    = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-fixed-menu-back-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-desk-fixed-menu-back-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-desk-fixed-menu-back-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-desk-menu-fixed-back-color']['alpha']) : $nz_h5_desk_menu_back_color;
		$nz_h5_desk_fixed_menu_effect_color  = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-fixed-menu-effect-color']['color']) && $GLOBALS['lifefitness_ninzio']['h5-desk-fixed-menu-effect-color']['color']) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']['h5-desk-fixed-menu-effect-color']['color'],$GLOBALS['lifefitness_ninzio']['h5-desk-fixed-menu-effect-color']['alpha']) : $nz_h5_desk_menu_effect_color;
		$nz_h5_desk_fixed_menu_color_reg     = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-fixed-menu-color']['regular']) && $GLOBALS['lifefitness_ninzio']['h5-desk-fixed-menu-color']['regular']) ? $GLOBALS['lifefitness_ninzio']['h5-desk-fixed-menu-color']['regular'] : $nz_h5_desk_menu_color_reg;
		$nz_h5_desk_fixed_menu_color_hov     = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-fixed-menu-color']['hover']) && $GLOBALS['lifefitness_ninzio']['h5-desk-fixed-menu-color']['hover']) ? $GLOBALS['lifefitness_ninzio']['h5-desk-fixed-menu-color']['hover'] : $nz_h5_desk_menu_color_hov;

	/*	SHOP PAGE TITLE OPTIONS
	/*--------------------------*/

	    $nz_shop_text_color             = (isset( $GLOBALS['lifefitness_ninzio']['shop-text-color']) && !empty($GLOBALS['lifefitness_ninzio']['shop-text-color'])) ? $GLOBALS['lifefitness_ninzio']["shop-text-color"] : "";
	    $nz_shop_back_color             = (isset( $GLOBALS['lifefitness_ninzio']['shop-back']['background-color']) && !empty($GLOBALS['lifefitness_ninzio']['shop-back']['background-color'])) ? $GLOBALS['lifefitness_ninzio']["shop-back"]['background-color'] : "#333333";
	    $nz_shop_back_img               = (isset( $GLOBALS['lifefitness_ninzio']['shop-back']['background-image']) && !empty($GLOBALS['lifefitness_ninzio']['shop-back']['background-image'])) ? $GLOBALS['lifefitness_ninzio']['shop-back']["background-image"] : "";
	    $nz_shop_back_img_repeat        = (isset( $GLOBALS['lifefitness_ninzio']['shop-back']['background-repeat']) && !empty($GLOBALS['lifefitness_ninzio']['shop-back']['background-repeat'])) ? $GLOBALS['lifefitness_ninzio']['shop-back']['background-repeat'] : "no-repeat";
	    $nz_shop_back_img_position      = (isset( $GLOBALS['lifefitness_ninzio']['shop-back']['background-position']) && !empty($GLOBALS['lifefitness_ninzio']['shop-back']['background-position'])) ? $GLOBALS['lifefitness_ninzio']['shop-back']['background-position'] : "left top";
	    $nz_shop_back_img_attachment    = (isset( $GLOBALS['lifefitness_ninzio']['shop-back']['background-attachment']) && !empty($GLOBALS['lifefitness_ninzio']['shop-back']['background-attachment'])) ? $GLOBALS['lifefitness_ninzio']['shop-back']['background-attachment'] : "scroll";
	    $nz_shop_back_img_size          = (isset( $GLOBALS['lifefitness_ninzio']['shop-back']['background-size']) && !empty($GLOBALS['lifefitness_ninzio']['shop-back']['background-size'])) ? $GLOBALS['lifefitness_ninzio']['shop-back']['background-size'] : "auto";
	    $nz_shop_breadcrumbs_text_color = (isset( $GLOBALS['lifefitness_ninzio']['shop-breadcrumbs-text-color']) && !empty($GLOBALS['lifefitness_ninzio']['shop-breadcrumbs-text-color'])) ? $GLOBALS['lifefitness_ninzio']["shop-breadcrumbs-text-color"] : "#ffffff";

	/*	FOOTER OPTIONS
	/*--------------------------*/

		$nz_footer_back_col   = (isset($GLOBALS['lifefitness_ninzio']['footer-background']['background-color']) && $GLOBALS['lifefitness_ninzio']['footer-background']['background-color']) ? $GLOBALS['lifefitness_ninzio']['footer-background']['background-color'] : "#2d2e2f";
		$nz_footer_back_img   = (isset($GLOBALS['lifefitness_ninzio']['footer-background']['background-image']) && $GLOBALS['lifefitness_ninzio']['footer-background']['background-image']) ? esc_url($GLOBALS['lifefitness_ninzio']['footer-background']['background-image']) : "";
		$nz_footer_back_r     = (isset($GLOBALS['lifefitness_ninzio']['footer-background']['background-repeat']) && $GLOBALS['lifefitness_ninzio']['footer-background']['background-repeat']) ? $GLOBALS['lifefitness_ninzio']['footer-background']['background-repeat'] : "no-repeat";
		$nz_footer_back_s     = (isset($GLOBALS['lifefitness_ninzio']['footer-background']['background-size']) && $GLOBALS['lifefitness_ninzio']['footer-background']['background-size']) ? $GLOBALS['lifefitness_ninzio']['footer-background']['background-size'] : "cover";
		$nz_footer_back_a     = (isset($GLOBALS['lifefitness_ninzio']['footer-background']['background-attachment']) && $GLOBALS['lifefitness_ninzio']['footer-background']['background-attachment']) ? $GLOBALS['lifefitness_ninzio']['footer-background']['background-attachment'] : "scroll";
		$nz_footer_back_p     = (isset($GLOBALS['lifefitness_ninzio']['footer-background']['background-position']) && $GLOBALS['lifefitness_ninzio']['footer-background']['background-position']) ? $GLOBALS['lifefitness_ninzio']['footer-background']['background-position'] : "center center";

    $dynamic_css = "";

	if(isset($GLOBALS['lifefitness_ninzio']['font-custom-css']) && !empty($GLOBALS['lifefitness_ninzio']['font-custom-css'])){
		$dynamic_css .= esc_html($GLOBALS['lifefitness_ninzio']['font-custom-css']);
	}

	if(isset($GLOBALS['lifefitness_ninzio']['custom-css']) && !empty($GLOBALS['lifefitness_ninzio']['custom-css'])){
		$dynamic_css .= $GLOBALS['lifefitness_ninzio']['custom-css'];
	}

	/*  TYPOGRAPHY
	/*-------------------------*/
		
		$dynamic_css .='body,input,pre,code,kbd,samp,dt{
			font-size: '.$nz_main_font_size.';
			line-height: '.$nz_main_line_height.';
			font-family:'.$nz_main_font_family.';
		}';

		$dynamic_css .='.desk .header-top-menu ul li > a .txt {
			font-family:'.$nz_main_font_family.' !important;
		}';

		$dynamic_css .='h1,h2,h3,h4,h5,h6 {
			font-family:'.$nz_headings_font_family.';
			text-transform: '.$nz_headings_text_transform.';
		}';

		$dynamic_css .='h1 {font-size: '.$nz_h1_font_size.'; line-height: '.$nz_h1_line_height.';}';
		$dynamic_css .='h2 {font-size: '.$nz_h2_font_size.'; line-height: '.$nz_h2_line_height.';}';
		$dynamic_css .='h3 {font-size: '.$nz_h3_font_size.'; line-height: '.$nz_h3_line_height.';}';
		$dynamic_css .='h4 {font-size: '.$nz_h4_font_size.'; line-height: '.$nz_h4_line_height.';}';
		$dynamic_css .='h5 {font-size: '.$nz_h5_font_size.'; line-height: '.$nz_h5_line_height.';}';
		$dynamic_css .='h6 {font-size: '.$nz_h6_font_size.'; line-height: '.$nz_h6_line_height.';}';

		$dynamic_css .='.ls a,.mob-menu li a,#nz-content .search input[type="text"],
		.mob-header-content .header-top-menu li a,.mob-header-content .top-button,
		.header-top .top-button,.widget_title,.yawp_wim_title,textarea,select,button,
		.button, .button .txt,input[type="month"],input[type="number"],input[type="submit"],
		input[type="button"],input[type="date"],input[type="datetime"],input[type="password"],
		input[type="search"],input[type="datetime-local"],input[type="email"],input[type="tel"],
		input[type="text"],input[type="time"],input[type="url"],input[type="week"],
		input[type="reset"],.nz-timer,.count-value,
		.nz-persons .person .name,.nz-pricing-table > .column .title,
		.nz-pricing-table .price,.tabset .tab,
		.toggle-title .toggle-title-header,.ninzio-navigation,.woocommerce-pagination,
		.ninzio-filter .filter, .single-details .nz-i-list a,.nz-table th,
		.comment-meta .comment-author cite,.wp-caption .wp-caption-text,
		.woocommerce .product .added_to_cart,.woocommerce-tabs .tabs > li,
		.woocommerce .single-product-summary .amount,.reset_variations,
		.footer-menu > ul > li > a,.share-labelf,a.edit,a.view,
		.widget_icl_lang_sel_widget,.nz-progress .progress-percent,
		.nz-progress .progress-title,.nz-content-box-2 .box-title span,
		.footer-info,.product .price,.related-products-title h3,
		.ninzio-nav-single > *,.box-more,.count-title,.nz-pricing-table .hlabel,
		.widget_nz_recent_entries .post .post-date-custom,.standard .post-date-custom,
		.single .post-social-share .social-links a span,
		.woocommerce .product .onsale,.widget_tag_cloud .tagcloud a,.post-tags a,
		.widget_product_tag_cloud .tagcloud a,.projects-tags a,
		.widget_recent_entries a,.widget_categories ul li a,
		.widget_pages ul li a,.widget_archive ul li a,
		.widget_meta ul li a,
		.widget_nav_menu li a,
		.widget_product_categories li a,
		.post .post-category ul li a,
		.tagline-title,
		.nz-accordion .toggle-title {
			font-family:'.$nz_headings_font_family.' !important;
		}';

	/*  BACKGROUND
	/*-------------------------*/

		$dynamic_css .='html,
		#gen-wrap {
			background-color:'.$nz_site_back_col.';';
			if(!empty($nz_site_back_img)){
				$dynamic_css .='background-image:url('.$nz_site_back_img.');
				background-repeat:'.$nz_site_back_r.';
				background-attachment: '.$nz_site_back_a.';
				-webkit-background-size: '.$nz_site_back_s.';
				-moz-background-size: '.$nz_site_back_s.';
				background-size: '.$nz_site_back_s.';
				background-position:'.$nz_site_back_p;
			}
		$dynamic_css .='}';

		$dynamic_css .='.shoping-cart .rich-header,
		.woo-account .rich-header,
		.shoping-cart .parallax-container,
		.woo-account .parallax-container,
		.shoping-cart .fixed-container,
		.woo-account .fixed-container {';
			if(!empty($nz_shop_back_img)){
				$dynamic_css .='background-image:url('.$nz_shop_back_img.');
				background-repeat:'.$nz_shop_back_img_repeat.';
				background-attachment: '.$nz_shop_back_img_attachment.';
				-webkit-background-size: '.$nz_shop_back_img_size.';
				-moz-background-size: '.$nz_shop_back_img_size.';
				background-size: '.$nz_shop_back_img_size.';
				background-position:'.$nz_shop_back_img_position;
			}
		$dynamic_css .='}';

		$dynamic_css .='.shoping-cart .rich-header h1,
		.woo-account .rich-header h1 {
			color:'.$nz_shop_text_color.'; 
		}';

		$dynamic_css .='.shoping-cart .rich-header .nz-breadcrumbs,
		.woo-account .rich-header .nz-breadcrumbs {
			color:'.$nz_shop_breadcrumbs_text_color.'; 
		}';

		$dynamic_css .='.footer .footer-info-area {
			background-color:'.$nz_footer_back_col.';';
			if(!empty($nz_footer_back_img)){
				$dynamic_css .='background-image:url('.$nz_footer_back_img.');
				background-repeat:'.$nz_footer_back_r.';
				background-attachment: '.$nz_footer_back_a.';
				-webkit-background-size: '.$nz_footer_back_s.';
				-moz-background-size: '.$nz_footer_back_s.';
				background-size: '.$nz_footer_back_s.';
				background-position:'.$nz_footer_back_p;
			}
		$dynamic_css .='}';

	/*  COLOR
	/*-------------------------*/
		
		$dynamic_css .='::-moz-selection {
			background-color:'.$lifefitness_ninzio_main_color.';
			color: #ffffff;
		}';

		$dynamic_css .='::selection {
			background-color:'.$lifefitness_ninzio_main_color.';
			color: #ffffff;
		}';

		/*COLOR DYNAMIC STYLES*/

		$dynamic_css .='.mob-menu li a:hover,
		.mob-menu .current-menu-item > a,
		.mob-menu .current-menu-parent > a,
		.mob-menu .current-menu-ancestor > a,
		.mob-menu ul li > a:hover > .di,
		.mob-menu .current-menu-item > a > .di,
		.mob-menu .current-menu-parent > a > .di,
		.mob-menu .current-menu-ancestor > a > .di,
		.mob-header-content .header-top-menu li a:hover,
		.mob-header-content .header-top-menu .current-menu-item > a,
		.mob-header-content .header-top-menu .current-menu-parent > a,
		.mob-header-content .header-top-menu .current-menu-ancestor > a,
		.mob-header-content .header-top-menu ul li > a:hover > .di,
		.mob-header-content .header-top-menu .current-menu-item > a > .di,
		.mob-header-content .header-top-menu .current-menu-parent > a > .di,
		.mob-header-content .header-top-menu .current-menu-ancestor > a > .di,
		.search-r .post-title a,.project-category a:hover,.project-details a:hover,
		.nz-related-portfolio .project-details a:hover,.single-details .nz-i-list a:hover,
		.blog-post .post .post-title:hover > a,.nz-recent-posts .post .post-title:hover > a,
		.blog-post .post .post-meta a:hover,.nz-recent-posts .post .post-meta a:hover,
		.blog-post .post .post-meta a:hover i,.nz-recent-posts .post .post-meta a:hover i,
		.single-post-content a:not(.button),.nz-breadcrumbs a:hover,
		.nz-content-box-2 a:hover .box-title h3,.nz-breadcrumbs > *:before,
		.post-comments a:hover,.footer-menu ul li a:hover,
		.comment-content .edit-link a:hover,.loop .project-title a:hover,
		.loop .projects-category a:hover,.nz-related-projects .projects-category a:hover,
		.nz-recent-projects .projects-category a:hover,
		.widget_product_categories ul li a:hover,
		.widget_nav_menu ul li a:hover,
		.widget_recent_entries a:hover,
		.widget_categories ul li a:hover,
		.widget_pages ul li a:hover,
		.widget_archive ul li a:hover,
		.widget_meta ul li a:hover,
		.widget_nz_recent_entries .post-title:hover,
		.widget_price_filter .price_slider_amount .button:hover,
		.sidebar .widget_shopping_cart .cart_list > li > a:hover,
		.sidebar .widget_products .product_list_widget > li > a:hover,
		.sidebar .widget_recently_viewed_products .product_list_widget > li > a:hover,
		.sidebar .widget_recent_reviews .product_list_widget > li > a:hover,
		.sidebar .widget_top_rated_products .product_list_widget > li > a:hover,
		.sidebar .widget_product_tag_cloud .tagcloud a:hover,
		.sidebar .post-tags a:hover,
		.sidebar .projects-tags a:hover,
		.sidebar .widget_tag_cloud .tagcloud a:hover,
		.sidebar .widget_recent_entries a:hover, 
		.sidebar .widget_nz_recent_entries .post-title:hover,
		.sidebar .widget_product_categories ul li a:hover, 
		.sidebar .widget_nav_menu ul li a:hover,
		.sidebar .widget_categories ul li a:hover, 
		.sidebar .widget_pages ul li a:hover, 
		.sidebar .widget_archive ul li a:hover, 
		.sidebar .widget_meta ul li a:hover,
		.site-widget-area .widget_shopping_cart .cart_list > li > a:hover,
		.site-widget-area .widget_products .product_list_widget > li > a:hover,
		.site-widget-area .widget_recently_viewed_products .product_list_widget > li > a:hover,
		.site-widget-area .widget_recent_reviews .product_list_widget > li > a:hover,
		.site-widget-area .widget_top_rated_products .product_list_widget > li > a:hover,
		.site-widget-area .widget_product_tag_cloud .tagcloud a:hover,
		.site-widget-area .post-tags a:hover,
		.site-widget-area .projects-tags a:hover,
		.site-widget-area .widget_tag_cloud .tagcloud a:hover,
		.footer .widget_shopping_cart .cart_list > li > a:hover,
		.footer .widget_products .product_list_widget > li > a:hover,
		.footer .widget_recently_viewed_products .product_list_widget > li > a:hover,
		.footer .widget_recent_reviews .product_list_widget > li > a:hover,
		.footer .widget_top_rated_products .product_list_widget > li > a:hover,
		.footer .widget_product_tag_cloud .tagcloud a:hover,
		.footer .post-tags a:hover,
		.footer .projects-tags a:hover,
		.footer .widget_tag_cloud .tagcloud a:hover,
		.blog-post .post .postmeta a:hover,
		.loop .small-image .projects .projects-category a:hover,
		.loop .medium-image .projects .projects-category a:hover,
		.loop .large-image .projects .projects-category a:hover,
		.loop .small-image-nogap .projects .projects-category a:hover,
		.loop .medium-image-nogap .projects .projects-category a:hover,
		.nz-recent-projects.small-image .projects-category a:hover,
		.nz-recent-projects.medium-image .projects-category a:hover,
		.nz-recent-projects.large-image .projects-category a:hover,
		.nz-recent-projects.small-image-nogap .projects-category a:hover,
		.nz-recent-projects.medium-image-nogap .projects-category a:hover,
		.nz-related-projects .projects-category a:hover,
		.project-social-link-share .social-links a:hover,
		.post-author-info .author-social-links a:hover,
		.nz-persons .person .name:hover,
		.stepset .active .title,
		.post-social-share .social-links a:hover,
		.nz-pricing-table .price,
		.nz-pricing-table .currency,
		.post .post-more,
		.single .post-social-share .social-links a:hover,
		.desk .header-top .header-social-links a:hover,
		.single-project-main-detailes .projects-category a:hover,
		.woocommerce .single-product-summary .price {
			color: '.$lifefitness_ninzio_main_color.' !important;
		}';

		$dynamic_css .='#nz-content a:not(.button),
		#nz-content a:not(.button):visited,
		.sidebar a:not(.button):not(.ui-slider-handle),
		.woo-cart .widget_shopping_cart .cart_list > li > a:hover,
		.woocommerce .single-product-summary .product_meta a:hover,
		.reset_variations:hover,.count-icon,
		.post-comments-area .comments-title,.footer-copyright a,
		.post-author-info-title a,
		.post-tags a:hover,
		.widget_twitter ul li:before,
		.post-comments-area a,
		.ninzio-filter .filter.active,
		.ninzio-filter .filter:hover  {
			color: '.$lifefitness_ninzio_main_color.';
		}';

		$dynamic_css .='#nz-content a:not(.button):hover,
		#nz-content a:not(.button):visited:hover,
		.woocommerce .product_meta a:hover,
		.sidebar a:not(.button):hover,
		.post-author-info-title a:hover,
		.post-comments-area a:hover {
			color: '.lifefitness_ninzio_hex_to_rgb_shade($lifefitness_ninzio_main_color,50).';
		}';

		/*BACKGROUND COLOR DYNAMIC STYLES*/

		$dynamic_css .='.flex-control-paging li a.flex-active,
		.flex-direction-nav a:hover,
		.ninzio-navigation li a:hover,
		.ninzio-navigation li .current,
		.woocommerce-pagination li a:hover,
		.woocommerce-pagination li .current,
		.widget_price_filter .ui-slider .ui-slider-range,
		.nz-persons .person .title:after,
		.post .post-date:after,
		#nz-content .nz-single-image:before,
		.widget_twitter .follow,
		.nz-content-box-2 .box-title h3:after,
		.nz-content-box-2 .box-title h3:before,
		.nz-persons .person .title:after,
		.nz-persons .person .title:before,
		.header-top .header-top-menu ul .submenu-languages li a:after,
		.mob-menu-toggle2:hover,#top,.widget_calendar td#today,
		.desk-menu .sub-menu li > a:before,
		.standard .post-date-custom,
		.widget_shopping_cart .cart_list .remove:hover,
		.footer-menu ul li a:after,
		.post .post-category ul li a,
		.single .single-post-content a:before,
		.post-comments-area .comments-title:after,
		.post-comments-area #respond #reply-title:after,
		.comment-meta .replay a:hover,
		.post-single-navigation a:hover,
		.single-projects .post-gallery .flex-direction-nav li a:hover,
		.single .project-details a:after,
		.nz-related-projects h3:after,
		.social-links a:hover,
		.nz-persons .person .name:after,
		.stepset .active .step-title,
		.widget_nz_recent_entries .post-body:before,
		.widget_recent_comments ul li:before,
		.post .post-more:hover:after,
		#nz-content .nz-single-image:hover:before,
		.post .post-date-custom,
		.woocommerce .product .button:hover:before,
		.woocommerce .product .added_to_cart:hover:before,
		.woocommerce .product .product_type_external:hover:before,
		.ninzio-filter .filter.active:after,
		#projects-pagination span:hover,
		.woocommerce .product .single-product-summary .button:hover,
		.woocommerce .product .single-product-summary .added_to_cart:hover,
		.woocommerce .product .single-product-summary .product_type_external:hover,
		.nz-accordion .toggle-icon {
			background-color: '.$lifefitness_ninzio_main_color.' !important;
		}';

		$dynamic_css .='button,
		input[type="reset"],
		input[type="submit"],
		input[type="button"],
		.single-details .project-link,
		.wc-proceed-to-checkout a,
		.woocommerce-message .button.wc-forward,
		a.edit,a.view,#nz-content .nz-single-image:before,
		.woocommerce .product .onsale,
		.woocommerce .single-product-summary .product_meta a:after,
		.woocommerce-tabs .panel > h2:after, 
		.woocommerce-tabs .panel > #reviews > #comments > h2:after,
		.button-ghost.default.icon-true.animate-false .btn-icon:after,
		#comments #submit:hover,
		.ajax-loading-wrap .load-bar:before,
		.owl-controls .owl-page.active,
		.widget_shopping_cart p.buttons > a, 
		.widget_price_filter .price_slider_amount .button,
		.post .post-more:after,
		.nz-content-box.version3 .box-title,
		.button.wc-backward {
			background-color: '.$lifefitness_ninzio_main_color.';
		}';


		$dynamic_css .='button:hover,input[type="reset"]:hover,
		input[type="submit"]:hover,input[type="button"]:hover,
		.single-details .project-link:hover,
		.woocommerce .single-product-summary .button:hover,
		.wc-proceed-to-checkout a:hover,
		.woocommerce-message .button.wc-forward:hover,
		.single_add_to_cart_button:hover,
		a.edit:hover,a.view:hover,
		.button-normal.default.icon-true.animate-false .btn-icon:after,
		.button-3d.default.icon-true.animate-false .btn-icon:after,
		.button-ghost.default.icon-true.animate-false:hover .btn-icon:after,
		.widget_shopping_cart p.buttons > a:hover, 
		.widget_price_filter .price_slider_amount .button:hover,
		.button.wc-backward:hover {
			background-color: '.lifefitness_ninzio_hex_to_rgb_shade($lifefitness_ninzio_main_color,20).';
		}';

		$dynamic_css .='.button-normal.default.icon-true.animate-false:hover .btn-icon:after {
			background-color: '.lifefitness_ninzio_hex_to_rgb_shade($lifefitness_ninzio_main_color,40).';
		}';


		$dynamic_css .='.widget_recent_projects .ninzio-overlay {
			background-color: '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.9).';
		}';

		$dynamic_css .='.sidebar .widget_tag_cloud .tagcloud a:hover, 
		.sidebar .post-tags a:hover, 
		.sidebar .widget_product_tag_cloud .tagcloud a:hover, 
		.sidebar .projects-tags a:hover,
		.footer .widget_tag_cloud .tagcloud a:hover, 
		.footer .post-tags a:hover, 
		.footer .widget_product_tag_cloud .tagcloud a:hover, 
		.footer .projects-tags a:hover,
		.comment-meta .replay a:hover,
		.single .post-tags > *:hover,
		.mob-header .widget_tag_cloud .tagcloud a:hover, 
		.mob-header .post-tags a:hover, 
		.mob-header .widget_product_tag_cloud .tagcloud a:hover, 
		.mob-header .projects-tags a:hover {
			box-shadow: inset 0 0 0 2px '.$lifefitness_ninzio_main_color.';
		}';

		$dynamic_css .='.widget_nav_menu li a:before,
		.widget_product_categories li a:before,
		.widget_categories ul li a:before,
		.widget_pages ul li a:before,
		.widget_archive ul li a:before,
		.widget_meta ul li a:before {
			box-shadow: inset 0 0 0 1px '.$lifefitness_ninzio_main_color.' !important;
			color: '.$lifefitness_ninzio_main_color.' !important;
		}';

		$dynamic_css .='.nz-pricing-table .c-row .icon {
			box-shadow: inset 0 0 0 1px '.$lifefitness_ninzio_main_color.';
			color:'.$lifefitness_ninzio_main_color.';
		}';

		$dynamic_css .='#single-product-carousel .slides li.flex-active-slide:after {
			box-shadow: inset 0 0 0 2px '.$lifefitness_ninzio_main_color.' !important;
		}';

		$dynamic_css .='.nz-persons .person .ninzio-overlay {
			box-shadow: inset 0 0 0 5px '.$lifefitness_ninzio_main_color.' !important;
		}';

		$dynamic_css .='.slick-dots li.slick-active button {
			box-shadow: inset 0 0 0 20px '.$lifefitness_ninzio_main_color.' !important;
		}';

		$dynamic_css .='.zoomWindowContainer .zoomWindow {
			border: 2px solid '.$lifefitness_ninzio_main_color.' !important;
		}';

		$dynamic_css .='.shop-loader span {
			border-left: 2px solid '.$lifefitness_ninzio_main_color.';
		}';

		$dynamic_css .='.nz-loader {
			border-top: 1px solid '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.1).';
			border-right: 1px solid '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.1).';
			border-bottom: 1px solid '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.1).';
			border-left: 1px solid '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.5).';
		}';

		$dynamic_css .='.widget_price_filter .ui-slider .ui-slider-handle,
		.widget_tag_cloud .tagcloud a:after,
		.post-tags a:after,
		.widget_product_tag_cloud .tagcloud a:after,
		.projects-tags a:after,
		.widget_tag_cloud .tagcloud a:before,
		.post-tags a:before,
		.widget_product_tag_cloud .tagcloud a:before,
		.projects-tags a:before,
		.widget_price_filter .price_slider_amount .button:before,
		.widget_price_filter .price_slider_amount .button:after {
			border-color: '.$lifefitness_ninzio_main_color.' !important;
		}';

		$dynamic_css .='.single-details .nz-i-list span.icon {
			box-shadow: inset 0 0 0 20px '.$lifefitness_ninzio_main_color.';
		}';

		$dynamic_css .='.nz-pricing-table > .column.highlight-true .column-inner {
			box-shadow:inset 0 0 0 3px '.$lifefitness_ninzio_main_color.';
		}';

		$dynamic_css .='.nz-pricing-table > .column.highlight-true .c-foot a {
			background-color:'.$lifefitness_ninzio_main_color.' !important;
			box-shadow: inset 0 0 0 2px '.$lifefitness_ninzio_main_color.';
		}';

		$dynamic_css .='.nz-pricing-table > .column.highlight-true .c-foot a:hover {
			background-color:'.lifefitness_ninzio_hex_to_rgb_shade($lifefitness_ninzio_main_color,20).' !important;
			box-shadow: inset 0 0 0 2px '.lifefitness_ninzio_hex_to_rgb_shade($lifefitness_ninzio_main_color,20).' !important;
		}';

		$dynamic_css .='.single .project-details ul li:before{
			color:'.$lifefitness_ninzio_main_color.';
			box-shadow: inset 0 0 0 1px '.$lifefitness_ninzio_main_color.';
		}';

		$dynamic_css .='.default.button-normal{background-color: '.$lifefitness_ninzio_main_color.';}';
		$dynamic_css .='.default.button-ghost {box-shadow:inset 0 0 0 2px '.$lifefitness_ninzio_main_color.';color:'.$lifefitness_ninzio_main_color.';}';
		$dynamic_css .='.default.button-3d {background-color:'.$lifefitness_ninzio_main_color.';box-shadow: 0 4px '.lifefitness_ninzio_hex_to_rgb_shade($lifefitness_ninzio_main_color,50).';}';

		$dynamic_css .='.default.animate-false.button-3d:hover {box-shadow: 0 2px '.lifefitness_ninzio_hex_to_rgb_shade($lifefitness_ninzio_main_color,50).';}';
		$dynamic_css .='.default.animate-false.button-normal.hover-fill:hover{background-color: '.lifefitness_ninzio_hex_to_rgb_shade($lifefitness_ninzio_main_color,20).';}';
		
		$dynamic_css .='.default.button-ghost.hover-fill:hover,
		.default.button-ghost.hover-drop:after,
		.default.button-ghost.hover-side:after,
		.default.button-ghost.hover-scene:after,
		.default.button-ghost.hover-screen:after
		{background-color: '.$lifefitness_ninzio_main_color.';}';

		$dynamic_css .='.ajax-loading-wrap .cssload-spin-box {
			margin: 10px auto;
			position: relative;
			overflow: hidden;
			width: 15px;
			height: 15px;
			border-radius: 100%;
			box-shadow: 15px 15px '.$lifefitness_ninzio_main_color.', -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', -15px -15px '.$lifefitness_ninzio_main_color.', 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).';
			-ms-box-shadow: 15px 15px '.$lifefitness_ninzio_main_color.', -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', -15px -15px '.$lifefitness_ninzio_main_color.', 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).';
			-webkit-box-shadow: 15px 15px '.$lifefitness_ninzio_main_color.', -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', -15px -15px '.$lifefitness_ninzio_main_color.', 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).';
			animation: cssload-spin ease infinite 2.6s;
			-ms-animation: cssload-spin ease infinite 2.6s;
			-webkit-animation: cssload-spin ease infinite 2.6s;
		}';

		$dynamic_css .='#projects-load-more .project-loader:before {
		    border-left: 2px solid '.$lifefitness_ninzio_main_color.';
		}';

		$dynamic_css .='@keyframes cssload-spin {
			0%,100% {box-shadow: 15px 15px '.$lifefitness_ninzio_main_color.', -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', -15px -15px '.$lifefitness_ninzio_main_color.', 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).';}
			25% {box-shadow: -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', -15px -15px '.$lifefitness_ninzio_main_color.', 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', 15px 15px '.$lifefitness_ninzio_main_color.';}
			50% {box-shadow: -15px -15px '.$lifefitness_ninzio_main_color.', 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', 15px 15px '.$lifefitness_ninzio_main_color.', -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).';}
			75% {box-shadow: 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.8).', 15px 15px '.$lifefitness_ninzio_main_color.', -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.8).', -15px -15px '.$lifefitness_ninzio_main_color.';}
		}';

		$dynamic_css .='@-ms-keyframes cssload-spin {
			0%,100% {box-shadow: 15px 15px '.$lifefitness_ninzio_main_color.', -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', -15px -15px '.$lifefitness_ninzio_main_color.', 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).';}
			25% {box-shadow: -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', -15px -15px '.$lifefitness_ninzio_main_color.', 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', 15px 15px '.$lifefitness_ninzio_main_color.';}
			50% {box-shadow: -15px -15px '.$lifefitness_ninzio_main_color.', 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', 15px 15px '.$lifefitness_ninzio_main_color.', -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).';}
			75% {box-shadow: 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.8).', 15px 15px '.$lifefitness_ninzio_main_color.', -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.8).', -15px -15px '.$lifefitness_ninzio_main_color.';}
		}';

		$dynamic_css .='@-webkit-keyframes cssload-spin {
			0%,100% {box-shadow: 15px 15px '.$lifefitness_ninzio_main_color.', -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', -15px -15px '.$lifefitness_ninzio_main_color.', 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).';}
			25% {box-shadow: -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', -15px -15px '.$lifefitness_ninzio_main_color.', 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', 15px 15px '.$lifefitness_ninzio_main_color.';}
			50% {box-shadow: -15px -15px '.$lifefitness_ninzio_main_color.', 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).', 15px 15px '.$lifefitness_ninzio_main_color.', -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.2).';}
			75% {box-shadow: 15px -15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.8).', 15px 15px '.$lifefitness_ninzio_main_color.', -15px 15px '.lifefitness_ninzio_hex_to_rgba($lifefitness_ninzio_main_color,0.8).', -15px -15px '.$lifefitness_ninzio_main_color.';}
		}';


	/*  HEADER
	/*-------------------------*/

		if ($nz_header_bar == "true") {

			$dynamic_css .='.desk,
			.footer .footer-info-area {
				padding-top:4px;
			}';

			$dynamic_css .='#top {
			    background-color:'.$nz_header_bar_color_3.' !important;
			}';

			$dynamic_css .='.desk:before,
			.footer .footer-info-area:before {
				content:"";
				display:block;
				width:100%;
				height:5px;
				position:absolute;
				top:0;
				left:0;
			    background: -webkit-linear-gradient(90deg,'.$nz_header_bar_color_1.','.$nz_header_bar_color_2.','.$nz_header_bar_color_3.');
			    background: -o-linear-gradient(90deg,'.$nz_header_bar_color_1.','.$nz_header_bar_color_2.','.$nz_header_bar_color_3.');
			    background: -moz-linear-gradient(90deg,'.$nz_header_bar_color_1.','.$nz_header_bar_color_2.','.$nz_header_bar_color_3.');
			    background: linear-gradient(90deg,'.$nz_header_bar_color_1.','.$nz_header_bar_color_2.','.$nz_header_bar_color_3.');
			}';
		}

		$dynamic_css .='.mob-header-top {
		   	height: '.$nz_mob_height.'px !important;
		    line-height: '.$nz_mob_height.'px !important;
		}';

		$dynamic_css .='.mob-header-top .mob-menu-toggle,
	    .mob-sidebar-toggle {
			top: '.(($nz_mob_height-30)/2).'px !important;
		}';

		$dynamic_css .='.version1 .header-top {
			background-color: '.$nz_h1_header_top_back_color.';
		}';

		if(!empty($nz_h1_header_top_border_color)){
			$dynamic_css .='.version1 .header-top {
				border-bottom:1px solid '.$nz_h1_header_top_border_color.';
			}';
		}

		$dynamic_css .='.version1 .header-top .header-top-menu ul li a,.version1 .header-top .social-text {
		    color: '.$nz_h1_header_top_menu_color_reg.';
			font-weight: '.$nz_h1_header_top_menu_font_weight.';
			font-size: '.$nz_h1_header_top_menu_font_size.';
			text-transform: '.$nz_h1_header_top_menu_text_transform.';
		}';

		$dynamic_css .='.version1 .header-top .header-top-menu ul li:hover > a {
		    color: '.$nz_h1_header_top_menu_color_hov.';
		}';

		$dynamic_css .='.version1 .header-top .header-top-menu > ul > li:not(:last-child):after {
			color: '.lifefitness_ninzio_hex_to_rgba($nz_h1_header_top_menu_color_reg,0.3).';
		}';

		$dynamic_css .='.version1 .header-top .top-button {
		    color: '.$nz_h1_top_button_text_color.';
		    background-color: '.$nz_h1_top_button_back_color.';
		}';

		$dynamic_css .='.version1 .header-top .top-button:hover {
		    background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h1_top_button_back_color,20).';
		}';

		$dynamic_css .='.version1 .header-top .header-top-menu ul li ul.submenu-languages,
		.version1 .desk-menu > ul > li ul.submenu-languages
		{width: '.$nz_h1_desk_ls_w .';}';

		$dynamic_css .='.version1.top-false {
			height:'.$nz_h1_desk_height.'px;
		}';

		$dynamic_css .='.version1.top-true {
			height:'.(40+$nz_h1_desk_height).'px;
		}';

		$dynamic_css .='.version1 .header-body {
		    background-color: '.$nz_h1_desk_back_color.';';
		    if(!empty($nz_h1_desk_border_color)){
				$dynamic_css .='border-bottom:1px solid '.$nz_h1_desk_border_color.';';
		    }
			$dynamic_css .='height:'.$nz_h1_desk_height.'px;
		}';

		$dynamic_css .='.version1 .logo,
		.version1 .logo-title {
			height: '.$nz_h1_desk_height.'px;
			line-height: '.$nz_h1_desk_height.'px;
		}';

		$dynamic_css .='.version1 .desk-menu .sub-menu {
			top: '.$nz_h1_desk_height.'px;
		}';

		$dynamic_css .='.version1 .search {
			top: '.($nz_h1_desk_height/2 + 20).'px;
		}';

		$dynamic_css .='.version1 .desk-cart-wrap {
			height:'.$nz_h1_desk_height.'px;
		}';

		$dynamic_css .='.version1 .desk-cart-wrap .cart-info {
			background-color:'.$nz_h1_desk_cart_back_color.';
			color:'.$nz_h1_desk_cart_text_color.';
		}';

		$dynamic_css .='.version1 .search-toggle-wrap,
		.version1 .desk-cart-toggle,
		.version1 .site-sidebar-toggle,
		.version1 .header-social-links {
			margin-top: '.(($nz_h1_desk_height-40)/2).'px;
		}';

		$dynamic_css .='.version1 .site-sidebar-toggle {
			background-color: '.$nz_h1_desk_sidebar_toggle_color.';
			box-shadow:inset 0 0 0 2px '.$nz_h1_desk_sidebar_toggle_border_color.';
		}';

		$dynamic_css .='.version1 .woo-cart {
		    top: '.$nz_h1_desk_height.'px;
		}';

		$dynamic_css .='.version1 .desk-menu > ul > li {
			margin-left: '.$nz_h1_desk_menu_m.'px !important;
			height: '.$nz_h1_desk_height.'px;
			line-height: '.$nz_h1_desk_height.'px;
		}';

		$dynamic_css .='.version1:not(.active) .logo-title {
			color: '.$nz_h1_desk_menu_color_reg.';
		}';

		$dynamic_css .='.version1 .desk-menu > ul > li > a {
		    color: '.$nz_h1_desk_menu_color_reg.';
			text-transform: '.$nz_h1_desk_menu_text_transform.';
			font-weight: '.$nz_h1_desk_menu_font_weight.';
			font-size: '.$nz_h1_desk_menu_font_size.';
			font-family: '.$nz_h1_desk_menu_font_family.';
			margin-top: '.(($nz_h1_desk_height-30)/2).'px;
		}';

		$dynamic_css .='.version1 .desk-cart-toggle span {
		    color: '.$nz_h1_desk_menu_color_reg.';';
		    if ($nz_h1_desk_menu_text_transform == "none"){
		    	$dynamic_css .='margin-left: -11px;';
		    }
		$dynamic_css .='}';

		$dynamic_css .='.version1 .desk-menu > ul > li.menu-item-language > a > .txt {
			box-shadow: inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_menu_color_reg,0.5).';
		}';

		$dynamic_css .='.version1 .desk-menu > ul > li.menu-item-language:hover > a > .txt {
			box-shadow: inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_menu_color_reg,0.7).';
		}';

		$dynamic_css .='.version1 .desk-menu > ul > li:hover > a,
		.version1 .desk-menu > ul > li.one-page-active > a,
		.version1 .desk-menu > ul > li.current-menu-item > a,
		.version1 .desk-menu > ul > li.current-menu-parent > a,
		.version1 .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h1_desk_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.version1 .desk-menu > ul > li.current-menu-item > a,
		.one-page-top.version1 .desk-menu > ul > li.current-menu-parent > a,
		.one-page-top.version1 .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h1_desk_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.version1 .desk-menu > ul > li:hover > a,
		.one-page-top.version1 .desk-menu > ul > li.one-page-active > a {
		    color: '.$nz_h1_desk_menu_color_hov.' !important;
		}';

		$dynamic_css .='.version1 .desk-menu .sub-menu,
		.version1 .header-top .header-top-menu ul li ul,
		.version1 .woo-cart {
			background-color: '.$nz_h1_desk_submenu_back_color.';
		}';

		$dynamic_css .='.version1 .search {
			background-color: '.$nz_h1_desk_submenu_back_color.' !important;
		}';

		$dynamic_css .='.version1 .desk-menu .sub-menu .sub-menu {
			background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h1_desk_submenu_back_color,20).';
		}';

		$dynamic_css .='.version1 .desk-menu .sub-menu li > a {
		    color: '.$nz_h1_desk_submenu_color_reg.';
			text-transform: '.$nz_h1_desk_submenu_text_transform.';
			font-weight: '.$nz_h1_desk_submenu_font_weight.';
			font-size: '.$nz_h1_desk_submenu_font_size.';
			line-height: '.$nz_h1_desk_submenu_line_height.';
			font-family: '.$nz_h1_desk_submenu_font_family.';
		}';

		$dynamic_css .='.version1 .header-top .header-top-menu ul li ul li a {
		    color: '.$nz_h1_desk_submenu_color_reg.';
		}';

		$dynamic_css .='.version1 .desk-menu .sub-menu li:hover > a,
		.version1 .header-top .header-top-menu ul li ul li:hover > a {
		    color: '.$nz_h1_desk_submenu_color_hov.';
		}';
		
		$dynamic_css .='.version1 .desk-menu [data-mm="true"] > .sub-menu > li > a {
			text-transform: '.$nz_h1_desk_megamenu_text_transform.';
			font-weight: '.$nz_h1_desk_megamenu_font_weight.';
			font-size: '.$nz_h1_desk_megamenu_font_size.';
			color: '.$nz_h1_desk_megamenu_color.' !important;
			font-family: '.$nz_h1_desk_menu_font_family.';
		}';

		$dynamic_css .='.version1 .desk-menu > ul > [data-mm="true"] > .sub-menu > li:not(:last-child):after {
			background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_megamenu_color,0.1).' !important;
		}';

		if (isset($nz_h1_desk_megamenu_top_border) && !empty($nz_h1_desk_megamenu_top_border)) {
			
			$dynamic_css .='.version1 .desk-menu [data-mm="true"] > .sub-menu > li > a {
				padding: 0px 0 30px 0;
				position:relative;
			}';

			$dynamic_css .='.version1 .desk-menu [data-mm="true"] > .sub-menu > li > a:after {
				background-color: '.$nz_h1_desk_megamenu_top_border.';
				display:block;
				content: "";
			    width: 50px;
			    height: 2px;
			    display: block;
			    bottom: 22px;
			    left:0px;
			    position:absolute;
			}';

			$dynamic_css .='.version1 .yawp_wim_title {
				position:relative;
				padding: 0px 0 43px 0 !important;
				margin-bottom:0;
				line-height: '.$nz_h1_desk_submenu_line_height.';
			}';

			$dynamic_css .='.version1 .yawp_wim_title:after {
				background-color: '.$nz_h1_desk_megamenu_top_border.';
				display:block;
				content: "";
			    width: 50px;
			    height: 2px;
			    display: block;
			    bottom: 34px;
			    left:0px;
			    position:absolute;
			}';
		}

		$dynamic_css .='.version1 .desk-menu .sub-menu .label {font-family: '.$nz_h1_desk_menu_font_family.';}';

		$dynamic_css .='.version1 .search-true.cart-false .search-toggle:after,
		.version1 .cart-true .desk-cart-wrap:after {
			background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_menu_color_reg,0.2).';
		}';

		$dynamic_css .='.version1 .search input[type="text"] {
		    color: '.$nz_h1_desk_submenu_color_reg.';
		}';

		/*EFFECTS*/
		$dynamic_css .='.version1.effect-underline .desk-menu > ul > li > a:after,
		.version1.effect-overline .desk-menu > ul > li > a:after,
		.version1.effect-fill .desk-menu > ul > li:hover,
		.version1.effect-fill .desk-menu > ul > li.one-page-active > a,
		.version1.effect-fill .desk-menu > ul > li.current-menu-item,
		.version1.effect-fill .desk-menu > ul > li.current-menu-parent,
		.version1.effect-fill .desk-menu > ul > li.current-menu-ancestor {
			background-color: '.$nz_h1_desk_menu_effect_color.';
		}';

		$dynamic_css .='.version1.effect-dottes .desk-menu > ul > li > a .dottes,
		.version1.effect-dottes .desk-menu > ul > li > a .dottes:after,
		.version1.effect-dottes .desk-menu > ul > li > a .dottes:before {
			background-color: '.$nz_h1_desk_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version1.effect-fill .desk-menu > ul > li:hover,
		.one-page-top.version1.effect-fill .desk-menu > ul > li.one-page-active {
			background-color: '.$nz_h1_desk_menu_effect_color.' !important;
		}';

		$dynamic_css .='.version1.effect-outline .desk-menu > ul > li:hover > a,
		.version1.effect-outline .desk-menu > ul > li.one-page-active > a,
		.version1.effect-outline .desk-menu > ul > li.current-menu-item > a,
		.version1.effect-outline .desk-menu > ul > li.current-menu-parent > a,
		.version1.effect-outline .desk-menu > ul > li.current-menu-ancestor > a {
			box-shadow: inset 0 0 0 2px '.$nz_h1_desk_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version1.effect-outline .desk-menu > ul > li:hover > a,
		.one-page-top.version1.effect-outline .desk-menu > ul > li.one-page-active > a {
			box-shadow: inset 0 0 0 2px '.$nz_h1_desk_menu_effect_color.' !important;
		}';

		$dynamic_css .='.version1.effect-overline .desk-menu > ul > li > a:after {
			top:-'.(($nz_h1_desk_height-30)/2).'px;
		}';

		if (isset($nz_h1_desk_separator_color) && !empty($nz_h1_desk_separator_color)) {
			$dynamic_css .='.version1 .desk-menu > ul:after {
				content:"";
				display:block;
				float:left;
				width:1px;
				height:30px;
				margin-top:'.(($nz_h1_desk_height - 30)/2).'px;
				margin-left: 25px;
    			margin-right: 5px;
				background-color:'.$nz_h1_desk_separator_color.';
				-webkit-transition: all 300ms linear;
				transition: all 300ms linear;
			}';

			if ($nz_h1_header_social_links == 'true') {
				$dynamic_css .='.version1 .header-social-links:before {
					content:"";
					display:block;
					position:absolute;
					margin-top:0 !important;
					left:-20px;
					top:5px;
					width:1px;
					height:30px;
					background-color:'.$nz_h1_desk_separator_color.';
					-webkit-transition: all 300ms linear;
					transition: all 300ms linear;
				}';
			}
		}

		/*WIDGETS ------*/

			$dynamic_css .='.version1 .menu-item-type-yawp_wim,
			.version1 .menu-item-type-yawp_wim a:not(.button) {
				color: '.$nz_h1_desk_submenu_color_reg.';
				text-transform: '.$nz_h1_desk_submenu_text_transform.';
				font-weight: '.$nz_h1_desk_submenu_font_weight.';
				font-size: '.$nz_h1_desk_submenu_font_size.';
				line-height: '.$nz_h1_desk_submenu_line_height.';
				font-family: '.$nz_h1_desk_submenu_font_family.';
			}';

			$dynamic_css .='.version1 .widget_rss a, 
			.version1 .widget_nz_recent_entries a, 
			.version1 .widget_recent_comments a, 
			.version1 .widget_recent_entries a,
			.version1 .widget_nz_recent_entries .post .post-date,
			.version1 .nz-schedule li,
			.version1 .widget_twitter .tweet-time,
			.version1 .widget_shopping_cart .cart_list > li > a {
				color: '.$nz_h1_desk_submenu_color_reg.' !important;
			}';

			$dynamic_css .='.version1 .widget_rss a:hover, 
			.version1 .widget_nz_recent_entries a:hover, 
			.version1 .widget_recent_comments a:hover, 
			.version1 .widget_recent_entries a:hover,
			.version1 .widget_shopping_cart .cart_list > li > a:hover {
				color: '.$nz_h1_desk_submenu_color_hov.' !important;
			}';

			$dynamic_css .='.version1 .widget_twitter ul li:before,
			.version1 .widget_nz_recent_entries .post-body:before,
			.version1 .widget_recent_comments ul li:before {
				color: '.$nz_h1_megamenu_buttons_back_color.' !important;
			}';

			$dynamic_css .='.version1 .widget_nz_recent_entries .post-body:before,
			.version1 .widget_recent_comments ul li:before {
				color: '.$nz_h1_desk_submenu_color_reg.' !important;
				background-color: '.$nz_h1_megamenu_buttons_back_color.' !important;
			}';

			$dynamic_css .='.version1 .nz-schedule ul li {
				border-bottom: 1px dashed '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_submenu_color_reg, 0.2).';
			}';

			$dynamic_css .='.version1 .widget_shopping_cart .cart_list > li,
			.version1 .widget_products .product_list_widget > li, 
			.version1 .widget_recently_viewed_products .product_list_widget > li,
			.version1 .widget_recent_reviews .product_list_widget > li, 
			.version1 .widget_top_rated_products .product_list_widget > li {
				border-bottom: 1px dashed '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_submenu_color_reg, 0.2).';
			}';

			$dynamic_css .='.version1 .widget_price_filter .price_slider_wrapper .ui-widget-content {
				background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_submenu_color_reg, 0.2).' !important;
			}';

			$dynamic_css .='.version1 .widget_calendar td#prev, 
			.version1 .widget_calendar td#next,
			.version1 .widget_calendar td,
			.version1 .widget_calendar caption,
			.version1 .widget_calendar th:first-child,
			.version1 .widget_calendar th:last-child {
				border-color: '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_submenu_color_reg, 0.2).';
			}';


			$dynamic_css .='.version1 .widget_tag_cloud .tagcloud a:hover,
			.version1 .widget_product_tag_cloud .tagcloud a:hover, 
			.version1 .post-tags a:hover, 
			.version1 .projects-tags a:hover {
				color: '.$nz_h1_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version1 .widget_calendar td#today {
				background-color: '.$nz_h1_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version1 .widget_tag_cloud .tagcloud a:hover,
			.version1 .widget_product_tag_cloud .tagcloud a:hover, 
			.version1 .post-tags a:hover, 
			.version1 .projects-tags a:hover,
			.version1 .widget_tag_cloud .tagcloud a:hover,
			.version1 .widget_product_tag_cloud .tagcloud a:hover, 
			.version1 .post-tags a:hover, 
			.version1 .projects-tags a:hover {
				box-shadow:inset 0 0 0 2px '.$nz_h1_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version1 .widget_nav_menu ul li:hover a {
				color: '.$nz_h1_desk_submenu_color_reg.' !important;
			}';

			$dynamic_css .='.version1 .widget_product_categories ul li a:hover,
			.version1 .widget_shopping_cart p.buttons > a:hover,
			.version1 .widget_recent_entries a:hover,
			.version1 .widget_categories ul li a:hover,
			.version1 .widget_pages ul li a:hover,
			.version1 .widget_archive ul li a:hover,
			.version1 .widget_meta ul li a:hover,
			.version1 .widget_nz_recent_entries .post-title:hover,
			.version1 .widget_price_filter .price_slider_amount .button:hover,
			.version1 .widget_shopping_cart .cart_list > li > a:hover,
			.version1 .widget_products .product_list_widget > li > a:hover,
			.version1 .widget_recently_viewed_products .product_list_widget > li > a:hover,
			.version1 .widget_recent_reviews .product_list_widget > li > a:hover,
			.version1 .widget_top_rated_products .product_list_widget > li > a:hover,
			.version1 .widget_recent_entries a:hover, 
			.version1 .widget_nz_recent_entries .post-title:hover,
			.version1 .widget_product_categories ul li a:hover, 
			.version1 .widget_nav_menu ul li a:hover,
			.version1 .widget_recent_comments a:hover {
				color: '.$nz_h1_desk_submenu_color_hov.' !important;
			}';

			$dynamic_css .='.version1 .menu-item-type-yawp_wim a:hover {
				color: '.$nz_h1_desk_submenu_color_hov.';
			}';

			$dynamic_css .='.version1 textarea, 
			.version1 select, 
			.version1 input[type="date"], 
			.version1 input[type="datetime"], 
			.version1 input[type="datetime-local"], 
			.version1 input[type="email"], 
			.version1 input[type="month"], 
			.version1 input[type="number"], 
			.version1 input[type="password"], 
			.version1 input[type="search"], 
			.version1 input[type="tel"], 
			.version1 input[type="text"], 
			.version1 input[type="time"], 
			.version1 input[type="url"], 
			.version1 input[type="week"] {
				box-shadow: inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_submenu_color_reg,0.25).';
				color: '.$nz_h1_desk_submenu_color_reg.';
			}';

			$dynamic_css .='.version1 textarea:hover, 
			.version1 select:hover, 
			.version1 input[type="date"]:hover, 
			.version1 input[type="datetime"]:hover, 
			.version1 input[type="datetime-local"]:hover, 
			.version1 input[type="email"]:hover, 
			.version1 input[type="month"]:hover, 
			.version1 input[type="number"]:hover, 
			.version1 input[type="password"]:hover, 
			.version1 input[type="search"]:hover, 
			.version1 input[type="tel"]:hover, 
			.version1 input[type="text"]:hover, 
			.version1 input[type="time"]:hover, 
			.version1 input[type="url"]:hover, 
			.version1 input[type="week"]:hover {
				color: '.$nz_h1_desk_submenu_color_hov.' !important;
			}';

			$dynamic_css .='.version1 .desk-menu .button,
			.version1 .desk-menu button,
			.version1 .desk-menu input[type="reset"],
			.version1 .desk-menu input[type="submit"],
			.version1 .desk-menu input[type="button"],
			.version1 .widget_recent_comments ul li:before {
				background-color:'.$nz_h1_megamenu_buttons_back_color.' !important;
				color: '.$nz_h1_megamenu_buttons_text_color.' !important;
			}';

			$dynamic_css .='.version1 .desk-menu .button:hover,
			.version1 .desk-menu button:hover,
			.version1 .desk-menu input[type="reset"]:hover,
			.version1 .desk-menu input[type="submit"]:hover,
			.version1 .desk-menu input[type="button"]:hover {
				background-color:'.lifefitness_ninzio_hex_to_rgb_shade($nz_h1_megamenu_buttons_back_color,20).' !important;
			}';

			$dynamic_css .='.version1 ::-webkit-input-placeholder {color: '.$nz_h1_desk_submenu_color_reg.';}';
			$dynamic_css .='.version1 :-moz-placeholder           {color: '.$nz_h1_desk_submenu_color_reg.';}';
			$dynamic_css .='.version1 ::-moz-placeholder          {color: '.$nz_h1_desk_submenu_color_reg.';}';
			$dynamic_css .='.version1 :-ms-input-placeholder      {color: '.$nz_h1_desk_submenu_color_reg.';}';

			$dynamic_css .='.version1 .widget_price_filter .ui-slider .ui-slider-handle {
				border-color: '.$nz_h1_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version1 .widget_shopping_cart p.buttons > a:hover, 
			.version1 .widget_shopping_cart p.buttons > a:hover, 
			.version1 .widget_price_filter .price_slider_amount .button:hover {
				box-shadow:inset 0 0 0 2px '.$nz_h1_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version1 .widget_price_filter .ui-slider .ui-slider-range {
				background-color: '.$nz_h1_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version1 .widget_shopping_cart p.buttons > a:hover,
			.version1 .widget_price_filter .price_slider_amount .button:hover {
				color: '.$nz_h1_desk_menu_effect_color.' !important;
			}';


			$dynamic_css .='.version1 .yawp_wim_title {
				text-transform: '.$nz_h1_desk_megamenu_text_transform.';
				font-weight: '.$nz_h1_desk_megamenu_font_weight.';
				font-size: '.$nz_h1_desk_megamenu_font_size.';
				color: '.$nz_h1_desk_megamenu_color.' !important;
				font-family: '.$nz_h1_desk_menu_font_family.';
			}';


			$dynamic_css .='.version1 .widget_tag_cloud .tagcloud a,
			.version1 .post-tags a,
			.version1 .widget_product_tag_cloud .tagcloud a,
			.version1 .projects-tags a {
				font-family: '.$nz_h1_desk_menu_font_family.';
				color: '.$nz_h1_desk_submenu_color_reg.';
				box-shadow:inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_submenu_color_reg, 0.3).' !important;
			}';

			$dynamic_css .='.version1 .widget_shopping_cart {
			    color: '.$nz_h1_desk_submenu_color_reg.';
			}';

			$dynamic_css .='.version1 .widget_shopping_cart .cart_list li {
				border-bottom: 1px solid '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_submenu_color_reg,0.2).';
			}';

			$dynamic_css .='.version1 .widget_shopping_cart .cart_list li .remove {
				background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h1_desk_submenu_back_color,10).' !important;
			}';

			$dynamic_css .='.version1 .widget_shopping_cart .cart_list li .remove:hover {
				background-color: '.$nz_h1_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version1 .widget_shopping_cart .cart_list li img {
			    background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_submenu_color_reg,0.1).';
			}';

			$dynamic_css .='.version1 .widget_shopping_cart .cart_list li:hover img {
			    background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_submenu_color_reg,0.2).';
			}';

			$dynamic_css .='.version1 .widget_shopping_cart p.buttons > a, 
			.version1 .widget_price_filter .price_slider_amount .button {
				color: '.$nz_h1_desk_submenu_color_reg.' !important;
				box-shadow:inset 0 0 0 2px '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_submenu_color_reg, 0.3).' !important;
			}';

			$dynamic_css .='.version1 .widget_shopping_cart p.buttons > a:hover, 
			.version1 .widget_price_filter .price_slider_amount .button:hover {
				color: '.$nz_h1_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version1 .star-rating:before {
				color: '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_submenu_color_reg, 0.4).' !important;
			}';


			$dynamic_css .='.version1 .yawp_wim_title a {
				text-transform: '.$nz_h1_desk_megamenu_text_transform.' !important;
				font-weight: '.$nz_h1_desk_megamenu_font_weight.' !important;
				font-size: '.$nz_h1_desk_megamenu_font_size.' !important;
				color: '.$nz_h1_desk_megamenu_color.' !important;
				font-family: '.$nz_h1_desk_menu_font_family.' !important;
			}';

			$dynamic_css .='.version1 .widget_categories ul li,
			.version1 .widget_pages ul li,
			.version1 .widget_archive ul li,
			.version1 .widget_meta ul li {
				border-bottom: 1px dashed '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_submenu_color_reg,0.25).';
			}';

			$dynamic_css .='.version1 .widget_nav_menu li a:before,
			.version1 .widget_product_categories li a:before,
			.version1 .widget_categories ul li a:before,
			.version1 .widget_pages ul li a:before,
			.version1 .widget_archive ul li a:before,
			.version1 .widget_meta ul li a:before {
				box-shadow: inset 0 0 0 1px '.$nz_h1_megamenu_buttons_back_color.' !important;
				color: '.$nz_h1_megamenu_buttons_back_color.' !important;
			}';

		/*------ WIDGETS*/

		/*FIXED*/

		$dynamic_css .='.version1.fixed-true.active .header-body,
		.version1.fixed-true.active {
			height:'.$nz_h1_fixed_height.'px;
		}';

		$dynamic_css .='.version1.fixed-true.active.top-true {
			height:'.($nz_h1_fixed_height + 40).'px;
		}';

		$dynamic_css .='.version1.fixed-true.active .logo,
		.version1.fixed-true.active .logo-title {
			height:'.$nz_h1_fixed_height.'px;
			line-height: '.$nz_h1_fixed_height.'px;
		}';

		$dynamic_css .='.version1.fixed-true.active .desk-menu .sub-menu {
			top: '.$nz_h1_fixed_height.'px;
		}';

		$dynamic_css .='.version1.fixed-true.active .search {
			top: '.($nz_h1_fixed_height/2 + 20).'px;
		}';

		$dynamic_css .='.version1.fixed-true.active .desk-cart-wrap {
			height:'.$nz_h1_fixed_height.'px;
		}';

		$dynamic_css .='.version1.fixed-true.active .search-toggle-wrap,
		.version1.fixed-true.active .desk-cart-toggle,
		.version1.fixed-true.active .site-sidebar-toggle,
		.version1.fixed-true.active .header-social-links {
			margin-top: '.(($nz_h1_fixed_height-40)/2).'px;
		}';

		$dynamic_css .='.version1.fixed-true.active .desk-cart-wrap .cart-info {
			background-color:'.$nz_h1_desk_fixed_cart_back_color.';
			color:'.$nz_h1_desk_fixed_cart_text_color.';
		}';

		$dynamic_css .='.version1.fixed-true.active .woo-cart {
		    top: '.$nz_h1_fixed_height.'px;
		}';

		$dynamic_css .='.version1.fixed-true.active .desk-menu > ul > li {
			height: '.$nz_h1_fixed_height.'px;
			line-height: '.$nz_h1_fixed_height.'px;
		}';

		$dynamic_css .='.version1.fixed-true.active .desk-menu > ul > li > a {
			margin-top: '.(($nz_h1_fixed_height-30)/2).'px;
		}';

		$dynamic_css .='.version1.fixed-true.active .logo-title {
			color: '.$nz_h1_desk_fixed_menu_color_reg.';
		}';

		$dynamic_css .='.version1.fixed-true.active .header-body {
		    background-color: '.$nz_h1_desk_fixed_back_color.';
		}';

		$dynamic_css .='.version1.fixed-true.active .desk-menu > ul > li > a {
		    color: '.$nz_h1_desk_fixed_menu_color_reg.';
		}';

		$dynamic_css .='.version1.fixed-true.active .desk-cart-toggle span {
		    color: '.$nz_h1_desk_fixed_menu_color_reg.';
		}';

		$dynamic_css .='.version1.fixed-true.active .desk-menu > ul > li:hover > a,
		.version1.fixed-true.active .desk-menu > ul > li.one-page-active > a,
		.version1.fixed-true.active .desk-menu > ul > li.current-menu-item > a,
		.version1.fixed-true.active .desk-menu > ul > li.current-menu-parent > a,
		.version1.fixed-true.active .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h1_desk_fixed_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.version1.fixed-true.active .desk-menu > ul > li.current-menu-item > a,
		.one-page-top.version1.fixed-true.active .desk-menu > ul > li.current-menu-parent > a,
		.one-page-top.version1.fixed-true.active .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h1_desk_fixed_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.version1.fixed-true.active .desk-menu > ul > li:hover > a,
		.one-page-top.version1.fixed-true.active .desk-menu > ul > li.one-page-active > a {
		    color: '.$nz_h1_desk_fixed_menu_color_hov.' !important;
		}';

		$dynamic_css .='.version1.fixed-true.active .site-sidebar-toggle {
			background-color: '.$nz_h1_desk_fixed_sidebar_toggle_color.';
			box-shadow:inset 0 0 0 2px '.$nz_h1_desk_fixed_sidebar_toggle_border_color.';
		}';

		$dynamic_css .='.version1.fixed-true.active .search-true.cart-false .search-toggle:after,
		.version1.fixed-true.active .cart-true .desk-cart-wrap:after {
			background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h1_desk_fixed_menu_color_reg,0.2).';
		}';

		$dynamic_css .='.version1.fixed-true.active.effect-outline .desk-menu > ul > li:hover > a,
		.version1.fixed-true.active.effect-outline .desk-menu > ul > li.one-page-active > a,
		.version1.fixed-true.active.effect-outline .desk-menu > ul > li.current-menu-item > a,
		.version1.fixed-true.active.effect-outline .desk-menu > ul > li.current-menu-parent > a,
		.version1.fixed-true.active.effect-outline .desk-menu > ul > li.current-menu-ancestor > a {
			box-shadow: inset 0 0 0 2px '.$nz_h1_desk_fixed_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version1.fixed-true.active.effect-outline .desk-menu > ul > li:hover > a,
		.one-page-top.version1.fixed-true.active.effect-outline .desk-menu > ul > li.one-page-active > a {
			box-shadow: inset 0 0 0 2px '.$nz_h1_desk_fixed_menu_effect_color.' !important;
		}';

		$dynamic_css .='.version1.fixed-true.active.effect-underline .desk-menu > ul > li > a:after,
		.version1.fixed-true.active.effect-overline .desk-menu > ul > li > a:after,
		.version1.fixed-true.active.effect-fill .desk-menu > ul > li:hover,
		.version1.fixed-true.active.effect-fill .desk-menu > ul > li.one-page-active,
		.version1.fixed-true.active.effect-fill .desk-menu > ul > li.current-menu-item,
		.version1.fixed-true.active.effect-fill .desk-menu > ul > li.current-menu-parent,
		.version1.fixed-true.active.effect-fill .desk-menu > ul > li.current-menu-ancestor {
			background-color: '.$nz_h1_desk_fixed_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version1.fixed-true.active.effect-fill .desk-menu > ul > li:hover,
		.one-page-top.version1.fixed-true.active.effect-fill .desk-menu > ul > li.one-page-active {
			background-color: '.$nz_h1_desk_fixed_menu_effect_color.' !important;
		}';

		if (isset($nz_h1_desk_fixed_separator_color) && !empty($nz_h1_desk_fixed_separator_color)) {
			$dynamic_css .='.version1.fixed-true.active .desk-menu > ul:after, 
			.version1.fixed-true.active .header-social-links:before {
				margin-top:'.(($nz_h1_fixed_height - 30)/2).'px;
				background-color:'.$nz_h1_desk_fixed_separator_color.';
			}';
		}

		$dynamic_css .='.version2 .header-top {
			background-color: '.$nz_h2_header_top_back_color.';
		}';

		if(!empty($nz_h2_header_top_border_color)){
			$dynamic_css .='.version2 .header-top {
				border-bottom:1px solid '.$nz_h2_header_top_border_color.';
			}';
		}

		$dynamic_css .='.version2 .header-top .header-top-menu ul li a, .version2 .header-top .social-text {
		    color: '.$nz_h2_header_top_menu_color_reg.';
		    font-weight: '.$nz_h2_header_top_menu_font_weight.';
			font-size: '.$nz_h2_header_top_menu_font_size.';
			text-transform: '.$nz_h2_header_top_menu_text_transform.';
		}';

		$dynamic_css .='.version2 .header-top .header-top-menu ul li:hover > a {
		    color: '.$nz_h2_header_top_menu_color_hov.';
		}';

		$dynamic_css .='.version2 .header-top .header-top-menu > ul > li:not(:last-child):after {
			color: '.lifefitness_ninzio_hex_to_rgba($nz_h2_header_top_menu_color_reg,0.3).';
		}';

		$dynamic_css .='.version2 .header-top .top-button {
		    color: '.$nz_h2_top_button_text_color.';
		    background-color: '.$nz_h2_top_button_back_color.';
		}';

		$dynamic_css .='.version2 .header-top .top-button:hover {
		    background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h2_top_button_back_color,20).';
		}';

		$dynamic_css .='.version2 .header-top .header-top-menu ul li ul.submenu-languages,
		.version2 .desk-menu > ul > li ul.submenu-languages
		{width: '.$nz_h2_desk_ls_w .';}';

		$dynamic_css .='.version2.top-false {
			height:'.$nz_h2_desk_height.'px;
		}';

		$dynamic_css .='.version2.top-true {
			height:'.(40+$nz_h2_desk_height).'px;
		}';

		$dynamic_css .='.version2 .header-body {
		    background-color: '.$nz_h2_desk_back_color.';';
		    if(!empty($nz_h2_desk_border_color)){
				$dynamic_css .='border-bottom:1px solid '.$nz_h2_desk_border_color.';';
		    }
			$dynamic_css .='height:'.$nz_h2_desk_height.'px;';
		$dynamic_css .='}';

		$dynamic_css .='.version2 .logo,
		.version2 .logo-title,
		.version2.desk .logo-part {
			height: '.$nz_h2_desk_height.'px;
			line-height: '.$nz_h2_desk_height.'px;
		}';

		$dynamic_css .='.version2 .desk-menu .sub-menu {
			top: '.$nz_h2_desk_height.'px;
		}';

		$dynamic_css .='.version2 .search {
			top: '.($nz_h2_desk_height/2 + 20).'px;
		}';

		$dynamic_css .='.version2 .desk-cart-wrap {
			height:'.$nz_h2_desk_height.'px;
		}';

		$dynamic_css .='.version2 .search-toggle-wrap,
		.version2 .desk-cart-toggle,
		.version2 .site-sidebar-toggle,
		.version2 .header-social-links {
			margin-top: '.(($nz_h2_desk_height-40)/2).'px;
		}';

		$dynamic_css .='.version2 .site-sidebar-toggle {
			background-color: '.$nz_h2_desk_sidebar_toggle_color.';';
			if($nz_h2_desk_sidebar_toggle_border_color != "none"){
				$dynamic_css .='box-shadow:inset 0 0 0 2px '.$nz_h2_desk_sidebar_toggle_border_color;
			}
		$dynamic_css .='}';

		$dynamic_css .='.version2 .desk-cart-wrap .cart-info {
			background-color:'.$nz_h2_desk_cart_back_color.';
			color:'.$nz_h2_desk_cart_text_color.';
		}';

		$dynamic_css .='.version2 .woo-cart {
		    top: '.$nz_h2_desk_height.'px;
		}';

		$dynamic_css .='.version2 .desk-menu > ul > li {
			margin-left: '.$nz_h2_desk_menu_m.'px !important;
			height: '.$nz_h2_desk_height.'px;
			line-height: '.$nz_h2_desk_height.'px;
		}';

		$dynamic_css .='.version2:not(.active) .logo-title {
			color: '.$nz_h2_desk_menu_color_reg.';
		}';

		$dynamic_css .='.version2 .desk-menu > ul > li > a {
		    color: '.$nz_h2_desk_menu_color_reg.';
			text-transform: '.$nz_h2_desk_menu_text_transform.';
			font-weight: '.$nz_h2_desk_menu_font_weight.';
			font-size: '.$nz_h2_desk_menu_font_size.';
			font-family: '.$nz_h2_desk_menu_font_family.';
			margin-top: '.(($nz_h2_desk_height-30)/2).'px;
		}';

		$dynamic_css .='.version2 .desk-cart-toggle span {
		    color: '.$nz_h2_desk_menu_color_reg.';';
		$dynamic_css .='}';

		$dynamic_css .='.version2 .desk-menu > ul > li.menu-item-language > a > .txt {
			box-shadow: inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_menu_color_reg,0.5).';
		}';

		$dynamic_css .='.version2 .desk-menu > ul > li.menu-item-language:hover > a > .txt {
			box-shadow: inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_menu_color_reg,0.7).';
		}';

		$dynamic_css .='.version2 .desk-menu > ul > li:hover > a,
		.version2 .desk-menu > ul > li.one-page-active > a,
		.version2 .desk-menu > ul > li.current-menu-item > a,
		.version2 .desk-menu > ul > li.current-menu-parent > a,
		.version2 .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h2_desk_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.one-page-top.version2 .desk-menu > ul > li:hover > a,
		.one-page-top.version2 .desk-menu > ul > li.one-page-active > a {
			color: '.$nz_h2_desk_menu_color_hov.' !important;
		}';

		$dynamic_css .='.one-page-top.version2 .desk-menu > ul > li.current-menu-item > a,
		.one-page-top.version2 .desk-menu > ul > li.current-menu-parent > a,
		.one-page-top.version2 .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h2_desk_menu_color_hov.';
		}';

		$dynamic_css .='.version2 .desk-menu .sub-menu,
		.version2 .header-top .header-top-menu ul li ul,
		.version2 .woo-cart {
			background-color: '.$nz_h2_desk_submenu_back_color.';
		}';

		$dynamic_css .='.version2 .search {
			background-color: '.$nz_h2_desk_submenu_back_color.' !important;
		}';

		$dynamic_css .='.version2 .desk-menu .sub-menu .sub-menu {
			background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h2_desk_submenu_back_color,20).';
		}';

		$dynamic_css .='.version2 .desk-menu .sub-menu li > a {
		    color: '.$nz_h2_desk_submenu_color_reg.';
			text-transform: '.$nz_h2_desk_submenu_text_transform.';
			font-weight: '.$nz_h2_desk_submenu_font_weight.';
			font-size: '.$nz_h2_desk_submenu_font_size.';
			line-height: '.$nz_h2_desk_submenu_line_height.';
			font-family: '.$nz_h2_desk_submenu_font_family.';
		}';

		$dynamic_css .='.version2 .header-top .header-top-menu ul li ul li a {
		    color: '.$nz_h2_desk_submenu_color_reg.';
		}';

		$dynamic_css .='.version2 .desk-menu .sub-menu li:hover > a,
		.version2 .header-top .header-top-menu ul li ul li:hover > a {
		    color: '.$nz_h2_desk_submenu_color_hov.';
		}';
		
		$dynamic_css .='.version2 .desk-menu [data-mm="true"] > .sub-menu > li > a {
			text-transform: '.$nz_h2_desk_megamenu_text_transform.';
			font-weight: '.$nz_h2_desk_megamenu_font_weight.';
			font-size: '.$nz_h2_desk_megamenu_font_size.';
			color: '.$nz_h2_desk_megamenu_color.' !important;
			font-family: '.$nz_h2_desk_menu_font_family.';
		}';

		$dynamic_css .='.version2 .desk-menu > ul > [data-mm="true"] > .sub-menu > li:not(:last-child):after {
			background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_megamenu_color,0.1).' !important;
		}';

		if (isset($nz_h2_desk_megamenu_top_border) && !empty($nz_h2_desk_megamenu_top_border)) {
			
			$dynamic_css .='.version2 .desk-menu [data-mm="true"] > .sub-menu > li > a {
				padding: 0px 0 30px 0;
				position:relative;
			}';

			$dynamic_css .='.version2 .desk-menu [data-mm="true"] > .sub-menu > li > a:after {
				background-color: '.$nz_h2_desk_megamenu_top_border.';
				display:block;
				content: "";
			    width: 50px;
			    height: 2px;
			    display: block;
			    bottom: 22px;
			    left:0px;
			    position:absolute;
			}';

			$dynamic_css .='.version2 .yawp_wim_title {
				position:relative;
				padding: 0px 0 43px 0 !important;
				margin-bottom:0;
				line-height: '.$nz_h2_desk_submenu_line_height.';
			}';

			$dynamic_css .='.version2 .yawp_wim_title:after {
				background-color: '.$nz_h2_desk_megamenu_top_border.';
				display:block;
				content: "";
			    width: 30px;
			    height: 2px;
			    display: block;
			    bottom: 30px;
			    left:0px;
			    position:absolute;
			}';
		}


		/*WIDGETS ------*/

			$dynamic_css .='.version2 .menu-item-type-yawp_wim,
			.version2 .menu-item-type-yawp_wim a:not(.button) {
				color: '.$nz_h2_desk_submenu_color_reg.';
				text-transform: '.$nz_h2_desk_submenu_text_transform.';
				font-weight: '.$nz_h2_desk_submenu_font_weight.';
				font-size: '.$nz_h2_desk_submenu_font_size.';
				line-height: '.$nz_h2_desk_submenu_line_height.';
				font-family: '.$nz_h2_desk_submenu_font_family.';
			}';

			$dynamic_css .='.version2 .widget_rss a, 
			.version2 .widget_nz_recent_entries a, 
			.version2 .widget_recent_comments a, 
			.version2 .widget_recent_entries a,
			.version2 .widget_nz_recent_entries .post .post-date,
			.version2 .nz-schedule li,
			.version2 .widget_twitter .tweet-time,
			.version2 .widget_shopping_cart .cart_list > li > a {
				color: '.$nz_h2_desk_submenu_color_reg.' !important;
			}';

			$dynamic_css .='.version2 .widget_rss a:hover, 
			.version2 .widget_nz_recent_entries a:hover, 
			.version2 .widget_recent_comments a:hover, 
			.version2 .widget_recent_entries a:hover,
			.version2 .widget_shopping_cart .cart_list > li > a:hover {
				color: '.$nz_h2_desk_submenu_color_hov.' !important;
			}';

			$dynamic_css .='.version2 .widget_twitter ul li:before,
			.version2 .widget_nz_recent_entries .post-body:before,
			.version2 .widget_recent_comments ul li:before {
				color: '.$nz_h2_megamenu_buttons_back_color.' !important;
			}';

			$dynamic_css .='.version2 .nz-schedule ul li {
				border-bottom: 1px dashed '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg, 0.2).';
			}';

			$dynamic_css .='.version2 .widget_shopping_cart .cart_list > li,
			.version2 .widget_products .product_list_widget > li, 
			.version2 .widget_recently_viewed_products .product_list_widget > li,
			.version2 .widget_recent_reviews .product_list_widget > li, 
			.version2 .widget_top_rated_products .product_list_widget > li {
				border-bottom: 1px dashed '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg, 0.2).';
			}';

			$dynamic_css .='.version2 .widget_price_filter .price_slider_wrapper .ui-widget-content {
				background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg, 0.2).' !important;
			}';

			$dynamic_css .='.version2 .widget_calendar td#prev, 
			.version2 .widget_calendar td#next,
			.version2 .widget_calendar td,
			.version2 .widget_calendar caption,
			.version2 .widget_calendar th:first-child,
			.version2 .widget_calendar th:last-child {
				border-color: '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg, 0.2).';
			}';


			$dynamic_css .='.version2 .widget_tag_cloud .tagcloud a:hover,
			.version2 .widget_product_tag_cloud .tagcloud a:hover, 
			.version2 .post-tags a:hover, 
			.version2 .projects-tags a:hover {
				color: '.$nz_h2_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version2 .widget_calendar td#today {
				background-color: '.$nz_h2_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version2 .widget_tag_cloud .tagcloud a:hover,
			.version2 .widget_product_tag_cloud .tagcloud a:hover, 
			.version2 .post-tags a:hover, 
			.version2 .projects-tags a:hover,
			.version2 .widget_tag_cloud .tagcloud a:hover,
			.version2 .widget_product_tag_cloud .tagcloud a:hover, 
			.version2 .post-tags a:hover, 
			.version2 .projects-tags a:hover {
				box-shadow:inset 0 0 0 2px '.$nz_h2_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version2 .widget_nav_menu ul li:hover a {
				color: '.$nz_h2_desk_submenu_color_reg.' !important;
			}';

			$dynamic_css .='.version2 .widget_product_categories ul li a:hover,
			.version2 .widget_shopping_cart p.buttons > a:hover,
			.version2 .widget_recent_entries a:hover,
			.version2 .widget_categories ul li a:hover,
			.version2 .widget_pages ul li a:hover,
			.version2 .widget_archive ul li a:hover,
			.version2 .widget_meta ul li a:hover,
			.version2 .widget_nz_recent_entries .post-title:hover,
			.version2 .widget_price_filter .price_slider_amount .button:hover,
			.version2 .widget_shopping_cart .cart_list > li > a:hover,
			.version2 .widget_products .product_list_widget > li > a:hover,
			.version2 .widget_recently_viewed_products .product_list_widget > li > a:hover,
			.version2 .widget_recent_reviews .product_list_widget > li > a:hover,
			.version2 .widget_top_rated_products .product_list_widget > li > a:hover,
			.version2 .widget_recent_entries a:hover, 
			.version2 .widget_nz_recent_entries .post-title:hover,
			.version2 .widget_product_categories ul li a:hover, 
			.version2 .widget_nav_menu ul li a:hover,
			.version2 .widget_recent_comments a:hover {
				color: '.$nz_h2_desk_submenu_color_hov.' !important;
			}';

			$dynamic_css .='.version2 .menu-item-type-yawp_wim a:hover {
				color: '.$nz_h2_desk_submenu_color_hov.';
			}';

			$dynamic_css .='.version2 textarea, 
			.version2 select, 
			.version2 input[type="date"], 
			.version2 input[type="datetime"], 
			.version2 input[type="datetime-local"], 
			.version2 input[type="email"], 
			.version2 input[type="month"], 
			.version2 input[type="number"], 
			.version2 input[type="password"], 
			.version2 input[type="search"], 
			.version2 input[type="tel"], 
			.version2 input[type="text"], 
			.version2 input[type="time"], 
			.version2 input[type="url"], 
			.version2 input[type="week"] {
				box-shadow: inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg,0.25).';
				color: '.$nz_h2_desk_submenu_color_reg.';
			}';

			$dynamic_css .='.version2 textarea:hover, 
			.version2 select:hover, 
			.version2 input[type="date"]:hover, 
			.version2 input[type="datetime"]:hover, 
			.version2 input[type="datetime-local"]:hover, 
			.version2 input[type="email"]:hover, 
			.version2 input[type="month"]:hover, 
			.version2 input[type="number"]:hover, 
			.version2 input[type="password"]:hover, 
			.version2 input[type="search"]:hover, 
			.version2 input[type="tel"]:hover, 
			.version2 input[type="text"]:hover, 
			.version2 input[type="time"]:hover, 
			.version2 input[type="url"]:hover, 
			.version2 input[type="week"]:hover {
				color: '.$nz_h2_desk_submenu_color_hov.' !important;
			}';

			$dynamic_css .='.version2 .desk-menu .button,
			.version2 .desk-menu button,
			.version2 .desk-menu input[type="reset"],
			.version2 .desk-menu input[type="submit"],
			.version2 .desk-menu input[type="button"],
			.version2 .widget_recent_comments ul li:before {
				background-color:'.$nz_h2_megamenu_buttons_back_color.' !important;
				color: '.$nz_h2_megamenu_buttons_text_color.' !important;
			}';

			$dynamic_css .='.version2 .desk-menu .button:hover,
			.version2 .desk-menu button:hover,
			.version2 .desk-menu input[type="reset"]:hover,
			.version2 .desk-menu input[type="submit"]:hover,
			.version2 .desk-menu input[type="button"]:hover {
				background-color:'.lifefitness_ninzio_hex_to_rgb_shade($nz_h2_megamenu_buttons_back_color,20).' !important;
			}';

			$dynamic_css .='.version2 ::-webkit-input-placeholder {color: '.$nz_h2_desk_submenu_color_reg.';}';
			$dynamic_css .='.version2 :-moz-placeholder           {color: '.$nz_h2_desk_submenu_color_reg.';}';
			$dynamic_css .='.version2 ::-moz-placeholder          {color: '.$nz_h2_desk_submenu_color_reg.';}';
			$dynamic_css .='.version2 :-ms-input-placeholder      {color: '.$nz_h2_desk_submenu_color_reg.';}';

			$dynamic_css .='.version2 .widget_price_filter .ui-slider .ui-slider-handle {
				border-color: '.$nz_h2_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version2 .widget_shopping_cart p.buttons > a:hover, 
			.version2 .widget_shopping_cart p.buttons > a:hover, 
			.version2 .widget_price_filter .price_slider_amount .button:hover {
				box-shadow:inset 0 0 0 2px '.$nz_h2_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version2 .widget_price_filter .ui-slider .ui-slider-range {
				background-color: '.$nz_h2_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version2 .widget_shopping_cart p.buttons > a:hover,
			.version2 .widget_price_filter .price_slider_amount .button:hover {
				color: '.$nz_h2_desk_menu_effect_color.' !important;
			}';


			$dynamic_css .='.version2 .yawp_wim_title {
				text-transform: '.$nz_h2_desk_megamenu_text_transform.';
				font-weight: '.$nz_h2_desk_megamenu_font_weight.';
				font-size: '.$nz_h2_desk_megamenu_font_size.';
				color: '.$nz_h2_desk_megamenu_color.' !important;
				font-family: '.$nz_h2_desk_menu_font_family.';
			}';


			$dynamic_css .='.version2 .widget_tag_cloud .tagcloud a,
			.version2 .post-tags a,
			.version2 .widget_product_tag_cloud .tagcloud a,
			.version2 .projects-tags a {
				font-family: '.$nz_h2_desk_menu_font_family.';
				color: '.$nz_h2_desk_submenu_color_reg.';
				box-shadow:inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg, 0.3).' !important;
			}';

			$dynamic_css .='.version2 .widget_shopping_cart {
			    color: '.$nz_h2_desk_submenu_color_reg.';
			}';

			$dynamic_css .='.version2 .widget_shopping_cart .cart_list li {
				border-bottom: 1px solid '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg,0.2).';
			}';

			$dynamic_css .='.version2 .widget_shopping_cart .cart_list li .remove {
				background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h2_desk_submenu_back_color,10).' !important;
			}';

			$dynamic_css .='.version2 .widget_shopping_cart .cart_list li .remove:hover {
				background-color: '.$nz_h2_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version2 .widget_shopping_cart .cart_list li img {
			    background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg,0.1).';
			}';

			$dynamic_css .='.version2 .widget_shopping_cart .cart_list li:hover img {
			    background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg,0.2).';
			}';

			$dynamic_css .='.version2 .widget_shopping_cart p.buttons > a, 
			.version2 .widget_price_filter .price_slider_amount .button {
				color: '.$nz_h2_desk_submenu_color_reg.' !important;
				box-shadow:inset 0 0 0 2px '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg, 0.3).' !important;
			}';

			$dynamic_css .='.version2 .widget_shopping_cart p.buttons > a:hover, 
			.version2 .widget_price_filter .price_slider_amount .button:hover {
				color: '.$nz_h2_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version2 .star-rating:before {
				color: '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg, 0.4).' !important;
			}';

			$dynamic_css .='.version2 .yawp_wim_title a {
				text-transform: '.$nz_h2_desk_megamenu_text_transform.' !important;
				font-weight: '.$nz_h2_desk_megamenu_font_weight.' !important;
				font-size: '.$nz_h2_desk_megamenu_font_size.' !important;
				color: '.$nz_h2_desk_megamenu_color.' !important;
				font-family: '.$nz_h2_desk_menu_font_family.' !important;
			}';

			$dynamic_css .='.version2 .widget_categories ul li,
			.version2 .widget_pages ul li,
			.version2 .widget_archive ul li,
			.version2 .widget_meta ul li {
				border-bottom: 1px dashed '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg,0.25).';
			}';

			$dynamic_css .='.version2 .widget_nav_menu li a:before,
			.version2 .widget_product_categories li a:before,
			.version2 .widget_categories ul li a:before,
			.version2 .widget_pages ul li a:before,
			.version2 .widget_archive ul li a:before,
			.version2 .widget_meta ul li a:before {
				box-shadow: inset 0 0 0 1px '.$nz_h2_megamenu_buttons_back_color.' !important;
				color: '.$nz_h2_megamenu_buttons_back_color.' !important;
			}';

		/*------ WIDGETS*/

		$dynamic_css .='.version2 .desk-menu .sub-menu .label {font-family: '.$nz_h2_desk_menu_font_family.';}';

		$dynamic_css .='.version2 .search-true.cart-false .search-toggle:after,
		.version2 .cart-true .desk-cart-wrap:after {
			background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_menu_color_reg,0.2).';
		}';

		$dynamic_css .='.version2 .search input[type="text"],
		.version2 .woo-cart {
		    color: '.$nz_h2_desk_submenu_color_reg.';
		}';

		$dynamic_css .='.version2 .woo-cart .widget_shopping_cart .cart_list li {
			border-bottom: 1px solid '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg,0.2).';
		}';

		$dynamic_css .='.version2 .woo-cart .widget_shopping_cart .cart_list li .remove {
			background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h2_desk_submenu_back_color,20).';
		}';

		$dynamic_css .='.version2 .woo-cart .widget_shopping_cart .cart_list li .remove:hover {
			background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h2_desk_submenu_back_color,30).' !important;
		}';

		$dynamic_css .='.version2 .woo-cart .widget_shopping_cart .cart_list li img {
		    background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg,0.1).';
		}';

		$dynamic_css .='.version2 .woo-cart .widget_shopping_cart .cart_list li:hover img {
		    background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_submenu_color_reg,0.2).';
		}';

		/*EFFECTS*/
		$dynamic_css .='.version2.effect-underline .desk-menu > ul > li > a:after,
		.version2.effect-overline .desk-menu > ul > li > a:after,
		.version2.effect-fill .desk-menu > ul > li:hover,
		.version2.effect-fill .desk-menu > ul > li.one-page-active > a,
		.version2.effect-fill .desk-menu > ul > li.current-menu-item,
		.version2.effect-fill .desk-menu > ul > li.current-menu-parent,
		.version2.effect-fill .desk-menu > ul > li.current-menu-ancestor {
			background-color: '.$nz_h2_desk_menu_effect_color.';
		}';

		$dynamic_css .='.version2.effect-dottes .desk-menu > ul > li > a .dottes,
		.version2.effect-dottes .desk-menu > ul > li > a .dottes:after,
		.version2.effect-dottes .desk-menu > ul > li > a .dottes:before {
			background-color: '.$nz_h2_desk_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version2.effect-fill .desk-menu > ul > li:hover,
		.one-page-top.version2.effect-fill .desk-menu > ul > li.one-page-active {
			background-color: '.$nz_h2_desk_menu_effect_color.' !important
		}';

		$dynamic_css .='.version2.effect-outline .desk-menu > ul > li:hover > a,
		.version2.effect-outline .desk-menu > ul > li.one-page-active > a,
		.version2.effect-outline .desk-menu > ul > li.current-menu-item > a,
		.version2.effect-outline .desk-menu > ul > li.current-menu-parent > a,
		.version2.effect-outline .desk-menu > ul > li.current-menu-ancestor > a {
			box-shadow: inset 0 0 0 2px '.$nz_h2_desk_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version2.effect-outline .desk-menu > ul > li:hover > a,
		.one-page-top.version2.effect-outline .desk-menu > ul > li.one-page-active > a {
			box-shadow: inset 0 0 0 2px '.$nz_h2_desk_menu_effect_color.' !important;
		}';

		$dynamic_css .='.version2.effect-overline .desk-menu > ul > li > a:after {
			top:-'.(($nz_h2_desk_height-30)/2).'px;
		}';

		/*FIXED*/
		$dynamic_css .='.version2.fixed-true.active .header-body,
		.version2.fixed-true.active {
			height:'.$nz_h2_fixed_height.'px;
		}';

		$dynamic_css .='.version2.fixed-true.active.top-true {
			height:'.($nz_h2_fixed_height + 40).'px;
		}';

		$dynamic_css .='.version2.fixed-true.active .logo,
		.version2.fixed-true.active .logo-title {
			height:'.$nz_h2_fixed_height.'px;
			line-height: '.$nz_h2_fixed_height.'px;
		}';

		$dynamic_css .='.version2.fixed-true.active .desk-menu .sub-menu {
			top: '.$nz_h2_fixed_height.'px;
		}';

		$dynamic_css .='.version2.fixed-true.active .search {
			top: '.($nz_h2_fixed_height/2 + 20).'px;
		}';

		$dynamic_css .='.version2.fixed-true.active .desk-cart-wrap {
			height:'.$nz_h2_fixed_height.'px;
		}';

		$dynamic_css .='.version2.fixed-true.active .search-toggle-wrap,
		.version2.fixed-true.active .desk-cart-toggle,
		.version2.fixed-true.active .site-sidebar-toggle {
			margin-top: '.(($nz_h2_fixed_height-40)/2).'px;
		}';

		$dynamic_css .='.version2.fixed-true.active .desk-cart-wrap .cart-info {
			background-color:'.$nz_h2_desk_fixed_cart_back_color.';
			color:'.$nz_h2_desk_fixed_cart_text_color.';
		}';

		$dynamic_css .='.version2.fixed-true.active .woo-cart {
		    top: '.$nz_h2_fixed_height.'px;
		}';

		$dynamic_css .='.version2.fixed-true.active .desk-menu > ul > li {
			height: '.$nz_h2_fixed_height.'px;
			line-height: '.$nz_h2_fixed_height.'px;
		}';

		$dynamic_css .='.version2.fixed-true.active .desk-menu > ul > li > a {
			margin-top: '.(($nz_h2_fixed_height-30)/2).'px;
		}';

		$dynamic_css .='.version2.fixed-true.active .logo-title {
			color: '.$nz_h2_desk_fixed_menu_color_reg.';
		}';

		$dynamic_css .='.version2.fixed-true.active .header-body {
		    background-color: '.$nz_h2_desk_fixed_back_color.';
		}';

		$dynamic_css .='.version2.fixed-true.active .desk-menu > ul > li > a {
		    color: '.$nz_h2_desk_fixed_menu_color_reg.';
		}';

		$dynamic_css .='.version2.fixed-true.active .desk-cart-toggle span {
		    color: '.$nz_h2_desk_fixed_menu_color_reg.';
		}';

		$dynamic_css .='.version2.fixed-true.active .desk-menu > ul > li:hover > a,
		.version2.fixed-true.active .desk-menu > ul > li.one-page-active > a,
		.version2.fixed-true.active .desk-menu > ul > li.current-menu-item > a,
		.version2.fixed-true.active .desk-menu > ul > li.current-menu-parent > a,
		.version2.fixed-true.active .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h2_desk_fixed_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.version2.fixed-true.active .desk-menu > ul > li.current-menu-item > a,
		.one-page-top.version2.fixed-true.active .desk-menu > ul > li.current-menu-parent > a,
		.one-page-top.version2.fixed-true.active .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h2_desk_fixed_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.version2.fixed-true.active .desk-menu > ul > li:hover > a,
		.one-page-top.version2.fixed-true.active .desk-menu > ul > li.one-page-active > a {
		    color: '.$nz_h2_desk_fixed_menu_color_hov.' !important;
		}';

		$dynamic_css .='.version2.fixed-true.active .site-sidebar-toggle {
			background-color: '.$nz_h2_desk_fixed_sidebar_toggle_color.';
			box-shadow:inset 0 0 0 2px '.$nz_h2_desk_fixed_sidebar_toggle_border_color.';
		}';

		$dynamic_css .='.version2.fixed-true.active .search-true.cart-false .search-toggle:after,
		.version2.fixed-true.active .cart-true .desk-cart-wrap:after {
			background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h2_desk_fixed_menu_color_reg,0.2).';
		}';

		$dynamic_css .='.version2.fixed-true.active.effect-outline .desk-menu > ul > li:hover > a,
		.version2.fixed-true.active.effect-outline .desk-menu > ul > li.one-page-active > a,
		.version2.fixed-true.active.effect-outline .desk-menu > ul > li.current-menu-item > a,
		.version2.fixed-true.active.effect-outline .desk-menu > ul > li.current-menu-parent > a,
		.version2.fixed-true.active.effect-outline .desk-menu > ul > li.current-menu-ancestor > a {
			box-shadow: inset 0 0 0 2px '.$nz_h2_desk_fixed_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version2.fixed-true.active.effect-outline .desk-menu > ul > li:hover > a,
		.one-page-top.version2.fixed-true.active.effect-outline .desk-menu > ul > li.one-page-active > a {
			box-shadow: inset 0 0 0 2px '.$nz_h2_desk_fixed_menu_effect_color.' !important;
		}';

		$dynamic_css .='.version2.fixed-true.active.effect-underline .desk-menu > ul > li > a:after,
		.version2.fixed-true.active.effect-overline .desk-menu > ul > li > a:after,
		.version2.fixed-true.active.effect-fill .desk-menu > ul > li:hover,
		.version2.fixed-true.active.effect-fill .desk-menu > ul > li.one-page-active,
		.version2.fixed-true.active.effect-fill .desk-menu > ul > li.current-menu-item,
		.version2.fixed-true.active.effect-fill .desk-menu > ul > li.current-menu-parent,
		.version2.fixed-true.active.effect-fill .desk-menu > ul > li.current-menu-ancestor {
			background-color: '.$nz_h2_desk_fixed_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version2.fixed-true.active.effect-fill .desk-menu > ul > li:hover,
		.one-page-top.version2.fixed-true.active.effect-fill .desk-menu > ul > li.one-page-active {
			background-color: '.$nz_h2_desk_fixed_menu_effect_color.' !important;
		}';

		$dynamic_css .='.version2.fixed-true.active.effect-overline .desk-menu > ul > li > a:after {
			top:-'.(($nz_h2_fixed_height-30)/2).'px;
		}';

		$dynamic_css .='.version3 .header-body {
		    background-color: '.$nz_h3_desk_back_color.';';
		    if(!empty($nz_h3_desk_border_color)){
				$dynamic_css .='border-bottom:1px solid '.$nz_h3_desk_border_color.';';
		    }
			$dynamic_css .='height:'.$nz_h3_desk_height.'px;';
		$dynamic_css .='}';

		$dynamic_css .='.version3 .logo,
		.version3 .logo-title {
			height: '.$nz_h3_desk_height.'px;
			line-height: '.$nz_h3_desk_height.'px;
		}';

		$dynamic_css .='.version3 .desk-menu .sub-menu {
			top: '.$nz_h3_desk_height.'px;
		}';

		$dynamic_css .='.version3 .search {
			top: '.($nz_h3_desk_height/2 + 20).'px;
		}';

		$dynamic_css .='.version3 .desk-cart-wrap {
			height:'.$nz_h3_desk_height.'px;
		}';

		$dynamic_css .='.version3 .search-toggle-wrap,
		.version3 .desk-cart-toggle,
		.version3 .site-sidebar-toggle,
		.version3 .header-social-links {
			margin-top: '.(($nz_h3_desk_height-40)/2).'px;
		}';

		$dynamic_css .='.version3 .site-sidebar-toggle {
			background-color: '.$nz_h3_desk_sidebar_toggle_color.';
			box-shadow:inset 0 0 0 2px '.$nz_h3_desk_sidebar_toggle_border_color.';
		}';

		$dynamic_css .='.version3 .desk-cart-wrap .cart-info {
			background-color:'.$nz_h3_desk_cart_back_color.';
			color:'.$nz_h3_desk_cart_text_color.';
		}';

		$dynamic_css .='.version3 .woo-cart {
		    top: '.$nz_h3_desk_height.'px;
		}';

		$dynamic_css .='.version3 .desk-menu > ul > li {
			margin-left: '.$nz_h3_desk_menu_m.'px !important;
			height: '.$nz_h3_desk_height.'px;
			line-height: '.$nz_h3_desk_height.'px;
		}';

		$dynamic_css .='.version3:not(.active) .logo-title {
			color: '.$nz_h3_desk_menu_color_reg.';
		}';

		$dynamic_css .='.version3 .desk-menu > ul > li > a {
		    color: '.$nz_h3_desk_menu_color_reg.';
			text-transform: '.$nz_h3_desk_menu_text_transform.';
			font-weight: '.$nz_h3_desk_menu_font_weight.';
			font-size: '.$nz_h3_desk_menu_font_size.';
			font-family: '.$nz_h3_desk_menu_font_family.';
			margin-top: '.(($nz_h3_desk_height-30)/2).'px;
		}';

		$dynamic_css .='.version3 .desk-cart-toggle span {
		    color: '.$nz_h3_desk_menu_color_reg.';';
		$dynamic_css .='}';

		$dynamic_css .='.version3 .desk-menu > ul > li.menu-item-language > a > .txt {
			box-shadow: inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_menu_color_reg,0.5).';
		}';

		$dynamic_css .='.version3 .desk-menu > ul > li.menu-item-language:hover > a > .txt {
			box-shadow: inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_menu_color_reg,0.7).';
		}';

		$dynamic_css .='.version3 .desk-menu > ul > li:hover > a,
		.version3 .desk-menu > ul > li.one-page-active > a,
		.version3 .desk-menu > ul > li.current-menu-item > a,
		.version3 .desk-menu > ul > li.current-menu-parent > a,
		.version3 .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h3_desk_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.version3 .desk-menu > ul > li:hover > a,
		.one-page-top.version3 .desk-menu > ul > li.one-page-active > a {
			color: '.$nz_h3_desk_menu_color_hov.' !important;
		}';

		$dynamic_css .='.one-page-top.version3 .desk-menu > ul > li.current-menu-item > a,
		.one-page-top.version3 .desk-menu > ul > li.current-menu-parent > a,
		.one-page-top.version3 .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h3_desk_menu_color_hov.';
		}';

		$dynamic_css .='.version3 .desk-menu .sub-menu,
		.version3 .header-top .header-top-menu ul li ul,
		.version3 .woo-cart {
			background-color: '.$nz_h3_desk_submenu_back_color.';
		}';

		$dynamic_css .='.version3 .search {
			background-color: '.$nz_h3_desk_submenu_back_color.' !important;
		}';

		$dynamic_css .='.version3 .desk-menu .sub-menu .sub-menu {
			background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h3_desk_submenu_back_color,20).';
		}';

		$dynamic_css .='.version3 .desk-menu .sub-menu li > a {
		    color: '.$nz_h3_desk_submenu_color_reg.';
			text-transform: '.$nz_h3_desk_submenu_text_transform.';
			font-weight: '.$nz_h3_desk_submenu_font_weight.';
			font-size: '.$nz_h3_desk_submenu_font_size.';
			line-height: '.$nz_h3_desk_submenu_line_height.';
			font-family: '.$nz_h3_desk_submenu_font_family.';
		}';

		$dynamic_css .='.version3 .desk-menu .sub-menu li:hover > a {
		    color: '.$nz_h3_desk_submenu_color_hov.';
		}';
		
		$dynamic_css .='.version3 .desk-menu [data-mm="true"] > .sub-menu > li > a {
			text-transform: '.$nz_h3_desk_megamenu_text_transform.';
			font-weight: '.$nz_h3_desk_megamenu_font_weight.';
			font-size: '.$nz_h3_desk_megamenu_font_size.';
			color: '.$nz_h3_desk_megamenu_color.' !important;
			font-family: '.$nz_h3_desk_menu_font_family.';
		}';

		$dynamic_css .='.version3 .desk-menu > ul > [data-mm="true"] > .sub-menu > li:not(:last-child):after {
			background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_megamenu_color,0.1).' !important;
		}';

		if (isset($nz_h3_desk_megamenu_top_border) && !empty($nz_h3_desk_megamenu_top_border)) {
			
			$dynamic_css .='.version3 .desk-menu [data-mm="true"] > .sub-menu > li > a {
				padding: 0px 0 30px 0;
				position:relative;
			}';

			$dynamic_css .='.version3 .desk-menu [data-mm="true"] > .sub-menu > li > a:after {
				background-color: '.$nz_h3_desk_megamenu_top_border.';
				display:block;
				content: "";
			    width: 50px;
			    height: 2px;
			    display: block;
			    bottom: 23px;
			    left:0px;
			    position:absolute;
			}';

			$dynamic_css .='.version3 .yawp_wim_title {
				position:relative;
				padding: 0px 0 43px 0 !important;
				margin-bottom:0;
				line-height: '.$nz_h3_desk_submenu_line_height.';
			}';

			$dynamic_css .='.version3 .yawp_wim_title:after {
				background-color: '.$nz_h3_desk_megamenu_top_border.';
				display:block;
				content: "";
			    width: 30px;
			    height: 2px;
			    display: block;
			    bottom: 30px;
			    left:0px;
			    position:absolute;
			}';
		}

		/*WIDGETS ------*/

			$dynamic_css .='.version3 .menu-item-type-yawp_wim,
			.version3 .menu-item-type-yawp_wim a:not(.button) {
				color: '.$nz_h3_desk_submenu_color_reg.';
				text-transform: '.$nz_h3_desk_submenu_text_transform.';
				font-weight: '.$nz_h3_desk_submenu_font_weight.';
				font-size: '.$nz_h3_desk_submenu_font_size.';
				line-height: '.$nz_h3_desk_submenu_line_height.';
				font-family: '.$nz_h3_desk_submenu_font_family.';
			}';

			$dynamic_css .='.version3 .widget_rss a, 
			.version3 .widget_nz_recent_entries a, 
			.version3 .widget_recent_comments a, 
			.version3 .widget_recent_entries a,
			.version3 .widget_nz_recent_entries .post .post-date,
			.version3 .nz-schedule li,
			.version3 .widget_twitter .tweet-time,
			.version3 .widget_shopping_cart .cart_list > li > a {
				color: '.$nz_h3_desk_submenu_color_reg.' !important;
			}';

			$dynamic_css .='.version3 .widget_rss a:hover, 
			.version3 .widget_nz_recent_entries a:hover, 
			.version3 .widget_recent_comments a:hover, 
			.version3 .widget_recent_entries a:hover,
			.version3 .widget_shopping_cart .cart_list > li > a:hover {
				color: '.$nz_h3_desk_submenu_color_hov.' !important;
			}';

			$dynamic_css .='.version3 .widget_twitter ul li:before,
			.version3 .widget_nz_recent_entries .post-body:before,
			.version3 .widget_recent_comments ul li:before {
				color: '.$nz_h3_megamenu_buttons_back_color.' !important;
			}';

			$dynamic_css .='.version3 .nz-schedule ul li {
				border-bottom: 1px dashed '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg, 0.2).';
			}';

			$dynamic_css .='.version3 .widget_shopping_cart .cart_list > li,
			.version3 .widget_products .product_list_widget > li, 
			.version3 .widget_recently_viewed_products .product_list_widget > li,
			.version3 .widget_recent_reviews .product_list_widget > li, 
			.version3 .widget_top_rated_products .product_list_widget > li {
				border-bottom: 1px dashed '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg, 0.2).';
			}';

			$dynamic_css .='.version3 .widget_price_filter .price_slider_wrapper .ui-widget-content {
				background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg, 0.2).' !important;
			}';

			$dynamic_css .='.version3 .widget_calendar td#prev, 
			.version3 .widget_calendar td#next,
			.version3 .widget_calendar td,
			.version3 .widget_calendar caption,
			.version3 .widget_calendar th:first-child,
			.version3 .widget_calendar th:last-child {
				border-color: '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg, 0.2).';
			}';


			$dynamic_css .='.version3 .widget_tag_cloud .tagcloud a:hover,
			.version3 .widget_product_tag_cloud .tagcloud a:hover, 
			.version3 .post-tags a:hover, 
			.version3 .projects-tags a:hover {
				color: '.$nz_h3_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version3 .widget_calendar td#today {
				background-color: '.$nz_h3_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version3 .widget_tag_cloud .tagcloud a:hover,
			.version3 .widget_product_tag_cloud .tagcloud a:hover, 
			.version3 .post-tags a:hover, 
			.version3 .projects-tags a:hover,
			.version3 .widget_tag_cloud .tagcloud a:hover,
			.version3 .widget_product_tag_cloud .tagcloud a:hover, 
			.version3 .post-tags a:hover, 
			.version3 .projects-tags a:hover {
				box-shadow:inset 0 0 0 2px '.$nz_h3_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version3 .widget_nav_menu ul li:hover a {
				color: '.$nz_h3_desk_submenu_color_reg.' !important;
			}';

			$dynamic_css .='.version3 .widget_product_categories ul li a:hover,
			.version3 .widget_shopping_cart p.buttons > a:hover,
			.version3 .widget_recent_entries a:hover,
			.version3 .widget_categories ul li a:hover,
			.version3 .widget_pages ul li a:hover,
			.version3 .widget_archive ul li a:hover,
			.version3 .widget_meta ul li a:hover,
			.version3 .widget_nz_recent_entries .post-title:hover,
			.version3 .widget_price_filter .price_slider_amount .button:hover,
			.version3 .widget_shopping_cart .cart_list > li > a:hover,
			.version3 .widget_products .product_list_widget > li > a:hover,
			.version3 .widget_recently_viewed_products .product_list_widget > li > a:hover,
			.version3 .widget_recent_reviews .product_list_widget > li > a:hover,
			.version3 .widget_top_rated_products .product_list_widget > li > a:hover,
			.version3 .widget_recent_entries a:hover, 
			.version3 .widget_nz_recent_entries .post-title:hover,
			.version3 .widget_product_categories ul li a:hover, 
			.version3 .widget_nav_menu ul li a:hover,
			.version3 .widget_recent_comments a:hover {
				color: '.$nz_h3_desk_submenu_color_hov.' !important;
			}';

			$dynamic_css .='.version3 .menu-item-type-yawp_wim a:hover {
				color: '.$nz_h3_desk_submenu_color_hov.';
			}';

			$dynamic_css .='.version3 textarea, 
			.version3 select, 
			.version3 input[type="date"], 
			.version3 input[type="datetime"], 
			.version3 input[type="datetime-local"], 
			.version3 input[type="email"], 
			.version3 input[type="month"], 
			.version3 input[type="number"], 
			.version3 input[type="password"], 
			.version3 input[type="search"], 
			.version3 input[type="tel"], 
			.version3 input[type="text"], 
			.version3 input[type="time"], 
			.version3 input[type="url"], 
			.version3 input[type="week"] {
				box-shadow: inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg,0.25).';
				color: '.$nz_h3_desk_submenu_color_reg.';
			}';

			$dynamic_css .='.version3 textarea:hover, 
			.version3 select:hover, 
			.version3 input[type="date"]:hover, 
			.version3 input[type="datetime"]:hover, 
			.version3 input[type="datetime-local"]:hover, 
			.version3 input[type="email"]:hover, 
			.version3 input[type="month"]:hover, 
			.version3 input[type="number"]:hover, 
			.version3 input[type="password"]:hover, 
			.version3 input[type="search"]:hover, 
			.version3 input[type="tel"]:hover, 
			.version3 input[type="text"]:hover, 
			.version3 input[type="time"]:hover, 
			.version3 input[type="url"]:hover, 
			.version3 input[type="week"]:hover {
				color: '.$nz_h3_desk_submenu_color_hov.' !important;
			}';

			$dynamic_css .='.version3 .desk-menu .button,
			.version3 .desk-menu button,
			.version3 .desk-menu input[type="reset"],
			.version3 .desk-menu input[type="submit"],
			.version3 .desk-menu input[type="button"],
			.version3 .widget_recent_comments ul li:before {
				background-color:'.$nz_h3_megamenu_buttons_back_color.' !important;
				color: '.$nz_h3_megamenu_buttons_text_color.' !important;
			}';

			$dynamic_css .='.version3 .desk-menu .button:hover,
			.version3 .desk-menu button:hover,
			.version3 .desk-menu input[type="reset"]:hover,
			.version3 .desk-menu input[type="submit"]:hover,
			.version3 .desk-menu input[type="button"]:hover {
				background-color:'.lifefitness_ninzio_hex_to_rgb_shade($nz_h3_megamenu_buttons_back_color,20).' !important;
			}';

			$dynamic_css .='.version3 ::-webkit-input-placeholder {color: '.$nz_h3_desk_submenu_color_reg.';}';
			$dynamic_css .='.version3 :-moz-placeholder           {color: '.$nz_h3_desk_submenu_color_reg.';}';
			$dynamic_css .='.version3 ::-moz-placeholder          {color: '.$nz_h3_desk_submenu_color_reg.';}';
			$dynamic_css .='.version3 :-ms-input-placeholder      {color: '.$nz_h3_desk_submenu_color_reg.';}';

			$dynamic_css .='.version3 .widget_price_filter .ui-slider .ui-slider-handle {
				border-color: '.$nz_h3_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version3 .widget_shopping_cart p.buttons > a:hover, 
			.version3 .widget_shopping_cart p.buttons > a:hover, 
			.version3 .widget_price_filter .price_slider_amount .button:hover {
				box-shadow:inset 0 0 0 2px '.$nz_h3_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version3 .widget_price_filter .ui-slider .ui-slider-range {
				background-color: '.$nz_h3_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version3 .widget_shopping_cart p.buttons > a:hover,
			.version3 .widget_price_filter .price_slider_amount .button:hover {
				color: '.$nz_h3_desk_menu_effect_color.' !important;
			}';


			$dynamic_css .='.version3 .yawp_wim_title {
				text-transform: '.$nz_h3_desk_megamenu_text_transform.';
				font-weight: '.$nz_h3_desk_megamenu_font_weight.';
				font-size: '.$nz_h3_desk_megamenu_font_size.';
				color: '.$nz_h3_desk_megamenu_color.' !important;
				font-family: '.$nz_h3_desk_menu_font_family.';
			}';


			$dynamic_css .='.version3 .widget_tag_cloud .tagcloud a,
			.version3 .post-tags a,
			.version3 .widget_product_tag_cloud .tagcloud a,
			.version3 .projects-tags a {
				font-family: '.$nz_h3_desk_menu_font_family.';
				color: '.$nz_h3_desk_submenu_color_reg.';
				box-shadow:inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg, 0.3).' !important;
			}';

			$dynamic_css .='.version3 .widget_shopping_cart {
			    color: '.$nz_h3_desk_submenu_color_reg.';
			}';

			$dynamic_css .='.version3 .widget_shopping_cart .cart_list li {
				border-bottom: 1px solid '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg,0.2).';
			}';

			$dynamic_css .='.version3 .widget_shopping_cart .cart_list li .remove {
				background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h3_desk_submenu_back_color,10).' !important;
			}';

			$dynamic_css .='.version3 .widget_shopping_cart .cart_list li .remove:hover {
				background-color: '.$nz_h3_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version3 .widget_shopping_cart .cart_list li img {
			    background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg,0.1).';
			}';

			$dynamic_css .='.version3 .widget_shopping_cart .cart_list li:hover img {
			    background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg,0.2).';
			}';

			$dynamic_css .='.version3 .widget_shopping_cart p.buttons > a, 
			.version3 .widget_price_filter .price_slider_amount .button {
				color: '.$nz_h3_desk_submenu_color_reg.' !important;
				box-shadow:inset 0 0 0 2px '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg, 0.3).' !important;
			}';

			$dynamic_css .='.version3 .widget_shopping_cart p.buttons > a:hover, 
			.version3 .widget_price_filter .price_slider_amount .button:hover {
				color: '.$nz_h3_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version3 .star-rating:before {
				color: '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg, 0.4).' !important;
			}';

			$dynamic_css .='.version3 .yawp_wim_title a {
				text-transform: '.$nz_h3_desk_megamenu_text_transform.' !important;
				font-weight: '.$nz_h3_desk_megamenu_font_weight.' !important;
				font-size: '.$nz_h3_desk_megamenu_font_size.' !important;
				color: '.$nz_h3_desk_megamenu_color.' !important;
				font-family: '.$nz_h3_desk_menu_font_family.' !important;
			}';

			$dynamic_css .='.version3 .widget_categories ul li,
			.version3 .widget_pages ul li,
			.version3 .widget_archive ul li,
			.version3 .widget_meta ul li {
				border-bottom: 1px dashed '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg,0.25).';
			}';

			$dynamic_css .='.version3 .widget_nav_menu li a:before,
			.version3 .widget_product_categories li a:before,
			.version3 .widget_categories ul li a:before,
			.version3 .widget_pages ul li a:before,
			.version3 .widget_archive ul li a:before,
			.version3 .widget_meta ul li a:before {
				box-shadow: inset 0 0 0 1px '.$nz_h3_megamenu_buttons_back_color.' !important;
				color: '.$nz_h3_megamenu_buttons_back_color.' !important;
			}';

		/*------ WIDGETS*/

		$dynamic_css .='.version3 .desk-menu .sub-menu .label {font-family: '.$nz_h3_desk_menu_font_family.';}';

		$dynamic_css .='.version3 .search-true.cart-false .search-toggle:after,
		.version3 .cart-true .desk-cart-wrap:after {
			background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_menu_color_reg,0.2).';
		}';

		$dynamic_css .='.version3 .search input[type="text"],
		.version3 .woo-cart {
		    color: '.$nz_h3_desk_submenu_color_reg.';
		}';

		$dynamic_css .='.version3 .woo-cart .widget_shopping_cart .cart_list li {
			border-bottom: 1px solid '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg,0.2).';
		}';

		$dynamic_css .='.version3 .woo-cart .widget_shopping_cart .cart_list li .remove {
			background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h3_desk_submenu_back_color,20).';
		}';

		$dynamic_css .='.version3 .woo-cart .widget_shopping_cart .cart_list li .remove:hover {
			background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h3_desk_submenu_back_color,30).' !important;
		}';

		$dynamic_css .='.version3 .woo-cart .widget_shopping_cart .cart_list li img {
		    background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg,0.1).';
		}';

		$dynamic_css .='.version3 .woo-cart .widget_shopping_cart .cart_list li:hover img {
		    background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_submenu_color_reg,0.2).';
		}';

		/*EFFECTS*/
		$dynamic_css .='.version3.effect-underline .desk-menu > ul > li > a:after,
		.version3.effect-overline .desk-menu > ul > li > a:after,
		.version3.effect-fill .desk-menu > ul > li:hover,
		.version3.effect-fill .desk-menu > ul > li.one-page-active > a,
		.version3.effect-fill .desk-menu > ul > li.current-menu-item,
		.version3.effect-fill .desk-menu > ul > li.current-menu-parent,
		.version3.effect-fill .desk-menu > ul > li.current-menu-ancestor {
			background-color: '.$nz_h3_desk_menu_effect_color.';
		}';

		$dynamic_css .='.version3.effect-dottes .desk-menu > ul > li > a .dottes,
		.version3.effect-dottes .desk-menu > ul > li > a .dottes:after,
		.version3.effect-dottes .desk-menu > ul > li > a .dottes:before {
			background-color: '.$nz_h3_desk_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version3.effect-fill .desk-menu > ul > li:hover,
		.one-page-top.version3.effect-fill .desk-menu > ul > li.one-page-active {
			background-color: '.$nz_h3_desk_menu_effect_color.' !important;
		}';

		$dynamic_css .='.version3.effect-outline .desk-menu > ul > li:hover > a,
		.version3.effect-outline .desk-menu > ul > li.one-page-active > a,
		.version3.effect-outline .desk-menu > ul > li.current-menu-item > a,
		.version3.effect-outline .desk-menu > ul > li.current-menu-parent > a,
		.version3.effect-outline .desk-menu > ul > li.current-menu-ancestor > a {
			box-shadow: inset 0 0 0 2px '.$nz_h3_desk_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version3.effect-outline .desk-menu > ul > li:hover > a,
		.one-page-top.version3.effect-outline .desk-menu > ul > li.one-page-active > a {
			box-shadow: inset 0 0 0 2px '.$nz_h3_desk_menu_effect_color.' !important;
		}';

		$dynamic_css .='.version3.effect-overline .desk-menu > ul > li > a:after {
			top:-'.(($nz_h3_desk_height-30)/2).'px;
		}';

		if (isset($nz_h3_desk_separator_color) && !empty($nz_h3_desk_separator_color)) {

			$dynamic_css .='.version3 .desk-menu > ul:after {
				content:"";
				display:block;
				float:left;
				width:1px;
				height:30px;
				margin-top:'.(($nz_h3_desk_height - 30)/2).'px;
				margin-left: 25px;
    			margin-right: 5px;
				background-color:'.$nz_h3_desk_separator_color.';
				-webkit-transition: all 300ms linear;
				transition: all 300ms linear;
			}';

			if ($nz_h3_header_social_links == 'true') {

				$dynamic_css .='.version3 .header-social-links:before {
					content:"";
					display:block;
					position:absolute;
					margin-top:0 !important;
					left:-20px;
					top:5px;
					width:1px;
					height:30px;
					background-color:'.$nz_h3_desk_separator_color.';
					-webkit-transition: all 300ms linear;
					transition: all 300ms linear;
				}';
			}
		}

		/*FIXED*/
		$dynamic_css .='.version3.fixed-true.active .header-body,
		.version3.fixed-true.active {
			height:'.$nz_h3_fixed_height.'px;
		}';

		$dynamic_css .='.version3.fixed-true.active .logo,
		.version3.fixed-true.active .logo-title {
			height:'.$nz_h3_fixed_height.'px;
			line-height: '.$nz_h3_fixed_height.'px;
		}';

		$dynamic_css .='.version3.fixed-true.active .search,
		.version3.fixed-true.active .desk-menu .sub-menu {
			top: '.$nz_h3_fixed_height.'px;
		}';

		$dynamic_css .='.version3.fixed-true.active .search {
			top: '.($nz_h3_fixed_height/2 + 20).'px;
		}';

		$dynamic_css .='.version3.fixed-true.active .desk-cart-wrap {
			height:'.$nz_h3_fixed_height.'px;
		}';

		$dynamic_css .='.version3.fixed-true.active .header-social-links,
		.version3.fixed-true.active .search-toggle-wrap,
		.version3.fixed-true.active .desk-cart-toggle,
		.version3.fixed-true.active .site-sidebar-toggle {
			margin-top: '.(($nz_h3_fixed_height-40)/2).'px;
		}';

		$dynamic_css .='.version3.fixed-true.active .desk-cart-wrap .cart-info {
			background-color:'.$nz_h3_desk_fixed_cart_back_color.';
			color:'.$nz_h3_desk_fixed_cart_text_color.';
		}';

		$dynamic_css .='.version3.fixed-true.active .woo-cart {
		    top: '.$nz_h3_fixed_height.'px;
		}';

		$dynamic_css .='.version3.fixed-true.active .desk-menu > ul > li {
			height: '.$nz_h3_fixed_height.'px;
			line-height: '.$nz_h3_fixed_height.'px;
		}';

		$dynamic_css .='.version3.fixed-true.active .desk-menu > ul > li > a {
			margin-top: '.(($nz_h3_fixed_height-30)/2).'px;
		}';

		$dynamic_css .='.version3.fixed-true.active .header-social-links  a {
		    color: '.$nz_h3_desk_fixed_social_links_color.';
		}';

		$dynamic_css .='.version3.fixed-true.active .logo-title {
			color: '.$nz_h3_desk_fixed_menu_color_reg.';
		}';

		$dynamic_css .='.version3.fixed-true.active .header-body {
		    background-color: '.$nz_h3_desk_fixed_back_color.';
		}';

		$dynamic_css .='.version3.fixed-true.active .desk-menu > ul > li > a {
		    color: '.$nz_h3_desk_fixed_menu_color_reg.';
		}';

		$dynamic_css .='.version3.fixed-true.active .desk-cart-toggle span {
		    color: '.$nz_h3_desk_fixed_menu_color_reg.';
		}';

		$dynamic_css .='.version3.fixed-true.active .desk-menu > ul > li:hover > a,
		.version3.fixed-true.active .desk-menu > ul > li.one-page-active > a,
		.version3.fixed-true.active .desk-menu > ul > li.current-menu-item > a,
		.version3.fixed-true.active .desk-menu > ul > li.current-menu-parent > a,
		.version3.fixed-true.active .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h3_desk_fixed_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.version3.fixed-true.active .desk-menu > ul > li.current-menu-item > a,
		.one-page-top.version3.fixed-true.active .desk-menu > ul > li.current-menu-parent > a,
		.one-page-top.version3.fixed-true.active .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h3_desk_fixed_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.version3.fixed-true.active .desk-menu > ul > li:hover > a,
		.one-page-top.version3.fixed-true.active .desk-menu > ul > li.one-page-active > a {
		    color: '.$nz_h3_desk_fixed_menu_color_hov.' !important;
		}';

		$dynamic_css .='.version3.fixed-true.active .site-sidebar-toggle {
			background-color: '.$nz_h3_desk_fixed_sidebar_toggle_color.';
			box-shadow:inset 0 0 0 2px '.$nz_h3_desk_fixed_sidebar_toggle_border_color.';
		}';

		$dynamic_css .='.version3.fixed-true.active .search-true.cart-false .search-toggle:after,
		.version3.fixed-true.active .cart-true .desk-cart-wrap:after {
			background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h3_desk_fixed_menu_color_reg,0.2).';
		}';

		$dynamic_css .='.version3.fixed-true.active.effect-outline .desk-menu > ul > li:hover > a,
		.version3.fixed-true.active.effect-outline .desk-menu > ul > li.one-page-active > a,
		.version3.fixed-true.active.effect-outline .desk-menu > ul > li.current-menu-item > a,
		.version3.fixed-true.active.effect-outline .desk-menu > ul > li.current-menu-parent > a,
		.version3.fixed-true.active.effect-outline .desk-menu > ul > li.current-menu-ancestor > a {
			box-shadow: inset 0 0 0 2px '.$nz_h3_desk_fixed_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version3.fixed-true.active.effect-outline .desk-menu > ul > li:hover > a,
		.one-page-top.version3.fixed-true.active.effect-outline .desk-menu > ul > li.one-page-active > a {
			box-shadow: inset 0 0 0 2px '.$nz_h3_desk_fixed_menu_effect_color.' !important;
		}';

		$dynamic_css .='.version3.fixed-true.active.effect-underline .desk-menu > ul > li > a:after,
		.version3.fixed-true.active.effect-overline .desk-menu > ul > li > a:after,
		.version3.fixed-true.active.effect-fill .desk-menu > ul > li:hover,
		.version3.fixed-true.active.effect-fill .desk-menu > ul > li.one-page-active,
		.version3.fixed-true.active.effect-fill .desk-menu > ul > li.current-menu-item,
		.version3.fixed-true.active.effect-fill .desk-menu > ul > li.current-menu-parent,
		.version3.fixed-true.active.effect-fill .desk-menu > ul > li.current-menu-ancestor {
			background-color: '.$nz_h3_desk_fixed_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version3.fixed-true.active.effect-fill .desk-menu > ul > li:hover,
		.one-page-top.version3.fixed-true.active.effect-fill .desk-menu > ul > li.one-page-active {
			background-color: '.$nz_h3_desk_fixed_menu_effect_color.' !important;
		}';

		if (isset($nz_h3_desk_fixed_separator_color) && !empty($nz_h3_desk_fixed_separator_color)) {
			$dynamic_css .='.version3.fixed-true.active .desk-menu > ul:after, .version3.fixed-true.active .header-social-links:before {
				margin-top:'.(($nz_h3_fixed_height - 30)/2).'px;
				background-color:'.$nz_h3_desk_fixed_separator_color.';
			}';
		}

		if (isset($nz_h3_desk_fixed_separator_color) && !empty($nz_h3_desk_fixed_separator_color)) {
			$dynamic_css .='.version3.fixed-true.active .desk-menu > ul:after {
				background-color:'.$nz_h3_desk_fixed_separator_color.';
			}';
		}

		$dynamic_css .='.one-page-bullets a[href*="#"]:hover,
		.one-page-bullets .one-page-active[href*="#"] {
			box-shadow:inset 0 0 0 10px '.$lifefitness_ninzio_main_color.';
		}';

		$dynamic_css .='.desk-menu > ul > li > a > .txt .label:before {
			border-color: '.$lifefitness_ninzio_main_color.' transparent transparent transparent;
		}';

		$dynamic_css .='.version5 .header-top {
			background-color: '.$nz_h5_header_top_back_color.';
		}';

		if(!empty($nz_h5_header_top_border_color)){
			$dynamic_css .='.version5 .header-top {
				border-bottom:1px solid '.$nz_h5_header_top_border_color.';
			}';
		}

		$dynamic_css .='.version5 .header-top .header-top-menu ul li a,.version5 .header-top .social-text {
		    color: '.$nz_h5_header_top_menu_color_reg.';
			font-weight: '.$nz_h5_header_top_menu_font_weight.';
			font-size: '.$nz_h5_header_top_menu_font_size.';
			text-transform: '.$nz_h5_header_top_menu_text_transform.';
		}';

		$dynamic_css .='.version5 .header-top .header-top-menu ul li:hover > a {
		    color: '.$nz_h5_header_top_menu_color_hov.';
		}';

		$dynamic_css .='.version5 .header-top .header-top-menu > ul > li:not(:last-child):after {
			color: '.lifefitness_ninzio_hex_to_rgba($nz_h5_header_top_menu_color_reg,0.3).';
		}';

		$dynamic_css .='.version5 .header-top .top-button {
		    color: '.$nz_h5_top_button_text_color.';
		    background-color: '.$nz_h5_top_button_back_color.';
		}';

		$dynamic_css .='.version5 .header-top .top-button:hover {
		    background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h5_top_button_back_color,20).';
		}';

		$dynamic_css .='.version5 .header-top .header-top-menu ul li ul.submenu-languages,
		.version5 .desk-menu > ul > li ul.submenu-languages
		{width: '.$nz_h5_desk_ls_w .';}';

		$dynamic_css .='.version5.top-false {
			height:'.$nz_h5_desk_height.'px;
		}';

		$dynamic_css .='.version5.top-true {
			height:'.(80+$nz_h5_desk_height).'px;
		}';

		$dynamic_css .='.version5 .header-body {
		    background-color: '.$nz_h5_desk_back_color.';';
		    if(!empty($nz_h5_desk_border_color)){
				$dynamic_css .='border-bottom:1px solid '.$nz_h5_desk_border_color.';';
		    }
			$dynamic_css .='height:'.$nz_h5_desk_height.'px;
		}';

		$dynamic_css .='.desk.version5 .desk-menu {
		    background-color: '.$nz_h5_desk_menu_back_color.';
		}';

		$dynamic_css .='.version5 .logo,
		.version5 .logo-title {
			height: '.$nz_h5_desk_height.'px;
			line-height: '.$nz_h5_desk_height.'px;
		}';

		$dynamic_css .='.version5 .desk-cart-wrap {
			height:'.$nz_h5_desk_height.'px;
		}';

		$dynamic_css .='.version5 .search-toggle,
		.version5 .desk-cart-toggle,
		.version5 .site-sidebar-toggle,
		.version5 .header-social-links,
		.version5 .slogan {
			margin-top: '.(($nz_h5_desk_height-40)/2).'px;
		}';

		$dynamic_css .='.version5 .site-sidebar-toggle {
			background-color: '.$nz_h5_desk_sidebar_toggle_color.';
			box-shadow:inset 0 0 0 2px '.$nz_h5_desk_sidebar_toggle_border_color.';
		}';

		$dynamic_css .='.version5 .desk-cart-wrap .cart-info {
			background-color:'.$nz_h5_desk_cart_back_color.';
			color:'.$nz_h5_desk_cart_text_color.';
		}';

		$dynamic_css .='.version5 .woo-cart, .version5 .search{
		    top: '.($nz_h5_desk_height+40).'px;
		}';

		$dynamic_css .='.version5 .desk-menu > ul > li {
			margin-left: '.$nz_h5_desk_menu_m.'px !important;
		}';

		$dynamic_css .='.version5:not(.active) .logo-title {
			color: '.$nz_h5_desk_menu_color_reg.';
		}';

		$dynamic_css .='.version5 .desk-menu > ul > li > a {
		    color: '.$nz_h5_desk_menu_color_reg.';
			text-transform: '.$nz_h5_desk_menu_text_transform.';
			font-weight: '.$nz_h5_desk_menu_font_weight.';
			font-size: '.$nz_h5_desk_menu_font_size.';
			font-family: '.$nz_h5_desk_menu_font_family.';
		}';

		$dynamic_css .='.version5 .desk-menu > ul > li.menu-item-language > a > .txt {
			box-shadow: inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_menu_color_reg,0.5).';
		}';

		$dynamic_css .='.version5 .desk-menu > ul > li.menu-item-language:hover > a > .txt {
			box-shadow: inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_menu_color_reg,0.7).';
		}';

		$dynamic_css .='.version5 .desk-menu > ul > li:hover > a,
		.version5 .desk-menu > ul > li.one-page-active > a,
		.version5 .desk-menu > ul > li.current-menu-item > a,
		.version5 .desk-menu > ul > li.current-menu-parent > a,
		.version5 .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h5_desk_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.version5 .desk-menu > ul > li.current-menu-item > a,
		.one-page-top.version5 .desk-menu > ul > li.current-menu-parent > a,
		.one-page-top.version5 .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h5_desk_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.version5 .desk-menu > ul > li:hover > a,
		.one-page-top.version5 .desk-menu > ul > li.one-page-active > a {
		    color: '.$nz_h5_desk_menu_color_hov.' !important;
		}';

		$dynamic_css .='.version5 .desk-menu .sub-menu,
		.version5 .header-top .header-top-menu ul li ul,
		.version5 .woo-cart {
			background-color: '.$nz_h5_desk_submenu_back_color.';
		}';

		$dynamic_css .='.version5 .search {
			background-color: '.$nz_h5_desk_submenu_back_color.' !important;
		}';

		$dynamic_css .='.version5 .desk-menu .sub-menu .sub-menu {
			background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h5_desk_submenu_back_color,20).';
		}';

		$dynamic_css .='.version5 .desk-menu .sub-menu li > a {
		    color: '.$nz_h5_desk_submenu_color_reg.';
			text-transform: '.$nz_h5_desk_submenu_text_transform.';
			font-weight: '.$nz_h5_desk_submenu_font_weight.';
			font-size: '.$nz_h5_desk_submenu_font_size.';
			line-height: '.$nz_h5_desk_submenu_line_height.';
			font-family: '.$nz_h5_desk_submenu_font_family.';
		}';

		$dynamic_css .='.version5 .header-top .header-top-menu ul li ul li a {
		    color: '.$nz_h5_desk_submenu_color_reg.';
		}';

		$dynamic_css .='.version5 .desk-menu .sub-menu li:hover > a,
		.version5 .header-top .header-top-menu ul li ul li:hover > a {
		    color: '.$nz_h5_desk_submenu_color_hov.';
		}';
		
		$dynamic_css .='.version5 .desk-menu [data-mm="true"] > .sub-menu > li > a {
			text-transform: '.$nz_h5_desk_megamenu_text_transform.';
			font-weight: '.$nz_h5_desk_megamenu_font_weight.';
			font-size: '.$nz_h5_desk_megamenu_font_size.';
			color: '.$nz_h5_desk_megamenu_color.' !important;
			font-family: '.$nz_h5_desk_menu_font_family.';
		}';

		$dynamic_css .='.version5 .desk-menu > ul > [data-mm="true"] > .sub-menu > li:not(:last-child):after {
			background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_megamenu_color,0.1).' !important;
		}';

		if (isset($nz_h5_desk_megamenu_top_border) && !empty($nz_h5_desk_megamenu_top_border)) {
			
			$dynamic_css .='.version5 .desk-menu [data-mm="true"] > .sub-menu > li > a {
				padding: 0px 0 30px 0;
				position:relative;
			}';

			$dynamic_css .='.version5 .desk-menu [data-mm="true"] > .sub-menu > li > a:after {
				background-color: '.$nz_h5_desk_megamenu_top_border.';
				display:block;
				content: "";
			    width: 50px;
			    height: 2px;
			    display: block;
			    bottom: 22px;
			    left:0px;
			    position:absolute;
			}';

			$dynamic_css .='.version5 .yawp_wim_title {
				position:relative;
				padding: 0px 0 43px 0 !important;
				margin-bottom:0;
				line-height: '.$nz_h5_desk_submenu_line_height.';
			}';

			$dynamic_css .='.version5 .yawp_wim_title:after {
				background-color: '.$nz_h5_desk_megamenu_top_border.';
				display:block;
				content: "";
			    width: 50px;
			    height: 2px;
			    display: block;
			    bottom: 34px;
			    left:0px;
			    position:absolute;
			}';
		}

		$dynamic_css .='.version5 .desk-menu .sub-menu .label {font-family: '.$nz_h5_desk_menu_font_family.';}';

		$dynamic_css .='.version5 .search-true.cart-false .search-toggle:after,
		.version5 .cart-true .desk-cart-wrap:after {
			background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_menu_color_reg,0.2).';
		}';

		$dynamic_css .='.version5 .search input[type="text"] {
		    color: '.$nz_h5_desk_submenu_color_reg.';
		}';

		/*EFFECTS*/
		$dynamic_css .='.version5.effect-underline .desk-menu > ul > li > a:after,
		.version5.effect-overline .desk-menu > ul > li > a:after,
		.version5.effect-fill .desk-menu > ul > li:hover,
		.version5.effect-fill .desk-menu > ul > li.one-page-active > a,
		.version5.effect-fill .desk-menu > ul > li.current-menu-item,
		.version5.effect-fill .desk-menu > ul > li.current-menu-parent,
		.version5.effect-fill .desk-menu > ul > li.current-menu-ancestor {
			background-color: '.$nz_h5_desk_menu_effect_color.';
		}';

		$dynamic_css .='.version5.effect-dottes .desk-menu > ul > li > a .dottes,
		.version5.effect-dottes .desk-menu > ul > li > a .dottes:after,
		.version5.effect-dottes .desk-menu > ul > li > a .dottes:before {
			background-color: '.$nz_h5_desk_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version5.effect-fill .desk-menu > ul > li:hover,
		.one-page-top.version5.effect-fill .desk-menu > ul > li.one-page-active {
			background-color: '.$nz_h5_desk_menu_effect_color.' !important;
		}';

		$dynamic_css .='.version5.effect-outline .desk-menu > ul > li:hover > a,
		.version5.effect-outline .desk-menu > ul > li.one-page-active > a,
		.version5.effect-outline .desk-menu > ul > li.current-menu-item > a,
		.version5.effect-outline .desk-menu > ul > li.current-menu-parent > a,
		.version5.effect-outline .desk-menu > ul > li.current-menu-ancestor > a {
			box-shadow: inset 0 0 0 2px '.$nz_h5_desk_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version5.effect-outline .desk-menu > ul > li:hover > a,
		.one-page-top.version5.effect-outline .desk-menu > ul > li.one-page-active > a {
			box-shadow: inset 0 0 0 2px '.$nz_h5_desk_menu_effect_color.' !important;
		}';

		$dynamic_css .='.version5.effect-overline .desk-menu > ul > li > a:after {
			top:-'.(($nz_h5_desk_height-30)/2).'px;
		}';

		if (isset($nz_h5_desk_separator_color) && !empty($nz_h5_desk_separator_color)) {
			$dynamic_css .='.version5 .slogan:before,
			.version5 .social-links:before {
				width:1px;
				height:30px;
				content:"";
				display:block;
				position:absolute;
				top:50%;
				right:5px;
				margin-top:-15px;
				background-color:'.$nz_h5_desk_separator_color.';
			}';

			$dynamic_css .='.version5 .social-links:before {
				right:auto;
				left:-20px;
			}';
		}

		/*WIDGETS ------*/

			$dynamic_css .='.version5 .menu-item-type-yawp_wim,
			.version5 .menu-item-type-yawp_wim a:not(.button) {
				color: '.$nz_h5_desk_submenu_color_reg.';
				text-transform: '.$nz_h5_desk_submenu_text_transform.';
				font-weight: '.$nz_h5_desk_submenu_font_weight.';
				font-size: '.$nz_h5_desk_submenu_font_size.';
				line-height: '.$nz_h5_desk_submenu_line_height.';
				font-family: '.$nz_h5_desk_submenu_font_family.';
			}';

			$dynamic_css .='.version5 .widget_rss a, 
			.version5 .widget_nz_recent_entries a, 
			.version5 .widget_recent_comments a, 
			.version5 .widget_recent_entries a,
			.version5 .widget_nz_recent_entries .post .post-date,
			.version5 .nz-schedule li,
			.version5 .widget_twitter .tweet-time,
			.version5 .widget_shopping_cart .cart_list > li > a {
				color: '.$nz_h5_desk_submenu_color_reg.' !important;
			}';

			$dynamic_css .='.version5 .widget_rss a:hover, 
			.version5 .widget_nz_recent_entries a:hover, 
			.version5 .widget_recent_comments a:hover, 
			.version5 .widget_recent_entries a:hover,
			.version5 .widget_shopping_cart .cart_list > li > a:hover {
				color: '.$nz_h5_desk_submenu_color_hov.' !important;
			}';

			$dynamic_css .='.version5 .widget_twitter ul li:before,
			.version5 .widget_nz_recent_entries .post-body:before,
			.version5 .widget_recent_comments ul li:before {
				color: '.$nz_h5_megamenu_buttons_back_color.' !important;
			}';

			$dynamic_css .='.version5 .nz-schedule ul li {
				border-bottom: 1px dashed '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_submenu_color_reg, 0.2).';
			}';

			$dynamic_css .='.version5 .widget_shopping_cart .cart_list > li,
			.version5 .widget_products .product_list_widget > li, 
			.version5 .widget_recently_viewed_products .product_list_widget > li,
			.version5 .widget_recent_reviews .product_list_widget > li, 
			.version5 .widget_top_rated_products .product_list_widget > li {
				border-bottom: 1px dashed '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_submenu_color_reg, 0.2).';
			}';

			$dynamic_css .='.version5 .widget_price_filter .price_slider_wrapper .ui-widget-content {
				background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_submenu_color_reg, 0.2).' !important;
			}';

			$dynamic_css .='.version5 .widget_calendar td#prev, 
			.version5 .widget_calendar td#next,
			.version5 .widget_calendar td,
			.version5 .widget_calendar caption,
			.version5 .widget_calendar th:first-child,
			.version5 .widget_calendar th:last-child {
				border-color: '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_submenu_color_reg, 0.2).';
			}';


			$dynamic_css .='.version5 .widget_tag_cloud .tagcloud a:hover,
			.version5 .widget_product_tag_cloud .tagcloud a:hover, 
			.version5 .post-tags a:hover, 
			.version5 .projects-tags a:hover {
				color: '.$nz_h5_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version5 .widget_calendar td#today {
				background-color: '.$nz_h5_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version5 .widget_tag_cloud .tagcloud a:hover,
			.version5 .widget_product_tag_cloud .tagcloud a:hover, 
			.version5 .post-tags a:hover, 
			.version5 .projects-tags a:hover,
			.version5 .widget_tag_cloud .tagcloud a:hover,
			.version5 .widget_product_tag_cloud .tagcloud a:hover, 
			.version5 .post-tags a:hover, 
			.version5 .projects-tags a:hover {
				box-shadow:inset 0 0 0 2px '.$nz_h5_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version5 .widget_nav_menu ul li:hover a {
				color: '.$nz_h5_desk_submenu_color_reg.' !important;
			}';

			$dynamic_css .='.version5 .widget_product_categories ul li a:hover,
			.version5 .widget_shopping_cart p.buttons > a:hover,
			.version5 .widget_recent_entries a:hover,
			.version5 .widget_categories ul li a:hover,
			.version5 .widget_pages ul li a:hover,
			.version5 .widget_archive ul li a:hover,
			.version5 .widget_meta ul li a:hover,
			.version5 .widget_nz_recent_entries .post-title:hover,
			.version5 .widget_price_filter .price_slider_amount .button:hover,
			.version5 .widget_shopping_cart .cart_list > li > a:hover,
			.version5 .widget_products .product_list_widget > li > a:hover,
			.version5 .widget_recently_viewed_products .product_list_widget > li > a:hover,
			.version5 .widget_recent_reviews .product_list_widget > li > a:hover,
			.version5 .widget_top_rated_products .product_list_widget > li > a:hover,
			.version5 .widget_recent_entries a:hover, 
			.version5 .widget_nz_recent_entries .post-title:hover,
			.version5 .widget_product_categories ul li a:hover, 
			.version5 .widget_nav_menu ul li a:hover,
			.version5 .widget_recent_comments a:hover {
				color: '.$nz_h5_desk_submenu_color_hov.' !important;
			}';

			$dynamic_css .='.version5 .menu-item-type-yawp_wim a:hover {
				color: '.$nz_h5_desk_submenu_color_hov.';
			}';

			$dynamic_css .='.version5 textarea, 
			.version5 select, 
			.version5 input[type="date"], 
			.version5 input[type="datetime"], 
			.version5 input[type="datetime-local"], 
			.version5 input[type="email"], 
			.version5 input[type="month"], 
			.version5 input[type="number"], 
			.version5 input[type="password"], 
			.version5 input[type="search"], 
			.version5 input[type="tel"], 
			.version5 input[type="text"], 
			.version5 input[type="time"], 
			.version5 input[type="url"], 
			.version5 input[type="week"] {
				box-shadow: inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_submenu_color_reg,0.25).';
				color: '.$nz_h5_desk_submenu_color_reg.';
			}';

			$dynamic_css .='.version5 textarea:hover, 
			.version5 select:hover, 
			.version5 input[type="date"]:hover, 
			.version5 input[type="datetime"]:hover, 
			.version5 input[type="datetime-local"]:hover, 
			.version5 input[type="email"]:hover, 
			.version5 input[type="month"]:hover, 
			.version5 input[type="number"]:hover, 
			.version5 input[type="password"]:hover, 
			.version5 input[type="search"]:hover, 
			.version5 input[type="tel"]:hover, 
			.version5 input[type="text"]:hover, 
			.version5 input[type="time"]:hover, 
			.version5 input[type="url"]:hover, 
			.version5 input[type="week"]:hover {
				color: '.$nz_h5_desk_submenu_color_hov.' !important;
			}';

			$dynamic_css .='.version5 .desk-menu .button,
			.version5 .desk-menu button,
			.version5 .desk-menu input[type="reset"],
			.version5 .desk-menu input[type="submit"],
			.version5 .desk-menu input[type="button"],
			.version5 .widget_recent_comments ul li:before {
				background-color:'.$nz_h5_megamenu_buttons_back_color.' !important;
				color: '.$nz_h5_megamenu_buttons_text_color.' !important;
			}';

			$dynamic_css .='.version5 .desk-menu .button:hover,
			.version5 .desk-menu button:hover,
			.version5 .desk-menu input[type="reset"]:hover,
			.version5 .desk-menu input[type="submit"]:hover,
			.version5 .desk-menu input[type="button"]:hover {
				background-color:'.lifefitness_ninzio_hex_to_rgb_shade($nz_h5_megamenu_buttons_back_color,20).' !important;
			}';

			$dynamic_css .='.version5 ::-webkit-input-placeholder {color: '.$nz_h5_desk_submenu_color_reg.';}';
			$dynamic_css .='.version5 :-moz-placeholder           {color: '.$nz_h5_desk_submenu_color_reg.';}';
			$dynamic_css .='.version5 ::-moz-placeholder          {color: '.$nz_h5_desk_submenu_color_reg.';}';
			$dynamic_css .='.version5 :-ms-input-placeholder      {color: '.$nz_h5_desk_submenu_color_reg.';}';

			$dynamic_css .='.version5 .widget_price_filter .ui-slider .ui-slider-handle {
				border-color: '.$nz_h5_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version5 .widget_shopping_cart p.buttons > a:hover, 
			.version5 .widget_shopping_cart p.buttons > a:hover, 
			.version5 .widget_price_filter .price_slider_amount .button:hover {
				box-shadow:inset 0 0 0 2px '.$nz_h5_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version5 .widget_price_filter .ui-slider .ui-slider-range {
				background-color: '.$nz_h5_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version5 .widget_shopping_cart p.buttons > a:hover,
			.version5 .widget_price_filter .price_slider_amount .button:hover {
				color: '.$nz_h5_desk_menu_effect_color.' !important;
			}';


			$dynamic_css .='.version5 .yawp_wim_title {
				text-transform: '.$nz_h5_desk_megamenu_text_transform.';
				font-weight: '.$nz_h5_desk_megamenu_font_weight.';
				font-size: '.$nz_h5_desk_megamenu_font_size.';
				color: '.$nz_h5_desk_megamenu_color.' !important;
				font-family: '.$nz_h5_desk_menu_font_family.';
			}';


			$dynamic_css .='.version5 .widget_tag_cloud .tagcloud a,
			.version5 .post-tags a,
			.version5 .widget_product_tag_cloud .tagcloud a,
			.version5 .projects-tags a {
				font-family: '.$nz_h5_desk_menu_font_family.';
				color: '.$nz_h5_desk_submenu_color_reg.';
				box-shadow:inset 0 0 0 1px '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_submenu_color_reg, 0.3).' !important;
			}';

			$dynamic_css .='.version5 .widget_shopping_cart {
			    color: '.$nz_h5_desk_submenu_color_reg.';
			}';

			$dynamic_css .='.version5 .widget_shopping_cart .cart_list li {
				border-bottom: 1px solid '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_submenu_color_reg,0.2).';
			}';

			$dynamic_css .='.version5 .widget_shopping_cart .cart_list li .remove {
				background-color: '.lifefitness_ninzio_hex_to_rgb_shade($nz_h5_desk_submenu_back_color,10).' !important;
			}';

			$dynamic_css .='.version5 .widget_shopping_cart .cart_list li .remove:hover {
				background-color: '.$nz_h5_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version5 .widget_shopping_cart .cart_list li img {
			    background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_submenu_color_reg,0.1).';
			}';

			$dynamic_css .='.version5 .widget_shopping_cart .cart_list li:hover img {
			    background-color: '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_submenu_color_reg,0.2).';
			}';

			$dynamic_css .='.version5 .widget_shopping_cart p.buttons > a, 
			.version5 .widget_price_filter .price_slider_amount .button {
				color: '.$nz_h5_desk_submenu_color_reg.' !important;
				box-shadow:inset 0 0 0 2px '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_submenu_color_reg, 0.3).' !important;
			}';

			$dynamic_css .='.version5 .widget_shopping_cart p.buttons > a:hover, 
			.version5 .widget_price_filter .price_slider_amount .button:hover {
				color: '.$nz_h5_desk_menu_effect_color.' !important;
			}';

			$dynamic_css .='.version5 .star-rating:before {
				color: '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_submenu_color_reg, 0.4).' !important;
			}';

			$dynamic_css .='.version5 .yawp_wim_title a {
				text-transform: '.$nz_h5_desk_megamenu_text_transform.' !important;
				font-weight: '.$nz_h5_desk_megamenu_font_weight.' !important;
				font-size: '.$nz_h5_desk_megamenu_font_size.' !important;
				color: '.$nz_h5_desk_megamenu_color.' !important;
				font-family: '.$nz_h5_desk_menu_font_family.' !important;
			}';

			$dynamic_css .='.version5 .widget_categories ul li,
			.version5 .widget_pages ul li,
			.version5 .widget_archive ul li,
			.version5 .widget_meta ul li {
				border-bottom: 1px dashed '.lifefitness_ninzio_hex_to_rgba($nz_h5_desk_submenu_color_reg,0.25).';
			}';

			$dynamic_css .='.version5 .widget_nav_menu li a:before,
			.version5 .widget_product_categories li a:before,
			.version5 .widget_categories ul li a:before,
			.version5 .widget_pages ul li a:before,
			.version5 .widget_archive ul li a:before,
			.version5 .widget_meta ul li a:before {
				box-shadow: inset 0 0 0 1px '.$nz_h1_megamenu_buttons_back_color.' !important;
				color: '.$nz_h1_megamenu_buttons_back_color.' !important;
			}';

		/*------ WIDGETS*/

		/*FIXED*/

		$dynamic_css .='.version5.desk.fixed-true.active {
			-webkit-transform:translateY(-'.$nz_h5_desk_height.'px);
			-ms-transform:translateY(-'.$nz_h5_desk_height.'px);
			transform:translateY(-'.$nz_h5_desk_height.'px);
		}';

		$dynamic_css .='.version5.desk.fixed-true.top-true.active {
			-webkit-transform:translateY(-'.($nz_h5_desk_height+40).'px);
			-ms-transform:translateY(-'.($nz_h5_desk_height+40).'px);
			transform:translateY(-'.($nz_h5_desk_height+40).'px);
		}';

		if ($nz_header_bar == "true") {
			$dynamic_css .='.version5.desk.fixed-true.active {
				-webkit-transform:translateY(-'.($nz_h5_desk_height+5).'px);
				-ms-transform:translateY(-'.($nz_h5_desk_height+5).'px);
				transform:translateY(-'.($nz_h5_desk_height+5).'px);
			}';

			$dynamic_css .='.version5.desk.fixed-true.top-true.active {
				-webkit-transform:translateY(-'.($nz_h5_desk_height+45).'px);
				-ms-transform:translateY(-'.($nz_h5_desk_height+45).'px);
				transform:translateY(-'.($nz_h5_desk_height+45).'px);
			}';
		}

		

		$dynamic_css .='.version5.fixed-true.active .desk-menu {
		    background-color: '.$nz_h5_desk_fixed_menu_back_color.';
		}';

		$dynamic_css .='.version5.fixed-true.active .desk-menu > ul > li > a {
		    color: '.$nz_h5_desk_fixed_menu_color_reg.';
		}';

		$dynamic_css .='.version5.fixed-true.active .desk-menu > ul > li:hover > a,
		.version5.fixed-true.active .desk-menu > ul > li.one-page-active > a,
		.version5.fixed-true.active .desk-menu > ul > li.current-menu-item > a,
		.version5.fixed-true.active .desk-menu > ul > li.current-menu-parent > a,
		.version5.fixed-true.active .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h5_desk_fixed_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.version5.fixed-true.active .desk-menu > ul > li.current-menu-item > a,
		.one-page-top.version5.fixed-true.active .desk-menu > ul > li.current-menu-parent > a,
		.one-page-top.version5.fixed-true.active .desk-menu > ul > li.current-menu-ancestor > a {
		    color: '.$nz_h5_desk_fixed_menu_color_hov.';
		}';

		$dynamic_css .='.one-page-top.version5.fixed-true.active .desk-menu > ul > li:hover > a,
		.one-page-top.version5.fixed-true.active .desk-menu > ul > li.one-page-active > a {
		    color: '.$nz_h5_desk_fixed_menu_color_hov.' !important;
		}';

		$dynamic_css .='.version5.fixed-true.active.effect-outline .desk-menu > ul > li:hover > a,
		.version5.fixed-true.active.effect-outline .desk-menu > ul > li.one-page-active > a,
		.version5.fixed-true.active.effect-outline .desk-menu > ul > li.current-menu-item > a,
		.version5.fixed-true.active.effect-outline .desk-menu > ul > li.current-menu-parent > a,
		.version5.fixed-true.active.effect-outline .desk-menu > ul > li.current-menu-ancestor > a {
			box-shadow: inset 0 0 0 2px '.$nz_h5_desk_fixed_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version5.fixed-true.active.effect-outline .desk-menu > ul > li:hover > a,
		.one-page-top.version5.fixed-true.active.effect-outline .desk-menu > ul > li.one-page-active > a {
			box-shadow: inset 0 0 0 2px '.$nz_h5_desk_fixed_menu_effect_color.' !important;
		}';

		$dynamic_css .='.version5.fixed-true.active.effect-underline .desk-menu > ul > li > a:after,
		.version5.fixed-true.active.effect-overline .desk-menu > ul > li > a:after,
		.version5.fixed-true.active.effect-fill .desk-menu > ul > li:hover,
		.version5.fixed-true.active.effect-fill .desk-menu > ul > li.one-page-active,
		.version5.fixed-true.active.effect-fill .desk-menu > ul > li.current-menu-item,
		.version5.fixed-true.active.effect-fill .desk-menu > ul > li.current-menu-parent,
		.version5.fixed-true.active.effect-fill .desk-menu > ul > li.current-menu-ancestor {
			background-color: '.$nz_h5_desk_fixed_menu_effect_color.';
		}';

		$dynamic_css .='.one-page-top.version5.fixed-true.active.effect-fill .desk-menu > ul > li:hover,
		.one-page-top.version5.fixed-true.active.effect-fill .desk-menu > ul > li.one-page-active {
			background-color: '.$nz_h5_desk_fixed_menu_effect_color.' !important;
		}';

		$dynamic_css .='@media only screen and (min-width:1100px){';

			$dynamic_css .='.version1.fixed-true.stuck-false.stuck-boxed-false + .page-content-wrap {
				padding-top: '.$nz_h1_desk_height.'px;
			}';

			$dynamic_css .='.version1.fixed-true.stuck-false.stuck-boxed-false.top-true + .page-content-wrap {
				padding-top: '.(40 + $nz_h1_desk_height).'px;
			}';

			$dynamic_css .='.version1.fixed-true.active.stuck-boxed-false.stuck-false + .page-content-wrap  {
				padding-top: '.$nz_h1_fixed_height.'px;
			}';

			$dynamic_css .='.version1.stuck-true + .page-content-wrap > .rich-header.version1 {
				height: '.($nz_h1_desk_height+150).'px;
			}';

			$dynamic_css .='.version1.stuck-true.top-true + .page-content-wrap > .rich-header.version1 {
				height: '.($nz_h1_desk_height+190).'px;
			}';

			$dynamic_css .='.version1.stuck-boxed-true + .page-content-wrap > .rich-header.version1 {
				height: '.($nz_h1_desk_height+150).'px;
			}';

			$dynamic_css .='.version1.stuck-boxed-true.top-true + .page-content-wrap > .rich-header.version1 {
				height: '.($nz_h1_desk_height+190).'px;
			}';

			$dynamic_css .='.version1.stuck-true + .page-content-wrap > .rich-header.version2 {
				height: '.($nz_h1_desk_height+300).'px;
			}';

			$dynamic_css .='.version1.stuck-true.top-true + .page-content-wrap > .rich-header.version2 {
				height: '.($nz_h1_desk_height+340).'px;
			}';

			$dynamic_css .='.version1.stuck-boxed-true + .page-content-wrap > .rich-header.version2 {
				height: '.($nz_h1_desk_height+300).'px;
			}';

			$dynamic_css .='.version1.stuck-boxed-true.top-true + .page-content-wrap > .rich-header.version2 {
				height: '.($nz_h1_desk_height+340).'px;
			}';

			$dynamic_css .='.version1.stuck-true + .page-content-wrap > .rich-header.version1 {
				padding-top: '.(14 + $nz_h1_desk_height).'px;
			}';

			$dynamic_css .='.version1.stuck-true.top-true + .page-content-wrap > .rich-header.version1 {
				padding-top: '.(54 + $nz_h1_desk_height).'px;
			}';

			$dynamic_css .='.version1.stuck-boxed-true + .page-content-wrap > .rich-header.version1 {
				padding-top: '.(14 + $nz_h1_desk_height).'px;
			}';

			$dynamic_css .='.version1.stuck-boxed-true.top-true + .page-content-wrap > .rich-header.version1 {
				padding-top: '.(54 + $nz_h1_desk_height).'px;
			}';

			$dynamic_css .='.version1.stuck-true + .page-content-wrap > .rich-header.version2 {
				padding-top: '.(14 + $nz_h1_desk_height).'px;
			}';

			$dynamic_css .='.version1.stuck-true.top-true + .page-content-wrap > .rich-header.version2 {
				padding-top: '.(54 + $nz_h1_desk_height).'px;
			}';

			$dynamic_css .='.version1.stuck-boxed-true + .page-content-wrap > .rich-header.version2 {
				padding-top: '.(14 + $nz_h1_desk_height).'px;
			}';

			$dynamic_css .='.version1.stuck-boxed-true.top-true + .page-content-wrap > .rich-header.version2 {
				padding-top: '.(54 + $nz_h1_desk_height).'px;
			}';

			$dynamic_css .='.version2.fixed-true.stuck-false + .page-content-wrap {
				padding-top: '.$nz_h2_desk_height.'px;
			}';

			$dynamic_css .='.version2.fixed-true.stuck-false.top-true + .page-content-wrap {
				padding-top: '.(40 + $nz_h2_desk_height).'px;
			}';

			$dynamic_css .='.version2.fixed-true.active.stuck-false + .page-content-wrap  {
				padding-top: '.$nz_h2_fixed_height.'px;
			}';

			$dynamic_css .='.version2.stuck-true + .page-content-wrap > .rich-header.version1 {
				height: '.($nz_h2_desk_height+150).'px;
			}';

			$dynamic_css .='.version2.stuck-true.top-true + .page-content-wrap > .rich-header.version1 {
				height: '.($nz_h2_desk_height+190).'px;
			}';

			$dynamic_css .='.version2.stuck-true + .page-content-wrap > .rich-header.version2 {
				height: '.($nz_h2_desk_height+300).'px;
			}';

			$dynamic_css .='.version2.stuck-true.top-true + .page-content-wrap > .rich-header.version2 {
				height: '.($nz_h2_desk_height+340).'px;
			}';

			$dynamic_css .='.version2.stuck-true + .page-content-wrap > .rich-header.version1 {
				padding-top: '.(14 + $nz_h2_desk_height).'px;
			}';

			$dynamic_css .='.version2.stuck-true.top-true + .page-content-wrap > .rich-header.version1 {
				padding-top: '.(54 + $nz_h2_desk_height).'px;
			}';

			$dynamic_css .='.version2.stuck-true + .page-content-wrap > .rich-header.version2 {
				padding-top: '.(14 + $nz_h2_desk_height).'px;
			}';

			$dynamic_css .='.version2.stuck-true.top-true + .page-content-wrap > .rich-header.version2 {
				padding-top: '.(54 + $nz_h2_desk_height).'px;
			}';

			$dynamic_css .='.fixed-true.header-version3.page-content-wrap:not(.revolution-slider-active)  {
				padding-top: '.$nz_h3_desk_height.'px;
			}';

			$dynamic_css .='.fixed-true.header-version3.page-content-wrap.active  {
				padding-top: '.$nz_h3_fixed_height.'px;
			}';

			$dynamic_css .='.version3.fixed-true.active.effect-overline .desk-menu > ul > li > a:after {
				top:-'.(($nz_h3_fixed_height-30)/2).'px;
			}';

			

			$dynamic_css .='.version5.fixed-true.stuck-false.stuck-boxed-false + .page-content-wrap {
				padding-top: '.(40 + $nz_h5_desk_height).'px;
			}';

			$dynamic_css .='.version5.fixed-true.stuck-false.stuck-boxed-false.top-true + .page-content-wrap {
				padding-top: '.(80 + $nz_h5_desk_height).'px;
			}';

			$dynamic_css .='.version5.fixed-true.active.stuck-boxed-false.stuck-false + .page-content-wrap  {
				padding-top: '.(40 + $nz_h5_fixed_height).'px;
			}';

			$dynamic_css .='.version5.stuck-true + .page-content-wrap > .rich-header.version1 {
				height: '.($nz_h5_desk_height+190).'px;
			}';

			$dynamic_css .='.version5.stuck-true.top-true + .page-content-wrap > .rich-header.version1 {
				height: '.($nz_h5_desk_height+230).'px;
			}';

			$dynamic_css .='.version5.stuck-boxed-true + .page-content-wrap > .rich-header.version1 {
				height: '.($nz_h5_desk_height+200).'px;
			}';

			$dynamic_css .='.version5.stuck-boxed-true.top-true + .page-content-wrap > .rich-header.version1 {
				height: '.($nz_h5_desk_height+240).'px;
			}';

			$dynamic_css .='.version5.stuck-true + .page-content-wrap > .rich-header.version2 {
				height: '.($nz_h5_desk_height+340).'px;
			}';

			$dynamic_css .='.version5.stuck-true.top-true + .page-content-wrap > .rich-header.version2 {
				height: '.($nz_h5_desk_height+380).'px;
			}';

			$dynamic_css .='.version5.stuck-boxed-true + .page-content-wrap > .rich-header.version2 {
				height: '.($nz_h5_desk_height+340).'px;
			}';

			$dynamic_css .='.version5.stuck-boxed-true.top-true + .page-content-wrap > .rich-header.version2 {
				height: '.($nz_h5_desk_height+390).'px;
			}';

			$dynamic_css .='.version5.stuck-true + .page-content-wrap > .rich-header.version1 {
				padding-top: '.(54 + $nz_h5_desk_height).'px;
			}';

			$dynamic_css .='.version5.stuck-true.top-true + .page-content-wrap > .rich-header.version1 {
				padding-top: '.(94 + $nz_h5_desk_height).'px;
			}';

			$dynamic_css .='.version5.stuck-boxed-true + .page-content-wrap > .rich-header.version1 {
				padding-top: '.(54 + $nz_h5_desk_height).'px;
			}';

			$dynamic_css .='.version5.stuck-boxed-true.top-true + .page-content-wrap > .rich-header.version1 {
				padding-top: '.(94 + $nz_h5_desk_height).'px;
			}';

			$dynamic_css .='.version5.stuck-true + .page-content-wrap > .rich-header.version2 {
				padding-top: '.(54 + $nz_h5_desk_height).'px;
			}';

			$dynamic_css .='.version5.stuck-true.top-true + .page-content-wrap > .rich-header.version2 {
				padding-top: '.(94 + $nz_h5_desk_height).'px;
			}';

			$dynamic_css .='.version5.stuck-boxed-true + .page-content-wrap > .rich-header.version2 {
				padding-top: '.(54 + $nz_h5_desk_height).'px;
			}';

			$dynamic_css .='.version5.stuck-boxed-true.top-true + .page-content-wrap > .rich-header.version2 {
				padding-top: '.(94 + $nz_h5_desk_height).'px;
			}';
			
		$dynamic_css .='}';

		$dynamic_css .='@media only screen and (min-width:1600px){';
			$dynamic_css .='.version1 .desk-menu > ul > li {
				margin-left: '.$nz_h1_desk_menu_m_1600.'px !important;
			}';
			$dynamic_css .='.version2 .desk-menu > ul > li {
				margin-left: '.$nz_h2_desk_menu_m_1600.'px !important;
			}';
			$dynamic_css .='.version3 .desk-menu > ul > li {
				margin-left: '.$nz_h3_desk_menu_m_1600.'px !important;
			}';
		$dynamic_css .='}';

	    wp_add_inline_style( 'dynamic-styles', $dynamic_css );
}
add_action( 'wp_enqueue_scripts', 'lifefitness_ninzio_include_dynamic_styles' );
?>