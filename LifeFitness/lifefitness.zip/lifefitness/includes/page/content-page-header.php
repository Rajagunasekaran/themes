<?php
	
	lifefitness_ninzio_global_variables();

	$nz_rh_version     = (isset($GLOBALS['lifefitness_ninzio']['rh-version']) && !empty($GLOBALS['lifefitness_ninzio']['rh-version'])) ? $GLOBALS['lifefitness_ninzio']['rh-version'] : 'version1'; 
	$nz_header_version = (isset($GLOBALS['lifefitness_ninzio']['header-version']) && !empty($GLOBALS['lifefitness_ninzio']['header-version'])) ? $GLOBALS['lifefitness_ninzio']['header-version'] : 'version1';

	$nz_offset = 0;
	$nz_from   = 0;

	$nz_h1_fixed_height = (isset($GLOBALS['lifefitness_ninzio']['h1-fixed-height']) && $GLOBALS['lifefitness_ninzio']['h1-fixed-height']) ? $GLOBALS['lifefitness_ninzio']['h1-fixed-height'] : "90";
	$nz_h2_fixed_height = (isset($GLOBALS['lifefitness_ninzio']['h2-fixed-height']) && $GLOBALS['lifefitness_ninzio']['h2-fixed-height']) ? $GLOBALS['lifefitness_ninzio']['h2-fixed-height'] : "90";
	$nz_h3_fixed_height = (isset($GLOBALS['lifefitness_ninzio']['h3-fixed-height']) && $GLOBALS['lifefitness_ninzio']['h3-fixed-height']) ? $GLOBALS['lifefitness_ninzio']['h3-fixed-height'] : "90";

	$nz_h1_desk_height = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-height']) && $GLOBALS['lifefitness_ninzio']['h1-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h1-desk-height'] : "90";
	$nz_h2_desk_height = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-height']) && $GLOBALS['lifefitness_ninzio']['h2-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h2-desk-height'] : "90";
	$nz_h3_desk_height = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-height']) && $GLOBALS['lifefitness_ninzio']['h3-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h3-desk-height'] : "90";
	$nz_h5_desk_height = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-height']) && $GLOBALS['lifefitness_ninzio']['h5-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h5-desk-height'] : "90";

	$nz_h1_fixed = (isset($GLOBALS['lifefitness_ninzio']['h1-fixed']) && $GLOBALS['lifefitness_ninzio']['h1-fixed'] == 1) ? "true" : "false";
	$nz_h2_fixed = (isset($GLOBALS['lifefitness_ninzio']['h2-fixed']) && $GLOBALS['lifefitness_ninzio']['h2-fixed'] == 1) ? "true" : "false";
	$nz_h3_fixed = (isset($GLOBALS['lifefitness_ninzio']['h3-fixed']) && $GLOBALS['lifefitness_ninzio']['h3-fixed'] == 1) ? "true" : "false";
	$nz_h5_fixed = (isset($GLOBALS['lifefitness_ninzio']['h5-fixed']) && $GLOBALS['lifefitness_ninzio']['h5-fixed'] == 1) ? "true" : "false";

	$nz_h1_header_top = (isset($GLOBALS['lifefitness_ninzio']['h1-header-top']) && $GLOBALS['lifefitness_ninzio']['h1-header-top'] == 1) ? "true" : "false";
	$nz_h2_header_top = (isset($GLOBALS['lifefitness_ninzio']['h2-header-top']) && $GLOBALS['lifefitness_ninzio']['h2-header-top'] == 1) ? "true" : "false";

	switch ($nz_header_version) {
		case 'version1':
			$nz_offset = ($nz_h1_fixed == "true") ? $nz_h1_fixed_height : 0;
			$nz_from   = ($nz_h1_fixed == "true") ? (($nz_h1_header_top == "true") ? $nz_h1_desk_height+40 : $nz_h1_desk_height) : 0;
			break;
		case 'version2':
			$nz_offset = ($nz_h2_fixed == "true") ? $nz_h2_fixed_height : 0;
			$nz_from   = ($nz_h2_fixed == "true") ? (($nz_h2_header_top == "true") ? $nz_h2_desk_height+40 : $nz_h2_desk_height) : 0;
			break;
		case 'version3':
			$nz_offset = ($nz_h3_fixed == "true") ? $nz_h3_fixed_height : 0;
			$nz_from   = ($nz_h3_fixed == "true") ? $nz_h3_desk_height : 0;
			break;
		case 'version5':
			$nz_offset = ($nz_h5_fixed == "true") ? 40  : 0;
			$nz_from   = ($nz_h5_fixed == "true") ? $nz_h5_desk_height+76 : 0;
			break;
	}

	$values           = get_post_custom( get_the_ID() );
	$nz_rev_slider    = (isset($values["rev_slider"][0])) ? $values["rev_slider"][0] : "";

	$styles             = "";
	$styles_fp          = "";

	$styles_title       = "";
	$styles_border      = "";
	$styles_breadcrumbs = "";

	$nz_text_color          = (isset( $values['rh_text_color'][0]) && !empty($values['rh_text_color'][0])) ? $values["rh_text_color"][0] : "";
    $nz_back_color          = (isset( $values['rh_back_color'][0]) && !empty($values['rh_back_color'][0])) ? $values["rh_back_color"][0] : "#f7f7f7";
    $nz_back_img            = (isset( $values['rh_back_img'][0]) && !empty($values['rh_back_img'][0])) ? $values["rh_back_img"][0] : "";

    $nz_breadcrumbs_text_color = (isset( $values['breadcrumbs_text_color'][0]) && !empty($values['breadcrumbs_text_color'][0])) ? $values["breadcrumbs_text_color"][0] : "#777777";
    $nz_rh_text_border_color   = (isset( $values['rh_text_border_color'][0]) && !empty($values['rh_text_border_color'][0])) ? $values["rh_text_border_color"][0] : "";
    $nz_rh_text_border_opacity = (isset( $values['rh_text_border_opacity'][0]) && !empty($values['rh_text_border_opacity'][0])) ? $values["rh_text_border_opacity"][0] : "";

    $nz_back_img_repeat     = (isset( $values['rh_back_img_repeat'][0]) && !empty($values['rh_back_img_repeat'][0])) ? $values["rh_back_img_repeat"][0] : "no-repeat";
    $nz_back_img_position   = (isset( $values['rh_back_img_position'][0]) && !empty($values['rh_back_img_position'][0])) ? $values["rh_back_img_position"][0] : "left top";
    $nz_back_img_attachment = (isset( $values['rh_back_img_attachment'][0]) && !empty($values['rh_back_img_attachment'][0])) ? $values["rh_back_img_attachment"][0] : "scroll";
    $nz_back_img_size       = (isset( $values['rh_back_img_size'][0]) && !empty($values['rh_back_img_size'][0])) ? $values["rh_back_img_size"][0] : "auto";
    $nz_parallax            = (isset( $values['parallax'][0]) && !empty($values['parallax'][0])) ? $values["parallax"][0] : "false";

    if (class_exists('Woocommerce')){
        if (is_cart() || is_checkout() || is_account_page()) {
            $nz_parallax = (isset( $GLOBALS['lifefitness_ninzio']['shop-parallax']) && $GLOBALS['lifefitness_ninzio']['shop-parallax'] == 1) ? "true" : "false";
        }
    }

    if (!empty($nz_back_color)) {$styles .= 'background-color:'.$nz_back_color.';';}
    if (!empty($nz_text_color)) {$styles_title .= 'color:'.$nz_text_color.';';}
	if (!empty($nz_back_img)) {

		if ($nz_parallax != "true" && $nz_back_img_attachment != "fixed") {
			$styles .= 'background-image:url('.$nz_back_img.');';
    		$styles .= 'background-repeat:'.$nz_back_img_repeat.';';
    		$styles .= 'background-position:'.$nz_back_img_position.';';
    		if ($nz_back_img_size == "cover") {$styles .= '-webkit-background-size: cover;-moz-background-size: cover;background-size: cover;';}
		}

		if ($nz_parallax == "true" || $nz_back_img_attachment == "fixed") {

	    	$nz_back_img_repeat     = "no-repeat";
			$nz_back_img_size       = "cover";

			$styles_fp .= 'background-image:url('.$nz_back_img.');';
			$styles_fp .= 'background-repeat:'.$nz_back_img_repeat.';';
			$styles_fp .= 'background-position:'.$nz_back_img_position.';';
	    }

		if ($nz_parallax == "true") {$nz_back_img_attachment = "scroll";}

	}

	if (!empty($nz_breadcrumbs_text_color)) {
		$styles_breadcrumbs .= 'color:'.$nz_breadcrumbs_text_color.';';
	}

	if ($nz_rh_version == "version2") {

		if (!empty($nz_rh_text_border_color)) {
			if (!empty($nz_rh_text_border_opacity)) {
				$styles_border .= 'box-shadow:inset 0 0 0 3px '.lifefitness_ninzio_hex_to_rgba($nz_rh_text_border_color,$nz_rh_text_border_opacity).';';
			} else {
				$styles_border .= 'box-shadow:inset 0 0 0 3px '.$nz_rh_text_border_color.';';
			}
		}

	}

?>
<?php if(shortcode_exists("rev_slider") && !empty($nz_rev_slider)): ?>
	<?php echo(do_shortcode('[rev_slider '.$nz_rev_slider.']')); ?>
<?php else: ?>
	<?php if ($nz_rh_version != "none"): ?>
		<header class="rich-header page-header <?php echo esc_attr($nz_rh_version); ?>" data-parallax="<?php echo esc_attr($nz_parallax); ?>" style="<?php echo esc_attr($styles); ?>">
			<?php if ($nz_parallax == "true"): ?>
				<div class="parallax-container" style="<?php echo esc_attr($styles_fp); ?>">&nbsp;</div>
			<?php endif ?>
			<?php if ($nz_back_img_attachment == "fixed"): ?>
				<div class="fixed-container" style="<?php echo esc_attr($styles_fp); ?>">&nbsp;</div>
			<?php endif ?>
			<div class="container nz-clearfix">

				<?php if ($nz_rh_version == "version1"): ?>
					<div class="rh-content">
						<h1 style="<?php echo esc_attr($styles_title); ?>"><?php echo get_the_title(); ?></h1>				
						<div style="<?php echo esc_attr($styles_breadcrumbs); ?>" class="nz-breadcrumbs nz-clearfix"><?php lifefitness_ninzio_breadcrumbs(); ?></div>
					</div>
				<?php else: ?>
					<div class="rh-content">
						<h1 style="<?php echo esc_attr($styles_title); ?>">
							<?php echo get_the_title(); ?>
							<?php if (!empty($styles_border)): ?>
								<span class="left-hor" style="<?php echo esc_attr($styles_border); ?>"></span>
								<span class="left-ver" style="<?php echo esc_attr($styles_border); ?>"></span>
								<span class="right-hor" style="<?php echo esc_attr($styles_border); ?>"></span>
								<span class="right-ver" style="<?php echo esc_attr($styles_border); ?>"></span>
							<?php endif ?>
						</h1>				
					</div>
				<?php endif ?>

			</div>
			<?php if ($nz_rh_version == 'version2'): ?>
				<div id="slider-arrow" data-target="#nz-content" data-from="<?php echo esc_attr($nz_from); ?>" data-offset="<?php echo esc_attr($nz_offset); ?>" class="i-separator animate nz-clearfix lazy"></div>
			<?php endif ?>
		</header>
	<?php endif ?>
<?php endif ?>
