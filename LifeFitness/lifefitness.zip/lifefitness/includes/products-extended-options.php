<?php if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}?>
<?php 

add_action("admin_init", "lifefitness_ninzio_add_product_meta_box");
function lifefitness_ninzio_add_product_meta_box(){

    add_meta_box(
        "ninzio-product-options", 
        esc_html__("Product options", 'lifefitness'),
        "lifefitness_ninzio_render_product_options", 
        "product",
        "side", 
        "default"
    );

}

function lifefitness_ninzio_render_product_options($post) {

    $values = get_post_custom( $post->ID );

    $ninzio_label_color = isset( $values['ninzio_label_color'] ) ? esc_attr($values["ninzio_label_color"][0]) : "";
    wp_nonce_field( 'ninzio_product_meta_nonce', 'ninzio_product_meta_nonce' );

?>
    <br>
    <div id="ninzio-page-options" class="ninzio-page-section">
        <h2>Ninzio options</h2>
        <div class="ninzio-page-option">
            <label for="ninzio_label_color"><?php echo esc_html__('Enter label text color here', 'lifefitness'); ?></label>
            <input name="ninzio_label_color" class="ninzio-color-picker" type="text" value="<?php echo esc_attr($ninzio_label_color); ?>" />
        </div>
    </div>

<?php
}

add_action( 'save_post', 'lifefitness_ninzio_save_product_options' );  
function lifefitness_ninzio_save_product_options( $post_id )  
{  
    
    if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return; 
    if( !isset( $_POST['ninzio_product_meta_nonce'] ) || !wp_verify_nonce( $_POST['ninzio_product_meta_nonce'], 'ninzio_product_meta_nonce' ) ) return;  
    if( !current_user_can( 'edit_post', $post_id ) ) return;

    if( isset( $_POST['ninzio_label_color'] ) ){update_post_meta($post_id, "ninzio_label_color",$_POST["ninzio_label_color"]);}
}

?>