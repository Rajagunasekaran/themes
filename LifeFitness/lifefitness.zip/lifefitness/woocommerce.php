<?php get_header(); ?>
<?php
    
    lifefitness_ninzio_global_variables();

    $nz_shop_layout         = (isset($GLOBALS['lifefitness_ninzio']['shop-layout']) && !empty($GLOBALS['lifefitness_ninzio']['shop-layout'])) ? $GLOBALS['lifefitness_ninzio']['shop-layout'] : 'medium';
    $nz_shop_sidebar        = ($GLOBALS['lifefitness_ninzio']['shop-sidebar']) ? $GLOBALS['lifefitness_ninzio']['shop-sidebar'] : "none";
    $nz_shop_sidebar_single = ($GLOBALS['lifefitness_ninzio']['shop-sidebar-single']) ? $GLOBALS['lifefitness_ninzio']['shop-sidebar-single'] : "none";
    $nz_shop_rp             = ($GLOBALS['lifefitness_ninzio']['shop-rp'] && $GLOBALS['lifefitness_ninzio']['shop-rp'] == 1) ? "true" : "false";
    $nz_shop_rpn            = ($GLOBALS['lifefitness_ninzio']['shop-rpn']) ? $GLOBALS['lifefitness_ninzio']['shop-rpn'] : 3;

    $nz_rh_version      = (isset($GLOBALS['lifefitness_ninzio']['rh-version']) && !empty($GLOBALS['lifefitness_ninzio']['rh-version'])) ? $GLOBALS['lifefitness_ninzio']['rh-version'] : 'version1'; 
    $nz_header_version  = (isset($GLOBALS['lifefitness_ninzio']['header-version']) && !empty($GLOBALS['lifefitness_ninzio']['header-version'])) ? $GLOBALS['lifefitness_ninzio']['header-version'] : 'version1';

    $styles             = "";
    $styles_fp          = "";

    $styles_title       = "";
    $styles_border      = "";
    $styles_breadcrumbs = "";

    $nz_offset = 0;
    $nz_from   = 0;

    $nz_h1_fixed_height = (isset($GLOBALS['lifefitness_ninzio']['h1-fixed-height']) && $GLOBALS['lifefitness_ninzio']['h1-fixed-height']) ? $GLOBALS['lifefitness_ninzio']['h1-fixed-height'] : "90";
    $nz_h2_fixed_height = (isset($GLOBALS['lifefitness_ninzio']['h2-fixed-height']) && $GLOBALS['lifefitness_ninzio']['h2-fixed-height']) ? $GLOBALS['lifefitness_ninzio']['h2-fixed-height'] : "90";
    $nz_h3_fixed_height = (isset($GLOBALS['lifefitness_ninzio']['h3-fixed-height']) && $GLOBALS['lifefitness_ninzio']['h3-fixed-height']) ? $GLOBALS['lifefitness_ninzio']['h3-fixed-height'] : "90";

    $nz_h1_desk_height = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-height']) && $GLOBALS['lifefitness_ninzio']['h1-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h1-desk-height'] : "90";
    $nz_h2_desk_height = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-height']) && $GLOBALS['lifefitness_ninzio']['h2-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h2-desk-height'] : "90";
    $nz_h3_desk_height = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-height']) && $GLOBALS['lifefitness_ninzio']['h3-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h3-desk-height'] : "90";
    $nz_h5_desk_height = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-height']) && $GLOBALS['lifefitness_ninzio']['h5-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h5-desk-height'] : "90";

    $nz_h1_fixed = (isset($GLOBALS['lifefitness_ninzio']['h1-fixed']) && $GLOBALS['lifefitness_ninzio']['h1-fixed'] == 1) ? "true" : "false";
    $nz_h2_fixed = (isset($GLOBALS['lifefitness_ninzio']['h2-fixed']) && $GLOBALS['lifefitness_ninzio']['h2-fixed'] == 1) ? "true" : "false";
    $nz_h3_fixed = (isset($GLOBALS['lifefitness_ninzio']['h3-fixed']) && $GLOBALS['lifefitness_ninzio']['h3-fixed'] == 1) ? "true" : "false";
    $nz_h5_fixed = (isset($GLOBALS['lifefitness_ninzio']['h5-fixed']) && $GLOBALS['lifefitness_ninzio']['h5-fixed'] == 1) ? "true" : "false";

    $nz_h1_header_top = (isset($GLOBALS['lifefitness_ninzio']['h1-header-top']) && $GLOBALS['lifefitness_ninzio']['h1-header-top'] == 1) ? "true" : "false";
    $nz_h2_header_top = (isset($GLOBALS['lifefitness_ninzio']['h2-header-top']) && $GLOBALS['lifefitness_ninzio']['h2-header-top'] == 1) ? "true" : "false";

    switch ($nz_header_version) {
        case 'version1':
            $nz_offset = ($nz_h1_fixed == "true") ? $nz_h1_fixed_height : 0;
            $nz_from   = ($nz_h1_fixed == "true") ? (($nz_h1_header_top == "true") ? $nz_h1_desk_height+40 : $nz_h1_desk_height) : 0;
            break;
        case 'version2':
            $nz_offset = ($nz_h2_fixed == "true") ? $nz_h2_fixed_height : 0;
            $nz_from   = ($nz_h2_fixed == "true") ? (($nz_h2_header_top == "true") ? $nz_h2_desk_height+40 : $nz_h2_desk_height) : 0;
            break;
        case 'version3':
            $nz_offset = ($nz_h3_fixed == "true") ? $nz_h3_fixed_height : 0;
            $nz_from   = ($nz_h3_fixed == "true") ? $nz_h3_desk_height : 0;
            break;
        case 'version5':
            $nz_offset = ($nz_h5_fixed == "true") ? 40  : 0;
            $nz_from   = ($nz_h5_fixed == "true") ? $nz_h5_desk_height+76 : 0;
            break;
    }

    $nz_shop_title             = (isset( $GLOBALS['lifefitness_ninzio']['shop-title']) && !empty($GLOBALS['lifefitness_ninzio']['shop-title'])) ? esc_attr($GLOBALS['lifefitness_ninzio']["shop-title"]) : "";
    $nz_text_color             = (isset( $GLOBALS['lifefitness_ninzio']['shop-text-color']) && !empty($GLOBALS['lifefitness_ninzio']['shop-text-color'])) ? $GLOBALS['lifefitness_ninzio']["shop-text-color"] : "";
    $nz_back_color             = (isset( $GLOBALS['lifefitness_ninzio']['shop-back']['background-color']) && !empty($GLOBALS['lifefitness_ninzio']['shop-back']['background-color'])) ? $GLOBALS['lifefitness_ninzio']["shop-back"]['background-color'] : "#f7f7f7";
    $nz_back_img               = (isset( $GLOBALS['lifefitness_ninzio']['shop-back']['background-image']) && !empty($GLOBALS['lifefitness_ninzio']['shop-back']['background-image'])) ? $GLOBALS['lifefitness_ninzio']['shop-back']["background-image"] : "";
    $nz_back_img_repeat        = (isset( $GLOBALS['lifefitness_ninzio']['shop-back']['background-repeat']) && !empty($GLOBALS['lifefitness_ninzio']['shop-back']['background-repeat'])) ? $GLOBALS['lifefitness_ninzio']['shop-back']['background-repeat'] : "no-repeat";
    $nz_back_img_position      = (isset( $GLOBALS['lifefitness_ninzio']['shop-back']['background-position']) && !empty($GLOBALS['lifefitness_ninzio']['shop-back']['background-position'])) ? $GLOBALS['lifefitness_ninzio']['shop-back']['background-position'] : "left top";
    $nz_back_img_attachment    = (isset( $GLOBALS['lifefitness_ninzio']['shop-back']['background-attachment']) && !empty($GLOBALS['lifefitness_ninzio']['shop-back']['background-attachment'])) ? $GLOBALS['lifefitness_ninzio']['shop-back']['background-attachment'] : "scroll";
    $nz_back_img_size          = (isset( $GLOBALS['lifefitness_ninzio']['shop-back']['background-size']) && !empty($GLOBALS['lifefitness_ninzio']['shop-back']['background-size'])) ? $GLOBALS['lifefitness_ninzio']['shop-back']['background-size'] : "auto";
    $nz_breadcrumbs_text_color = (isset( $GLOBALS['lifefitness_ninzio']['shop-breadcrumbs-text-color']) && !empty($GLOBALS['lifefitness_ninzio']['shop-breadcrumbs-text-color'])) ? $GLOBALS['lifefitness_ninzio']["shop-breadcrumbs-text-color"] : "#777777";
    $nz_shop_text_border_color = (isset( $GLOBALS['lifefitness_ninzio']['shop-text-border-color']['color']) && !empty($GLOBALS['lifefitness_ninzio']['shop-text-border-color']['color'])) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']["shop-text-border-color"]['color'],$GLOBALS['lifefitness_ninzio']["shop-text-border-color"]['alpha']) : "";
    $nz_parallax               = (isset( $GLOBALS['lifefitness_ninzio']['shop-parallax']) && $GLOBALS['lifefitness_ninzio']['shop-parallax'] == 1) ? "true" : "false";

    if (!empty($nz_back_color)) {$styles .= 'background-color:'.$nz_back_color.';';}
    if (!empty($nz_text_color)) {$styles .= 'color:'.$nz_text_color.';';}
    if (!empty($nz_back_img)) {

        if ($nz_parallax != "true" && $nz_back_img_attachment != "fixed") {
            $styles .= 'background-image:url('.$nz_back_img.');';
            $styles .= 'background-repeat:'.$nz_back_img_repeat.';';
            $styles .= 'background-position:'.$nz_back_img_position.';';
            if ($nz_back_img_size == "cover") {$styles .= '-webkit-background-size: cover;-moz-background-size: cover;background-size: cover;';}
        }

        if ($nz_parallax == "true" || $nz_back_img_attachment == "fixed") {

            $nz_back_img_repeat     = "no-repeat";
            $nz_back_img_size       = "cover";

            $styles_fp .= 'background-image:url('.$nz_back_img.');';
            $styles_fp .= 'background-repeat:'.$nz_back_img_repeat.';';
            $styles_fp .= 'background-position:'.$nz_back_img_position.';';
        }

        if ($nz_parallax == "true") {$nz_back_img_attachment = "scroll";}

    }

    if (!empty($nz_breadcrumbs_text_color)) {
        $styles_breadcrumbs .= 'color:'.$nz_breadcrumbs_text_color.';';
    }

    if ($nz_rh_version == "version2" && !empty($nz_shop_text_border_color)) {
        $styles_border .= 'box-shadow:inset 0 0 0 3px '.$nz_shop_text_border_color.';';
    }

?>
<?php if ($nz_rh_version != "none"): ?>
    <header class="rich-header shop-header <?php echo esc_attr($nz_rh_version); ?>" data-parallax="<?php echo esc_attr($nz_parallax); ?>" style="<?php echo esc_attr($styles); ?>">
        <?php if ($nz_parallax == "true"): ?>
            <div class="parallax-container" style="<?php echo esc_attr($styles_fp); ?>">&nbsp;</div>
        <?php endif ?>
        <?php if ($nz_back_img_attachment == "fixed"): ?>
            <div class="fixed-container" style="<?php echo esc_attr($styles_fp); ?>">&nbsp;</div>
        <?php endif ?>
        <div class="container nz-clearfix">

            <?php if ($nz_rh_version == "version1"): ?>
                <div class="rh-content">
                    <?php if (isset($GLOBALS['lifefitness_ninzio']['shop-title']) && !empty($GLOBALS['lifefitness_ninzio']['shop-title'])): ?>
                        <h1 style="<?php echo esc_attr($styles_title); ?>"><?php echo esc_attr($GLOBALS['lifefitness_ninzio']['shop-title']); ?></h1>
                    <?php else: ?>
                        <h1 style="<?php echo esc_attr($styles_title); ?>"><?php echo esc_html__("Archive", 'lifefitness'); ?></h1>
                    <?php endif ?>
                    <div style="<?php echo esc_attr($styles_breadcrumbs); ?>" class="nz-breadcrumbs nz-clearfix"><?php lifefitness_ninzio_breadcrumbs(); ?></div>
                </div>
            <?php elseif ($nz_rh_version == "version2"): ?>
                <div class="rh-content">
                    <?php if (isset($GLOBALS['lifefitness_ninzio']['shop-title']) && !empty($GLOBALS['lifefitness_ninzio']['shop-title'])): ?>
                        <h1 style="<?php echo esc_attr($styles_title); ?>">
                            <?php echo esc_attr($GLOBALS['lifefitness_ninzio']['shop-title']); ?>
                            <?php if (!empty($styles_border)): ?>
                                <span class="left-hor" style="<?php echo esc_attr($styles_border); ?>"></span>
                                <span class="left-ver" style="<?php echo esc_attr($styles_border); ?>"></span>
                                <span class="right-hor" style="<?php echo esc_attr($styles_border); ?>"></span>
                                <span class="right-ver" style="<?php echo esc_attr($styles_border); ?>"></span>
                            <?php endif ?>
                        </h1>
                    <?php else: ?>
                        <h1 style="<?php echo esc_attr($styles_title); ?>">
                            <?php echo esc_html__("Archive", 'lifefitness'); ?>
                            <?php if (!empty($styles_border)): ?>
                                <span class="left-hor" style="<?php echo esc_attr($styles_border); ?>"></span>
                                <span class="left-ver" style="<?php echo esc_attr($styles_border); ?>"></span>
                                <span class="right-hor" style="<?php echo esc_attr($styles_border); ?>"></span>
                                <span class="right-ver" style="<?php echo esc_attr($styles_border); ?>"></span>
                            <?php endif ?>
                        </h1>
                    <?php endif ?>
                </div>
            <?php endif ?>
        </div>
        <?php if ($nz_rh_version == 'version2'): ?>
            <div id="slider-arrow" data-target="#nz-target" data-from="<?php echo esc_attr($nz_from); ?>" data-offset="<?php echo esc_attr($nz_offset); ?>" class="i-separator animate nz-clearfix lazy"></div>
        <?php endif ?>
    </header>
<?php endif ?>
<div class="shop-layout-wrap lazy <?php echo esc_attr($nz_shop_layout); ?>" id="nz-target">
	<?php if(is_shop() || is_product_category() || is_product_tag()): ?>
		<div class="loop">
            <div class="woocommerce-grey-bar">
                <div class="container">
                    <?php
                        woocommerce_result_count(); 
                        woocommerce_catalog_ordering();
                    ?>
                </div>
            </div>      
			<div class="container">
				<section class="content lazy shop-layout nz-clearfix">
					<?php if($nz_shop_sidebar == "left"): ?>

						<aside class="sidebar">
							<?php get_sidebar('shop'); ?>
						</aside>

						<section class="main-content right">
                            <?php wc_print_notices(); ?>
							<?php woocommerce_content(); ?>
						</section>

					<?php elseif ($nz_shop_sidebar == "right"): ?>

						<section class="main-content left">
                            <?php wc_print_notices(); ?>
							<?php woocommerce_content(); ?>
						</section>

						<aside class="sidebar">
							<?php get_sidebar('shop'); ?>
						</aside>

					<?php else: ?>
                        <?php wc_print_notices(); ?>
						<?php woocommerce_content(); ?>
					<?php endif; ?>
				</section>
			</div>
		</div>
	<?php endif; ?>
	<?php if (is_product()): ?>
        <?php
            $prev_post = get_adjacent_post(false, '', true);
            $next_post = get_adjacent_post(false, '', false);   
        ?>
        <div class="post-single-navigation nz-clearfix">
            <?php if(!empty($prev_post)) {echo '<a rel="prev" href="' . get_permalink($prev_post->ID) . '" title="' . $prev_post->post_title . '"></a>'; } ?>
            <?php if(!empty($next_post)) {echo '<a rel="next" href="' . get_permalink($next_post->ID) . '" title="' . $next_post->post_title . '"></a>'; } ?>
        </div>
		<section class='content nz-clearfix' data-rp="<?php echo esc_attr($nz_shop_rp); ?>" data-rpn="<?php echo esc_attr($nz_shop_rpn); ?>">
			

				<?php if($nz_shop_sidebar_single == "left"): ?>
                    <div class="container">
    					<aside class="sidebar">
    						<?php get_sidebar('shop-single'); ?>
    					</aside>
    					<section class="main-content right">
    						<?php woocommerce_content(); ?>
                        </section>
                        <div class="nz-clearfix">&nbsp;</div>
                    </div>
					<?php get_template_part( '/includes/woocommerce-related-products' ); ?>
				<?php elseif ($nz_shop_sidebar_single == "right"): ?>
                    <div class="container">
    					<section class="main-content left">
    						<?php woocommerce_content(); ?>
    					</section>	
    					<aside class="sidebar">
    						<?php get_sidebar('shop-single'); ?>
    					</aside>
                        <div class="nz-clearfix">&nbsp;</div>
                    </div>
                        <?php get_template_part( '/includes/woocommerce-related-products' ); ?>
				<?php else: ?>
                    <div class="container">
    					<?php woocommerce_content(); ?>
    					<div class="nz-clearfix">&nbsp;</div>
                    </div>
					<?php get_template_part( '/includes/woocommerce-related-products' ); ?>
				<?php endif; ?>

			
		</section>
	<?php endif ?>
</div>
<?php get_footer(); ?>