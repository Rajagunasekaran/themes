<?php 
	lifefitness_ninzio_global_variables();

	if (defined('THEME_PANEL')) {
		theme_panel_demo_configurations_before_wphead();
	}

	include(get_template_directory().'/includes/html-class.php');
?>
<!DOCTYPE html>
<html class="no-js <?php echo esc_attr($shop_class); ?> <?php echo esc_attr($blank_class); ?> <?php echo esc_attr($post_class); ?>" <?php language_attributes(); ?>>
<head>
	<!-- META TAGS -->
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- LINK TAGS -->
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<!-- general wrap start -->
<div id="gen-wrap">

	<!-- wrap start -->
	<div id="wrap" class="nz-<?php echo esc_attr($nz_layout); ?>">

		<?php if ($nz_header_version == "version2"): ?>
			<?php include(get_template_directory().'/includes/header/header-2.php'); ?>
			<div class="page-content-wrap">
			<?php if (is_page()): ?>
				<?php get_template_part( '/includes/page/content-page-header' ); ?>
			<?php endif ?>
		<?php elseif ($nz_header_version == "version3"): ?>
			<?php if (is_page()): ?>
				<?php 
					$values        = get_post_custom( get_the_ID() );
					$nz_rev_slider = (isset($values["rev_slider"][0])) ? $values["rev_slider"][0] : "";
					$nz_h3_fixed   = (isset($GLOBALS['lifefitness_ninzio']['h3-fixed']) && $GLOBALS['lifefitness_ninzio']['h3-fixed'] == 1) ? "true" : "false";
					
				?>
				<?php if(shortcode_exists("rev_slider") && !empty($nz_rev_slider)): ?>
					<div class="page-content-wrap revolution-slider-active fixed-<?php echo esc_attr($nz_h3_fixed); ?> header-<?php echo esc_attr($nz_header_version); ?>">
				<?php else: ?>
					<div class="page-content-wrap fixed-<?php echo esc_attr($nz_h3_fixed); ?> header-<?php echo esc_attr($nz_header_version); ?>">
				<?php endif ?>
				<?php get_template_part( '/includes/page/content-page-header-v2' ); ?>
			<?php else: ?>
				<?php get_template_part('/includes/header/header-3'); ?>
				<div class="page-content-wrap fixed-<?php echo esc_attr($nz_h3_fixed); ?> header-<?php echo esc_attr($nz_header_version); ?>">
			<?php endif; ?>
		<?php elseif($nz_header_version == "version5"): ?>
			<?php get_template_part('/includes/header/header-5'); ?>
			<div class="page-content-wrap">
			<?php if (is_page()): ?>
				<?php get_template_part( '/includes/page/content-page-header' ); ?>
			<?php endif ?>
		<?php else: ?>
			<?php get_template_part('/includes/header/header-1'); ?>
			<div class="page-content-wrap">
			<?php if (is_page()): ?>
				<?php get_template_part( '/includes/page/content-page-header' ); ?>
			<?php endif ?>
		<?php endif ?>