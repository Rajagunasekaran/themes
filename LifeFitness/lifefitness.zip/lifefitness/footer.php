	<?php lifefitness_ninzio_global_variables();?>

		<!-- footer start -->
		<footer class='footer'>
			<div class="footer-wa footer-columns-<?php echo esc_attr($GLOBALS['lifefitness_ninzio']['footer-widgets-column']); ?> nz-clearfix">
				<div class="container nz-clearfix">
					<div class="footer-one-third nz-clearfix">
						<?php get_sidebar('footer-main'); ?>
					</div>
					<div class="footer-two-thirds nz-clearfix">
						<?php get_sidebar('footer'); ?>
					</div>
				</div>
			</div>
			<div class="footer-info-area nz-clearfix">
				<div class="container">
					<?php if (isset($GLOBALS['lifefitness_ninzio']['footer-social']) && $GLOBALS['lifefitness_ninzio']['footer-social'] == 1): ?>
						<div class="footer-social-links nz-clearfix">
							<?php include(get_template_directory().'/includes/social-links.php'); ?>
						</div>
					<?php endif ?>
					<?php if (isset($GLOBALS['lifefitness_ninzio']['footer-copy']) && $GLOBALS['lifefitness_ninzio']['footer-copy']): ?>
						<div class="footer-copyright nz-clearfix">
							<?php echo wp_kses($GLOBALS['lifefitness_ninzio']['footer-copy'],wp_kses_allowed_html( 'post' )); ?>
						</div>
					<?php endif ?>
				</div>
			</div>
		</footer>
		<!-- footer end -->
		</div>
	</div>
	<!-- wrap end -->
</div>
<a id="top" href="#wrap"></a>
<!-- general wrap end -->
<?php if (is_page()){
	$nz_one_page_nav    = (isset($GLOBALS['lifefitness_ninzio']['one-page-navigation']) && !empty($GLOBALS['lifefitness_ninzio']['one-page-navigation'])) ? $GLOBALS['lifefitness_ninzio']['one-page-navigation'] : 'top'; 
	$nz_one_page_status = "false";
	$values = get_post_custom( get_the_ID() );
	if (isset($values['one_page'][0]) && $values['one_page'][0] == "true") {
		$nz_one_page_status = "true";
	}
?>
	<?php if ($nz_one_page_status == "true" && $nz_one_page_nav == "side"): ?>
		<?php
			$arg = array( 
				'theme_location' => 'one-page-bullets', 
				'depth'          => 1, 
				'container'      => false, 
				'menu_id'        => 'one-page-bullets',
				'link_before'    => '',
				'link_after'     => ''
			);
		?>
		<div class="one-page-bullets"><?php wp_nav_menu($arg); ?></div>
	<?php endif; ?>
<?php } ?>
<?php wp_footer(); ?>
</body>
</html>