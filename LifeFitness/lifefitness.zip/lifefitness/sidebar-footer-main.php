<?php if(is_active_sidebar('footer-main-widget-area')): ?>
	<aside class="footer-main-widget-area widget-area nz-clearfix">
		<?php if ( function_exists( 'dynamic_sidebar' ) && dynamic_sidebar('footer-main-widget-area') ) : ?><?php endif; ?>
	</aside>
<?php endif; ?>