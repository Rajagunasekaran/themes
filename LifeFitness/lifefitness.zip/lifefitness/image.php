<?php $metadata = wp_get_attachment_metadata(); ?>
<img class="ninzio-attachment-image" src="<?php echo esc_url( wp_get_attachment_url() ); ?>" alt="">