<?php
	get_header();
		get_template_part('/includes/blog/content-blog-header');
		get_template_part('/includes/blog/content-blog-body');
	get_footer(); 
?>