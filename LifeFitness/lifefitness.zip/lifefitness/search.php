<?php get_header(); ?>
<?php
    
    lifefitness_ninzio_global_variables();

    $nz_rh_version      = (isset($GLOBALS['lifefitness_ninzio']['rh-version']) && !empty($GLOBALS['lifefitness_ninzio']['rh-version'])) ? $GLOBALS['lifefitness_ninzio']['rh-version'] : 'version1'; 
    $nz_header_version  = (isset($GLOBALS['lifefitness_ninzio']['header-version']) && !empty($GLOBALS['lifefitness_ninzio']['header-version'])) ? $GLOBALS['lifefitness_ninzio']['header-version'] : 'version1';

    $styles             = "";
    $styles_fp          = "";

    $styles_title       = "";
    $styles_border      = "";
    $styles_breadcrumbs = "";

    $nz_offset = 0;
    $nz_from   = 0;

    $nz_h1_fixed_height = (isset($GLOBALS['lifefitness_ninzio']['h1-fixed-height']) && $GLOBALS['lifefitness_ninzio']['h1-fixed-height']) ? $GLOBALS['lifefitness_ninzio']['h1-fixed-height'] : "90";
    $nz_h2_fixed_height = (isset($GLOBALS['lifefitness_ninzio']['h2-fixed-height']) && $GLOBALS['lifefitness_ninzio']['h2-fixed-height']) ? $GLOBALS['lifefitness_ninzio']['h2-fixed-height'] : "90";
    $nz_h3_fixed_height = (isset($GLOBALS['lifefitness_ninzio']['h3-fixed-height']) && $GLOBALS['lifefitness_ninzio']['h3-fixed-height']) ? $GLOBALS['lifefitness_ninzio']['h3-fixed-height'] : "90";

    $nz_h1_desk_height = (isset($GLOBALS['lifefitness_ninzio']['h1-desk-height']) && $GLOBALS['lifefitness_ninzio']['h1-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h1-desk-height'] : "90";
    $nz_h2_desk_height = (isset($GLOBALS['lifefitness_ninzio']['h2-desk-height']) && $GLOBALS['lifefitness_ninzio']['h2-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h2-desk-height'] : "90";
    $nz_h3_desk_height = (isset($GLOBALS['lifefitness_ninzio']['h3-desk-height']) && $GLOBALS['lifefitness_ninzio']['h3-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h3-desk-height'] : "90";
    $nz_h5_desk_height = (isset($GLOBALS['lifefitness_ninzio']['h5-desk-height']) && $GLOBALS['lifefitness_ninzio']['h5-desk-height']) ? $GLOBALS['lifefitness_ninzio']['h5-desk-height'] : "90";

    $nz_h1_fixed = (isset($GLOBALS['lifefitness_ninzio']['h1-fixed']) && $GLOBALS['lifefitness_ninzio']['h1-fixed'] == 1) ? "true" : "false";
    $nz_h2_fixed = (isset($GLOBALS['lifefitness_ninzio']['h2-fixed']) && $GLOBALS['lifefitness_ninzio']['h2-fixed'] == 1) ? "true" : "false";
    $nz_h3_fixed = (isset($GLOBALS['lifefitness_ninzio']['h3-fixed']) && $GLOBALS['lifefitness_ninzio']['h3-fixed'] == 1) ? "true" : "false";
    $nz_h5_fixed = (isset($GLOBALS['lifefitness_ninzio']['h5-fixed']) && $GLOBALS['lifefitness_ninzio']['h5-fixed'] == 1) ? "true" : "false";

    $nz_h1_header_top = (isset($GLOBALS['lifefitness_ninzio']['h1-header-top']) && $GLOBALS['lifefitness_ninzio']['h1-header-top'] == 1) ? "true" : "false";
    $nz_h2_header_top = (isset($GLOBALS['lifefitness_ninzio']['h2-header-top']) && $GLOBALS['lifefitness_ninzio']['h2-header-top'] == 1) ? "true" : "false";

    switch ($nz_header_version) {
        case 'version1':
            $nz_offset = ($nz_h1_fixed == "true") ? $nz_h1_fixed_height : 0;
            $nz_from   = ($nz_h1_fixed == "true") ? (($nz_h1_header_top == "true") ? $nz_h1_desk_height+40 : $nz_h1_desk_height) : 0;
            break;
        case 'version2':
            $nz_offset = ($nz_h2_fixed == "true") ? $nz_h2_fixed_height : 0;
            $nz_from   = ($nz_h2_fixed == "true") ? (($nz_h2_header_top == "true") ? $nz_h2_desk_height+40 : $nz_h2_desk_height) : 0;
            break;
        case 'version3':
            $nz_offset = ($nz_h3_fixed == "true") ? $nz_h3_fixed_height : 0;
            $nz_from   = ($nz_h3_fixed == "true") ? $nz_h3_desk_height : 0;
            break;
        case 'version5':
            $nz_offset = ($nz_h5_fixed == "true") ? 40  : 0;
            $nz_from   = ($nz_h5_fixed == "true") ? $nz_h5_desk_height+76 : 0;
            break;
    }

    $nz_text_color                = (isset( $GLOBALS['lifefitness_ninzio']['tech-text-color']) && !empty($GLOBALS['lifefitness_ninzio']['tech-text-color'])) ? $GLOBALS['lifefitness_ninzio']["tech-text-color"] : "";
    $nz_back_color                = (isset( $GLOBALS['lifefitness_ninzio']['tech-back']['background-color']) && !empty($GLOBALS['lifefitness_ninzio']['tech-back']['background-color'])) ? $GLOBALS['lifefitness_ninzio']["tech-back"]['background-color'] : "#f7f7f7";
    $nz_back_img                  = (isset( $GLOBALS['lifefitness_ninzio']['tech-back']['background-image']) && !empty($GLOBALS['lifefitness_ninzio']['tech-back']['background-image'])) ? $GLOBALS['lifefitness_ninzio']['tech-back']["background-image"] : "";
    $nz_back_img_repeat           = (isset( $GLOBALS['lifefitness_ninzio']['tech-back']['background-repeat']) && !empty($GLOBALS['lifefitness_ninzio']['tech-back']['background-repeat'])) ? $GLOBALS['lifefitness_ninzio']['tech-back']['background-repeat'] : "no-repeat";
    $nz_back_img_position         = (isset( $GLOBALS['lifefitness_ninzio']['tech-back']['background-position']) && !empty($GLOBALS['lifefitness_ninzio']['tech-back']['background-position'])) ? $GLOBALS['lifefitness_ninzio']['tech-back']['background-position'] : "left top";
    $nz_back_img_attachment       = (isset( $GLOBALS['lifefitness_ninzio']['tech-back']['background-attachment']) && !empty($GLOBALS['lifefitness_ninzio']['tech-back']['background-attachment'])) ? $GLOBALS['lifefitness_ninzio']['tech-back']['background-attachment'] : "scroll";
    $nz_back_img_size             = (isset( $GLOBALS['lifefitness_ninzio']['tech-back']['background-size']) && !empty($GLOBALS['lifefitness_ninzio']['tech-back']['background-size'])) ? $GLOBALS['lifefitness_ninzio']['tech-back']['background-size'] : "auto";
    $nz_breadcrumbs_text_color    = (isset( $GLOBALS['lifefitness_ninzio']['tech-breadcrumbs-text-color']) && !empty($GLOBALS['lifefitness_ninzio']['tech-breadcrumbs-text-color'])) ? $GLOBALS['lifefitness_ninzio']["tech-breadcrumbs-text-color"] : "#ffffff";
    $nz_tech_text_border_color    = (isset( $GLOBALS['lifefitness_ninzio']['tech-text-border-color']['color']) && !empty($GLOBALS['lifefitness_ninzio']['tech-text-border-color']['color'])) ? lifefitness_ninzio_hex_to_rgba($GLOBALS['lifefitness_ninzio']["tech-text-border-color"]['color'],$GLOBALS['lifefitness_ninzio']["tech-text-border-color"]['alpha']) : "rgba(255,255,255,0.1)";
    $nz_parallax                  = (isset( $GLOBALS['lifefitness_ninzio']['tech-parallax']) && $GLOBALS['lifefitness_ninzio']['tech-parallax'] == 1) ? "true" : "false";

    if (!empty($nz_back_color)) {$styles .= 'background-color:'.$nz_back_color.';';}
    if (!empty($nz_text_color)) {$styles .= 'color:'.$nz_text_color.';';}
    if (!empty($nz_back_img)) {

        if ($nz_parallax != "true" && $nz_back_img_attachment != "fixed") {
            $styles .= 'background-image:url('.$nz_back_img.');';
            $styles .= 'background-repeat:'.$nz_back_img_repeat.';';
            $styles .= 'background-position:'.$nz_back_img_position.';';
            if ($nz_back_img_size == "cover") {$styles .= '-webkit-background-size: cover;-moz-background-size: cover;background-size: cover;';}
        }

        if ($nz_parallax == "true" || $nz_back_img_attachment == "fixed") {

            $nz_back_img_repeat     = "no-repeat";
            $nz_back_img_size       = "cover";

            $styles_fp .= 'background-image:url('.$nz_back_img.');';
            $styles_fp .= 'background-repeat:'.$nz_back_img_repeat.';';
            $styles_fp .= 'background-position:'.$nz_back_img_position.';';
        }

        if ($nz_parallax == "true") {$nz_back_img_attachment = "scroll";}

    }

    if (!empty($nz_breadcrumbs_text_color)) {
        $styles_breadcrumbs .= 'color:'.$nz_breadcrumbs_text_color.';';
    }

    if ($nz_rh_version == "version2" && !empty($nz_tech_text_border_color)) {
        $styles_border .= 'box-shadow:inset 0 0 0 3px '.$nz_tech_text_border_color.';';
    }
?>
<?php $total_results = $wp_query->found_posts; ?>
<?php if ($nz_rh_version != "none"): ?>
	<header class="rich-header search-header <?php echo esc_attr($nz_rh_version); ?>" data-parallax="<?php echo esc_attr($nz_parallax); ?>" style="<?php echo esc_attr($styles); ?>">
		<?php if ($nz_parallax == "true"): ?>
			<div class="parallax-container" style="<?php echo esc_attr($styles_fp); ?>">&nbsp;</div>
		<?php endif ?>
		<?php if ($nz_back_img_attachment == "fixed"): ?>
			<div class="fixed-container" style="<?php echo esc_attr($styles_fp); ?>">&nbsp;</div>
		<?php endif ?>
		<div class="container nz-clearfix">

			<?php if ($nz_rh_version == "version1"): ?>
				<div class="rh-content">
					<h1 style="<?php echo esc_attr($styles_title); ?>"><?php echo esc_html__('Search results', 'lifefitness'); ?></h1>				
                    <div style="<?php echo esc_attr($styles_breadcrumbs); ?>" class="nz-breadcrumbs nz-clearfix"><?php lifefitness_ninzio_breadcrumbs(); ?></div>
				</div>
			<?php elseif ($nz_rh_version == "version2"): ?>
				<div class="rh-content">
					<h1 style="<?php echo esc_attr($styles_title); ?>">
						<?php echo esc_html__('Search results', 'lifefitness'); ?>
						<?php if (!empty($styles_border)): ?>
                            <span class="left-hor" style="<?php echo esc_attr($styles_border); ?>"></span>
                            <span class="left-ver" style="<?php echo esc_attr($styles_border); ?>"></span>
                            <span class="right-hor" style="<?php echo esc_attr($styles_border); ?>"></span>
                            <span class="right-ver" style="<?php echo esc_attr($styles_border); ?>"></span>
                        <?php endif ?>
					</h1>				
				</div>
			<?php endif ?>
		</div>
		<?php if ($nz_rh_version == 'version2'): ?>
            <div id="slider-arrow" data-target="#nz-target" data-from="<?php echo esc_attr($nz_from); ?>" data-offset="<?php echo esc_attr($nz_offset); ?>" class="i-separator animate nz-clearfix lazy"></div>
        <?php endif ?>
	</header>
<?php endif ?>
<div id="nz-content" class='content nz-clearfix padding-true'>
	<div class='container'>
		<div class="search-form">
			<?php echo get_search_form(); ?>
		</div>
		<div class="search-results-title">
			<?php echo esc_attr($total_results).esc_html__(' search results for', 'lifefitness').' <strong><i>"'.get_search_query().'</i></strong>"'; ?>
		</div>
		<div class="search-posts">
			<?php if (have_posts()) : ?>
				<?php while (have_posts()) : the_post(); ?>

					<?php $post_type = get_post_type( get_the_ID() ); ?>

					<article <?php post_class() ?> id="post-<?php the_ID(); ?>">
						<div class="post-body">

							<?php if ($post_type == "post"): ?>
								<span title="<?php echo esc_attr($post_type); ?>" class="post-indication icon-feather2"></span>
							<?php elseif($post_type == "portfolio"): ?>
								<span title="<?php echo esc_attr($post_type); ?>" class="post-indication icon-briefcase2"></span>
							<?php else: ?>
								<span title="<?php echo esc_attr($post_type); ?>" class="post-indication icon-newspaper3"></span>
							<?php endif ?>

							<?php if ( '' != get_the_title() ): ?>
								<h3 class="post-title">
									<a href="<?php the_permalink(); ?>" title="<?php echo esc_html__("Go to", 'lifefitness').' '.get_the_title(); ?>" rel="bookmark">
										<?php the_title(); ?>
									</a>
								</h3>
							<?php endif; ?>

							<div class="post-meta nz-clearfix">
								<div class="post-author"><?php echo esc_html__("Posted by", 'lifefitness'); ?> <a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>" title="<?php echo esc_html__('View all posts by', 'lifefitness'); ?> <?php the_author(); ?>"><?php the_author(); ?></a></div>
							</div>
							<?php if ( '' != get_the_content() ): ?>
							<div class="post-content nz-clearfix">
								<?php the_excerpt(); ?>
							</div>
							<?php endif; ?>
							<a href="<?php the_permalink(); ?>" class="search-button round button button-normal default small animate-false hover-fill"><?php echo esc_html__("Read more", 'lifefitness'); ?><span class="screen-reader-text"> <?php the_title();?></span></a>
						</div>
					</article>
				<?php endwhile; ?>
				<?php lifefitness_ninzio_post_nav_num(); ?>
			<?php else : ?>
				<div class="suggestions">
					<p><strong><?php echo esc_html__('Suggestions:', 'lifefitness'); ?></strong></p>
					<ol>
						<li><?php echo esc_html__('Make sure that all words are spelled correctly', 'lifefitness'); ?></li>
						<li><?php echo esc_html__('Try different keywords', 'lifefitness'); ?></li>
						<li><?php echo esc_html__('Try more general keywords', 'lifefitness'); ?></li>
						<li><?php echo esc_html__('Try fewer keywords', 'lifefitness'); ?></li>
					</ol>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php get_footer(); ?>