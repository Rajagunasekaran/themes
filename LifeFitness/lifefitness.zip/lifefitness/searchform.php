<form action="<?php  echo esc_url(home_url('/')); ?>/" method="get">
    <fieldset>
        <input type="text" name="s" id="s" placeholder="<?php echo esc_html__('Search for...', 'lifefitness'); ?>" value="<?php echo esc_html__('Search for...', 'lifefitness'); ?>" />
        <input type="submit" id="searchsubmit" value="<?php echo esc_html__('Search', 'lifefitness'); ?>" />
    </fieldset>
</form>